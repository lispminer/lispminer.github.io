-- LMCodesDef.lua
-- Version 2.3.2022 20:47:58

lm.codes.ACQuantifierSourceType = {
		Before= 1,                            -- 'State before' frequencies (Quantifier test applied to the state-before set data only)
		After= 2,                             -- 'State after' frequencies (Quantifier test applied to the state-after set data only)
		DiffAbs= 3,                           -- Delta of absolute frequencies values (Quantifier test applied to the 4ft-table computed by substracting of corresponding frequencies)
		DiffRel= 4,                           -- Delta of relative frequencies values (Quantifier test applied to the 4ft-table computed by substracting of corresponding relative frequencies)
		ValDiff= 5,                           -- Difference of interest-measures (Test applied to the difference of interest-measures computed separately from each frequency table)
		ValDiffAbs= 6,                        -- Absolute difference of interest-measures (Test applied to the absolute difference of interest-measures computed separately from each frequency table)
		ValRatio= 7,                          -- Ratio of interest-measures (Test applied to the ratio of interest-measures computed separately from each frequency table)
		ValRatioMax= 8,                       -- Higher of two ratios of interest-measures (Test applied to the higher of two ratios of interest-measures (after/before or before/after))
};

lm.codes.ActionStateType = {
		Before= 2,                            -- Before (State before action)
		After= 3,                             -- After (State after action)
};

lm.codes.ActionType = {
		Stable= 2,                            -- Stable (Stable with no action)
		Variable= 3,                          -- Variable (Variable with action possible)
};

lm.codes.AFQuantifierType = {
		Sum= 1,                               -- Sum of frequencies (Sum of frequencies from source contingency table)
		Min= 2,                               -- Min frequency (Minimal frequency from source contingency table)
		Max= 3,                               -- Max frequency (Maximal frequency from source contingency table)
		PImplication= 4,                      -- p-Implication (a/(a+b) >= p ... at least 100*p [%] of objects satisfying A satisfy also S)
		AverageDifference= 28,                -- Average Difference Dependence (Relative difference in number of objects satisfying S among objects satisfying A to number objects saysfying S in the whole data matrix. Paramater p in <-1;inf), similar to the Lift(X->Y)= P(Y|X)/P(Y). It holds p= P(Y|X)/P(Y)-1.)
		AboveAverage= 5,                      -- Above Average Dependence (Among objects satisfying A, there are at least 100*p [%] more objects satisfying S than there are objects satisfying S in the whole data matrix. Parameter p in <0;inf).)
		BelowAverage= 6,                      -- Below Average Dependence (Among objects satisfying A, there are at least 100*p [%] less objects satisfying S than there are objects satisfying S in the whole data matrix. Parameter p in <0;1>.)
		OAD= 29,                              -- Outside Average Dependence (Among objects satisfying A, there is at least 100*p [%] more or less objects satisfying S than there are objects satisfying S in the whole data matrix. Parameter p in <0;1>.)
		LowerCriticalImplication= 7,          -- Lower Critical Implication
		UpperCriticalImplication= 8,          -- Upper Critical Implication
		DoublePImplication= 9,                -- Double p-Implication
		DoubleLowerCriticalImplication= 10,   -- Double Lower Critical Implication
		DoubleUpperCriticalImplication= 11,   -- Double Upper Critical Implication
		FoundedEquivalence= 12,               -- p-Equivalence
		LowerCriticalEquivalence= 13,         -- Lower Critical Equivalence
		UpperCriticalEquivalence= 14,         -- Upper Critical Equivalence
		SimpleDeviation= 15,                  -- Simple Deviation
		Fisher= 16,                           -- Fisher quantifier
		ChiSq= 17,                            -- Chi-Squared quantifier
		AQ= 18,                               -- A-quantifier
		EQ= 19,                               -- E-quantifier
		afrequency= 20,                       -- a-frequency (a-frequency (BASE) from source contingency table)
};

lm.codes.AFQuantifierValueType = {
		Abs= 4,                               -- Absolute number (Absolute number. Threshold value is left as given.)
		RelCondition= 1,                      -- Relative [%] to act condition (Relative to number of rows matching condition. Threshold value [%] is multiplied by (number of rows matching condition)/100)
		RelAll= 2,                            -- Relative [%] to all objects (Relative to number of all rows in the data matrix. Threshold value [%] is multiplied by (number of rows in the whole matrix)/100)
		RelMax= 3,                            -- Relative [%] to max frequency (Relative to maximal value in the current contingency table. Threshold value [%] is multiplied by (the highest frequency)/100)
};

lm.codes.AggregateType = {
		COUNT= 1,                             -- Count(*) (Number of rows in group.)
		SUM= 2,                               -- Sum (Sum of values in group. Each category is represented by its index.)
		MIN= 3,                               -- Minimum (Minimum value in group. Each category is represented by its index.)
		MAX= 4,                               -- Maximum (Maximum value in group. Each category is represented by its index.)
		AVG= 5,                               -- Average (Average value in group. Each category is represented by its index.)
};

lm.codes.BoolOpType = {
		Conjunction= 1,                       -- Conjunction (Logical operation of conjunction)
		Disjunction= 2,                       -- Disjunction (Logical operation of disjunction)
};

lm.codes.BoolType = {
		NotSet= 1,                            -- No boolean (Not boolean category)
		True= 2,                              -- True (Category representing 'TRUE' values)
		False= 3,                             -- False (Category representing 'FALSE' values)
};

lm.codes.BracketType = {
		Sharp= 1,                             -- Sharp (Include border value)
		Round= 2,                             -- No sharp (Don't include border value)
};

lm.codes.CategorySubType = {
		Enumeration= 1,                       -- Enumeration (Enumeration of values)
		Interval= 2,                          -- Interval (Interval of values)
		FuzzyInterval= 3,                     -- Fuzzy interval (Fuzzy intervals)
};

lm.codes.CedentType = {
		Antecedent= 2,                        -- Antecedent (Left 4ft-cedent)
		Succedent= 3,                         -- Succedent (Right 4ft-cedent)
		Condition= 4,                         -- Condition (Condition)
		FirstSet= 5,                          -- First set (First set for difference)
		SecondSet= 6,                         -- Second set (Second set for difference)
		AntecedentVar= 7,                     -- Variable antecedent (Action in antecedent)
		SuccedentVar= 8,                      -- Variable succedent (Action in succedent)
		CFAttribute= 9,                       -- Histogram attribute (Attribute used for calculation of CF-histogram)
		KLAttributeRow= 10,                   -- Row attribute (Row attribute for KL-table)
		KLAttributeCol= 11,                   -- Col attribute (Column attribut for KL-table)
		ETAttribute= 12,                      -- ETree Attribute (Attribute used in tree)
		ETClass= 13,                          -- Class Attribute (Target class attribute)
		MCAttribute= 14,                      -- Vector Attribute (Attribute used in clustering)
		ConditionedBy= 15,                    -- MI Conditioned be (Condition for a mutual influence truthfullness scope)
		NotInfluencedBy= 16,                  -- MI Not influenced by (Condition not influencing a mutual influence truthfullness)
};

lm.codes.CFQuantifierHistogramValueType = {
		Abs= 1,                               -- Absolute number (Absolute frequencies. Frequencies in histogram are left as given.)
		RelCondition= 2,                      -- Relative [%] to act condition (Relative frequencies to number of rows matching condition. Frequencies are divided by number of rows matching condition and multiplied by 100.)
		RelCategory= 3,                       -- Relative [%] for each category (Relative frequencies for each category (number of rows matching condition to number of all). Each frequency is divided by the corresponding frequency in the whole matrix and multiplied by 100.)
};

lm.codes.CFQuantifierStepCountType = {
		Abs= 1,                               -- Absolute number (Absolute number of steps. Count value is left as given.)
		RelRange= 2,                          -- Relative [%] to act range (Relative to number of categories in the currently selected range- 1. Count value is multiplied by ('number of categories in current range minus 1')/100)
		RelAll= 3,                            -- Relative [%] to all categories (Relative to number of all categories minus 1. Count value is multiplied by ('total number of categories minus 1')/100)
};

lm.codes.CFQuantifierStepSizeType = {
		Abs= 1,                               -- Absolute number (Change in frequency as an absolute number. Minimal step size is left as given.)
		RelFrequencyPrev= 2,                  -- Relative [%] to previous frequency (Relative to the previous frequency. Minimal step size is multiplied by (frequency of the previous category)/100)
		RelAll= 3,                            -- Relative [%] to all objects (Relative to number of all rows in the data matrix. Minimal step size is multiplied by (number of rows in the whole matrix)/100)
		RelCondition= 4,                      -- Relative [%] to act condition (Relative to number of rows matching condition. Minimal step size is multiplied by (number of rows matching condition)/100)
		RelFrequencyMax= 5,                   -- Relative [%] to max frequency (Relative to maximal frequency in the currently processed histogram. Minimal step size is multiplied by (the highest frequency in the whole histogram)/100)
};

lm.codes.CFQuantifierType = {
		Sum= 1,                               -- Sum of frequencies (Sum of frequencies from range of categories)
		Min= 2,                               -- Min frequency (Minimal frequency from range of categories)
		Max= 3,                               -- Max frequency (Maximal frequency from range of categories)
		Avg= 4,                               -- Average frequency (Average frequency from range of categories)
		Some= 5,                              -- Some frequency (At least one frequency from range of categories)
		VariationRatio= 8,                    -- Variation ratio (Variation ratio = 1-f(modal))
		NominalVariation= 9,                  -- Nominal variation (norm) (Nominal variation (norm) = suma(f_i*(1-f_i)) * K/(K-1), where f_i is frequency of the i-th category and K is number of categories)
		DiscreteOrdinaryVariation= 10,        -- Discrete ordinary variation (norm) (Discrete Ordinary Variation (norm) = 2*suma(F_i*(1-F_i))* 2/(K-1), where F_i is cumulative relative frequency of the i-th category and K is number of categories)
		MedianIA= 19,                         -- Median-category index (absolute) (Index (absolute <1;K>) of the median category)
		MedianIR= 20,                         -- Median-category index (relative) (Index (relative <0;1>) of the median category)
		ArithmeticAverage= 11,                -- Arithmetic average (Arithmetic average of cardinal values. Only for cardinal attributes.)
		GeometricAverge= 12,                  -- Geometric average (Geometric average of cardinal values. Only for cardinal attributes.)
		Variance= 13,                         -- Variance (Variance of cardinal values. Only for cardinal attributes.)
		StDev= 14,                            -- Standard deviation (Standard deviation of cardinal values. Only for cardinal attributes.)
		Skewness= 15,                         -- Skewness (Skewness of distribution of cardinal values. Only for cardinal attributes.)
		Asymetry= 16,                         -- Asymetry (Asymetry coeficient of distribution of cardinal values. Only for cardinal attributes.)
		StepsUp= 17,                          -- Steps-up (Number of steps-up in frequency of adjectant categories from given range in histogram)
		StepsDown= 18,                        -- Steps-down (Number of steps-down in frequency of adjectant categories from given range in histogram)
		PattDiffSum= 21,                      -- PattDiffSum (Sum of absolute values of differences of frequencies in the histogram and a given pattern)
		PattDiffMin= 22,                      -- PattDiffMin (The minimal of absolute values of differences of frequencies in the histogram and a given pattern)
		PattDiffMax= 23,                      -- PattDiffMax (The maximal of absolute values of differences of frequencies in the histogram and a given pattern)
		Var= 6,                               -- Variation from pattern (Total variation from given pattern)
};

lm.codes.CFQuantifierValueType = {
		Abs= 4,                               -- Absolute number (Absolute number. Threshold value is left as given.)
		RelCondition= 1,                      -- Relative [%] to act condition (Relative to number of rows matching condition. Threshold value [%] is multiplied by (number of rows matching condition)/100)
		RelAll= 2,                            -- Relative [%] to all objects (Relative to number of all rows in the data matrix. Threshold value [%] is multiplied by (number of rows in the whole matrix)/100)
		RelFrequencyMax= 3,                   -- Relative [%] to max frequency (Relative to maximal frequency in the whole histogram. Threshold value [%] is multiplied by (the highest frequency in the whole histogram)/100)
};

lm.codes.CoefficientType = {
		Subset= 1,                            -- Subsets (All the subsets of categories from minimal up to maximal length)
		OneCategory= 2,                       -- One category (Only one selected category appears in literal)
		Sequence= 3,                          -- Sequences (All the consecutive sequencies of categories from minimal up to maximal length)
		CyclicalSequence= 10,                 -- Cyclical sequences (Same as the sequence plus overlapping combinations of first and last categories)
		Cuts= 4,                              -- Cuts (All the cuts of categories from minimal up to maximal length)
		LeftCut= 5,                           -- Left cuts (All the left cuts of categories from minimal up to maximal length)
		RightCut= 6,                          -- Right cuts (All the right cuts of categories from minimal up to maximal length)
};

lm.codes.CompareType = {
		Equal= 1,                             -- Equal (Equal value)
		Less= 2,                              -- Less than (Less than)
		LessOrEqual= 3,                       -- Less than or equal (Less than or equal)
		Greater= 4,                           -- Greater than (Greater than)
		GreaterOrEqual= 5,                    -- Greater than or equal (Greater than or equal)
		NotEqual= 6,                          -- Not equal (Not equal value)
};

lm.codes.DataColumnSubType = {
		Ordinary= 1,                          -- Ordinary DB field (Ordinary database column)
		Derived= 2,                           -- Derived (Derived column by expression)
		SQLQuery= 7,                          -- SQL-query (Column computed as an SQL query)
		Geo= 8,                               -- Geo (Column computed as a geographical relation of a point to a set of points or polygons)
		DatePart= 4,                          -- Date-time partial value (A single partial value derived from the DateTime column)
		MCField= 3,                           -- Multi-column field (One field of a multi-column)
		Hypothesis= 5,                        -- Task-results derived value (Derived column based on results of a hypothesis)
		PCA= 6,                               -- Task-results derived value (One component of a Principal component analysis)
};

lm.codes.DataCharacterType = {
		Nominal= 2,                           -- Nominal (Nominal values)
		Ordinal= 3,                           -- Ordinal (Ordinal values with an order defined)
		Cardinal= 4,                          -- Cardinal (Cardinal values with a distance defined)
		NotSet= 1,                            -- Not set (Unknown character of values)
};

lm.codes.DataTableSubType = {
		Table= 1,                             -- Stored table (Data statically stored in database table)
		View= 2,                              -- Dynamic view (Dynamically created view from (multiple) database tables)
};

lm.codes.DatePartSubType = {
		Year= 2,                              -- Year (Year-value of the date)
		Month= 3,                             -- Month (Month-value of the date)
		Day= 4,                               -- Day (Day-value from of the date)
		Hour= 5,                              -- Hour (Hour-value of the time)
		Min= 6,                               -- Min (Minutes-value of the time)
		Sec= 7,                               -- Sec (Seconds-value of the time)
		DayOfWeek= 8,                         -- DayOfWeek (Day of the week of the date)
		DayOfYear= 9,                         -- DayOfYear (Day of the year of the date)
		WeekOfYear= 10,                       -- WeekOfYear (Week of the year of the date)
		Quarter= 11,                          -- Quarter (Quarter of the year of the date)
		DayOfRange= 12,                       -- DayOfRange (Day index within the min-max range of dates in the corresponding column)
		MonthOfRange= 13,                     -- MonthOfRange (Month index within the min-max range of dates in the corresponding column)
		NotSet= 1,                            -- Not set (Not applicable to this attribute)
};

lm.codes.DCQuantifierStepCountType = {
		Abs= 1,                               -- Absolute number (Absolute number of steps. Count value is left as given.)
		RelRange= 2,                          -- Relative [%] to act range (Relative to number of categories in the currently selected range- 1. Count value is multiplied by ('number of categories in current range minus 1')/100)
		RelAll= 3,                            -- Relative [%] to all categories (Relative to number of all categories minus 1. Count value is multiplied by ('total number of categories minus 1')/100)
};

lm.codes.DCQuantifierStepSizeType = {
		Abs= 1,                               -- Absolute number (Change in frequency as an absolute number. Minimal step size is left as given.)
		RelFrequencyPrev= 2,                  -- Relative [%] to previous frequency (Relative to the previous frequency. Minimal step size is multiplied by (frequency of the previous category)/100)
		RelAll= 3,                            -- Relative [%] to all objects (Relative to number of all rows in the data matrix. Minimal step size is multiplied by (number of rows in the whole matrix)/100)
		RelCondition= 4,                      -- Relative [%] to act condition (Relative to number of rows matching condition. Minimal step size is multiplied by (number of rows matching condition)/100)
		RelFrequencyMax= 5,                   -- Relative [%] to max frequency (Relative to maximal frequency in the currently processed histogram. Minimal step size is multiplied by (the highest frequency in the whole histogram)/100)
};

lm.codes.DCQuantifierType = {
		Sum= 1,                               -- Sum of frequencies (Sum of frequencies from range of categories)
		Min= 2,                               -- Min frequency (Minimal frequency from range of categories)
		Max= 3,                               -- Max frequency (Maximal frequency from range of categories)
		Avg= 4,                               -- Average frequency (Average frequency from range of categories)
		Some= 5,                              -- Some frequency (At least one frequency from range categories)
		VariationRatio= 8,                    -- Variation ratio (Variation ratio = 1-f(modal))
		NominalVariation= 9,                  -- Nominal variation (norm) (Nominal variation (norm) = suma(f(i)*(1-f(i))) * K/(K-1))
		DiscreteOrdinaryVariation= 10,        -- Discrete ordinary variation (norm) (Discrete Ordinary Variation (norm) = 2*suma(F(i)*(1-F(i))* 2/(K-1))
		ArithmeticAverage= 11,                -- Arithmetic average (Arithmetic average of cardinal values)
		GeometricAverage= 12,                 -- Geometric average (Geometric average of cardinal values)
		Variance= 13,                         -- Variance (Variance of cardinal values)
		StandardDeviation= 14,                -- Standard deviation (Standard deviation of cardinal values)
		Skewness= 15,                         -- Skewness (Skewness of distribution of cardinal values)
		Asymetry= 16,                         -- Asymetry (Asymetry coeficient of distribution of cardinal values)
		StepsUp= 17,                          -- Steps-up (Number of steps-up in frequency of adjectant categories in histogram)
		StepsDown= 18,                        -- Steps-down (Number of steps-down in frequency of adjectant categories in histogram)
		Var= 6,                               -- Variation from pattern (Total variation from given pattern)
};

lm.codes.DCQuantifierValueType = {
		Abs= 4,                               -- Absolute number (Absolute number. Threshold value is left as given.)
		RelCondition= 1,                      -- Relative [%] to act condition (Relative to number of rows matching condition. Threshold value [%] is multiplied by (number of rows matching condition)/100)
		RelAll= 2,                            -- Relative [%] to all objects (Relative to number of all rows in the data matrix. Threshold value [%] is multiplied by (number of rows in the whole matrix)/100)
		RelFrequencyMax= 3,                   -- Relative [%] to max frequency (Relative to maximal value in the current contingency table. Threshold value [%] is multiplied by (the highest frequency in the whole histogram)/100)
};

lm.codes.DFQuantifierType = {
		Sum= 1,                               -- Sum of frequencies (Sum of frequencies from source contingency table)
		Min= 2,                               -- Min frequency (Minimal frequency from source contingency table)
		Max= 3,                               -- Max frequency (Maximal frequency from source contingency table)
		PImplication= 4,                      -- p-Implication (a/(a+b) >= p ... at least 100*p [%] of objects satisfying A satisfy also S)
		AverageDifference= 28,                -- Average Difference Dependence (Relative difference in number of objects satisfying S among objects satisfying A to number objects saysfying S in the whole data matrix. Paramater p in <-1;inf), similar to the Lift(X->Y)= P(Y|X)/P(Y). It holds p= P(Y|X)/P(Y)-1.)
		AboveAverage= 5,                      -- Above Average Dependence (Among objects satisfying A there are at least 100*p [%] more objects satisfying S than there are objects satisfying S in the whole data matrix. Parameter p in <0;inf).)
		BelowAverage= 6,                      -- Below Average Dependence (Among objects satisfying A there are at least 100*p [%] less objects satisfying S than there are objects satisfying S in the whole data matrix. Parameter p in <0;1>.)
		OAD= 29,                              -- Outside Average Dependence (Among objects satisfying A, there is at least 100*p [%] more or less objects satisfying S than there are objects satisfying S in the whole data matrix. Parameter p in <0;1>.)
		LowerCriticalImplication= 7,          -- Lower Critical Implication (The binomical test rejects on the level alpha the null hypothesis P(S|A)<=p in favour of alternative P(S|A)>p)
		UpperCriticalImplication= 8,          -- Upper Critical Implication (The binomical test does not reject on the level alpha the null hypothesis P(S|A)<=p in favour of alternative P(S|A)>p)
		DoublePImplication= 9,                -- Double p-Implication (a/(a+b+c) >= p ... at least 100*p [%] of objects satisfying A or S satisfy both A and S)
		DoubleLowerCriticalImplication= 10,   -- Double Lower Critical Implication (The binomical test rejects on the level alpha the null hypothesis P(AandS|AorS)<=p in favour of alternative P(AandS|AorS)>p)
		DoubleUpperCriticalImplication= 11,   -- Double Upper Critical Implication (The binomical test does not reject on the level alpha the null hypothesis P(AandS|AorS)<=p in favour of alternative P(AandS|AorS)>p)
		PEquivalence= 12,                     -- p-Equivalence ((a+d)/n >= p ... at least 100*p [%] objects have the same truth value for A and S)
		LowerCriticalEquivalence= 13,         -- Lower Critical Equivalence (The binomical test rejects on the level alpha the null hypothesis P(A and S have the same truth value)<=p in favour of alternative P(A and S have the same truth value)>p)
		UpperCriticalEquivalence= 14,         -- Upper Critical Equivalence (The binomical test does not reject on the level alpha the null hypothesis P(A and S have the same truth value)<=p in favour of alternative P(A and S have the same truth value)>p)
		SimpleDeviation= 15,                  -- Simple Deviation (a*d > exp(sigma)*b*c)
		Fisher= 16,                           -- Fisher quantifier (The one-sided Fisher test rejects on the level alpha the null hypothesis of independence of A and S in favour of the alternative of their positive logarithmic interaction)
		ChiSq= 17,                            -- Chi-Squared quantifier (The one-sided Fisher test asymptotically rejects on the level alpha the null hypothesis of independence of A and S in favour of the alternative of their positive logarithmic interaction)
		AQ= 18,                               -- A-quantifier
		EQ= 19,                               -- E-quantifier
		afrequency= 20,                       -- a-frequency (a-frequency (BASE) from source contingency table)
};

lm.codes.DFQuantifierValueType = {
		Abs= 4,                               -- Absolute number (Absolute number. Threshold value is left as given.)
		RelCondition= 1,                      -- Relative [%] to act condition (Relative to number of rows matching condition. Threshold value [%] is multiplied by (number of rows matching condition)/100)
		RelAll= 2,                            -- Relative [%] to all objects (Relative to number of all rows in the data matrix. Threshold value [%] is multiplied by (number of rows in the whole matrix)/100)
		RelFrequencyMax= 3,                   -- Relative [%] to max frequency (Relative to maximal value in the current contingency table. Threshold value [%] is multiplied by (the highest frequency)/100)
};

lm.codes.DKQuantifierType = {
		Sum= 1,                               -- Sum of frequencies (Sum of frequencies from given part of source contingency table)
		Min= 4,                               -- Min frequency (Minimal frequency from given part of source contingency table)
		Max= 5,                               -- Max frequency (Maximal frequency from given part of source contingency table)
		Avg= 6,                               -- Average frequency (Average frequency from given part of source contingency table)
		Some= 7,                              -- Some frequency (At least one frequency from given part of source contingency table)
		CramerV= 16,                          -- Cramer's V coefficient (Cramer's V (association of two nominal variables) in <0;1> (the farther is value from 0 the more dependant))
		Kendall= 14,                          -- Kendall's TauB coefficient (Value of TauB in <-1;1> (the farther is value from 0 the more dependant))
		ChiSq= 8,                             -- Chi-square test (Chi-square test of similarity (the greater value the more dependant))
		ConditionalEntropy= 11,               -- Conditional entropy H(C|R) (Conditional entropy of columns given rows (the lower value the more dependant <0;log2(L)>))
		MutualInformation= 13,                -- Mutual information MI(R,C) normalized (Mutual information between rows and columns (the greater value the more dependant <0;1>))
		InformationDependence= 12,            -- Inf. dependence ID(R,C) (Information dependence between rows and columns (the greater value the more dependant <0;1>))
		AsymetricInformation= 15,             -- Asymetric information coefficient AIC(R,C) (Value of asymetric information coefficient Theta (the greater value the more dependant <0;1>))
};

lm.codes.DKQuantifierValueType = {
		Abs= 4,                               -- Absolute number (Absolute number. Threshold value is left as given.)
		RelCondition= 1,                      -- Relative [%] to act condition (Relative to number of rows matching condition. Threshold value [%] is multiplied by (number of rows matching condition)/100)
		RelAll= 2,                            -- Relative [%] to all objects (Relative to number of all rows in the data matrix. Threshold value [%] is multiplied by (number of rows in the whole matrix)/100)
		RelFrequencyMax= 3,                   -- Relative [%] to max frequency (Relative to maximal frequency in the current contingency table. Threshold value [%] is multiplied by (the highest frequency in the whole KL-table)/100)
};

lm.codes.FTQuantifierType = {
		Support= 17,                          -- Support (a/(a+b+c+d) >= p ... at least 100*p [%] of objects satisfy both A and S)
		PImplication= 1,                      -- p-Implication (a/(a+b) >= p ... at least 100*p [%] of objects satisfying A satisfy also S)
		AboveAverage= 15,                     -- Above Average Dependence (Among objects satisfying A, there is at least 100*p [%] more objects satisfying S than there are objects satisfying S in the whole data matrix. Parameter p in <0;inf).)
		BelowAverage= 16,                     -- Below Average Dependence (Among objects satisfying A, there is at least 100*p [%] less objects satisfying S than there are objects satisfying S in the whole data matrix. Parameter p in <0;1>.)
		OAD= 32,                              -- Outside Average Dependence (Among objects satisfying A, there is at least 100*p [%] more or less objects satisfying S than there are objects satisfying S in the whole data matrix. Parameter p in <0;1>.)
		AverageDifference= 31,                -- Average Difference Dependence (Relative difference in number of objects satisfying S among objects satisfying A to number objects saysfying S in the whole data matrix. Paramater p in <-1;inf), similar to the Lift(X->Y)= P(Y|X)/P(Y). It holds p= P(Y|X)/P(Y)-1.)
		LowerCriticalImplication= 2,          -- Lower Critical Implication (The binomical test rejects on the level alpha the null hypothesis P(S|A)<=p in favour of alternative P(S|A)>p)
		UpperCriticalImplication= 3,          -- Upper Critical Implication (The binomical test does not reject on the level alpha the null hypothesis P(S|A)<=p in favour of alternative P(S|A)>p)
		DoublePImplication= 4,                -- Double p-Implication (a/(a+b+c) >= p ... at least 100*p [%] of objects satisfying A or S satisfy both A and S)
		DoubleLowerCriticalImplication= 5,    -- Double Lower Critical Implication (The binomical test rejects on the level alpha the null hypothesis P(AandS|AorS)<=p in favour of alternative P(AandS|AorS)>p)
		DoubleUpperCriticalImplication= 6,    -- Double Upper Critical Implication (The binomical test does not reject on the level alpha the null hypothesis P(AandS|AorS)<=p in favour of alternative P(AandS|AorS)>p)
		PEquivalence= 7,                      -- p-Equivalence ((a+d)/n >= p ... at least 100*p [%] objects have the same truth value for A and S)
		LowerCriticalEquivalence= 8,          -- Lower Critical Equivalence (The binomical test rejects on the level alpha the null hypothesis P(A and S have the same truth value)<=p in favour of alternative P(A and S have the same truth value)>p)
		UpperCriticalEquivalence= 9,          -- Upper Critical Equivalence (The binomical test does not reject on the level alpha the null hypothesis P(A and S have the same truth value)<=p in favour of alternative P(A and S have the same truth value)>p)
		SimpleDeviation= 10,                  -- Simple Deviation (a*d > exp(delta)*b*c)
		Fisher= 11,                           -- Fisher quantifier (The one-sided Fisher test rejects on the level alpha the null hypothesis of independence of A and S in favour of the alternative of their positive logarithmic interaction)
		ChiSq= 12,                            -- Chi-Square quantifier (The Chi-Square test asymptotically rejects on the level alpha the null hypothesis of independence of A and S in favour of the alternative of their positive logarithmic interaction)
		EQ= 14,                               -- E-quantifier
		ParaSeparation= 40,                   -- Paraconsistent separation (Paraconsistent separation quantifier looking for (almost) separate A and S with truth-criterion of (1+p)*a<=b+c. It is recommend also to set-up a simple-frequency quantifier for (b+c) to assure some minimal sample size.)
		BASE= 18,                             -- BASE (a >= BASE ... at least BASE-number of objects for dependency to be statistically relevant)
		CEIL= 19,                             -- Ceiling (a <= CEIL ... not more than CEIL-number of objects (i.e. not too 'obvious' dependency))
		afrequency= 20,                       -- a-frequency (a-frequency from contingency table)
		bfrequency= 21,                       -- b-frequency (b-frequency from contingency table)
		cfrequency= 22,                       -- c-frequency (c-frequency from contingency table)
		dfrequency= 23,                       -- d-frequency (d-frequency from contingency table)
		rfrequency= 24,                       -- r-frequency (r-frequency (a+b) from contingency table)
		sfrequency= 25,                       -- s-frequency (s-frequency (c+d) from contingency table)
		kfrequency= 26,                       -- k-frequency (k-frequency (a+c) from contingency table)
		lfrequency= 27,                       -- l-frequency (l-frequency (b+d) from contingency table)
		adfrequency= 41,                      -- ad-frequency (ad-frequency (a+d) from contingency table)
		bcfrequency= 42,                      -- bc-frequency (bc-frequency (b+c) from contingency table)
		Sum= 28,                              -- Sum of values (Sum of frequencies (n) from contingency table)
		Min= 29,                              -- Min value (Minimal frequency from contingency table)
		Max= 30,                              -- Max value (Maximal frequency from contingency table)
		FreqDiffVal= 33,                      -- Frequency difference (Frequency of corresponding category in histogram minus number of rows matching both antecedent and succedent)
		FreqDiffRel= 34,                      -- Relative frequencies difference (Difference of relative frequency of a corresponding category in histogram and confidence)
		FreqDiffRelAbs= 35,                   -- Absolute value of relative frequencies difference (Absolute value of difference of relative frequency of a corresponding category in histogram and confidence)
		FreqDiffRelRatio= 36,                 -- Ratio of relative frequencies (Ratio of relative frequency in histogram to relative frequency of succedent in rows matching antecedent (i.e. "inverse Lift"))
		FreqDiffCat= 37,                      -- Relative frequencies of category difference (Difference of relative frequency of category in histogram to the frequency of this category in the whole data and relative frequency of rows matching both antecedent and succedent to frequency of category in the whole data)
		FreqDiffCatAbs= 38,                   -- Absolute value of relative frequencies of category difference (Absolute value of difference of relative frequency of category in histogram to the frequency of this category in the whole data and relative frequency of rows matching both antecedent and succedent to frequency of category in the whole data)
		FreqDiffCatRatio= 39,                 -- Ratio of relative frequencies of category (Ratio of relative frequency of category in histogram to the frequency of this category in the whole data and relative frequency of rows matching both antecedent and succedent to frequency of category in the whole data)
};

lm.codes.FTQuantifierValueType = {
		Abs= 4,                               -- Absolute number (Absolute number. Threshold value is left as given.)
		RelCondition= 1,                      -- Relative [%] to act condition (Relative to number of rows matching condition. Threshold value [%] is multiplied by (number of rows matching condition)/100)
		RelAll= 2,                            -- Relative [%] to all objects (Relative to number of all rows in the data matrix. Threshold value [%] is multiplied by (number of rows in the whole matrix)/100)
		RelFrequencyMax= 3,                   -- Relative [%] to max frequency (Relative to maximal frequency in the current contingency table. Threshold value [%] is multiplied by (the highest frequency)/100)
};

lm.codes.GaceType = {
		Positive= 1,                          -- Positive (Positive gace)
		Negative= 2,                          -- Negative (Negative gace (negation))
		Both= 3,                              -- Both (Both (positive and negative))
};

lm.codes.GeoColumnSubType = {
		InPolygonName= 2,                     -- In-Polygon name (Name of the polygon the coordinates are within)
		PointName= 3,                         -- Closest-Point name (Name of the closest point to the coordinates)
		PointDistance= 4,                     -- Closest-Point distance (Distance [km] from the coordinates to the the closest point)
		PointCount= 5,                        -- Point-number (Number of points within a distance [km] from the coordinates (distance given by a threshold value))
		NotSet= 1,                            -- Not set (Not applicable to this attribute)
};

lm.codes.GeoDistanceType = {
		Euclidean= 2,                         -- Euclidean (Euclidean distance of cartesian planar coordinates.)
		Cylindrical= 3,                       -- Cylindrical (Euclidean distance on cylindrical projection of geographical coordinates (WGS84) and transformed into kilometers. Applicable for points up to 500 km apart and within latitudes of 70N and 70S.)
		Haversine= 4,                         -- Haversine (Haversine formula for computing distances on the sphere for geographical coordinates (WGS84) and transformed into kilometers. The better precison for large distances on the Earth, but slowest.)
		NotSet= 1,                            -- Not set (Not applicable to this attribute)
};

lm.codes.InfinityType = {
		Finite= 1,                            -- Finite value (Finite value (not infinity))
		PlusInfinity= 2,                      -- Plus infinity (Plus infinity value)
		MinusInfinity= 3,                     -- Minus infinity (Minus infinity value)
};

lm.codes.IntervalValueType = {
		From= 1,                              -- From (Left border value)
		To= 2,                                -- To (Right border value)
		FuzzyFromMin= 3,                      -- Fuzzy from (min) (First left fuzzy border value)
		FuzzyFromMax= 4,                      -- Fuzzy from (max) (Second left fuzzy border value)
		FuzzyToMin= 5,                        -- Fuzzy to (min) (First right fuzzy border value)
		FuzzyToMax= 6,                        -- Fuzzy to (max) (Second right fuzzy border value)
};

lm.codes.KLQuantifierKLTableValueType = {
		Abs= 1,                               -- Absolute number (Absolute frequencies. Frequencies in histogram are left as given.)
		RelCondition= 2,                      -- Relative [%] to act condition (Relative frequencies to number of rows matching condition. Frequencies are divided by number of rows matching condition and multiplied by 100.)
		RelRow= 3,                            -- Relative [%] for each row (Relative frequencies for each row. Each frequency is divided by the sum of frequencies in its row and multiplied by 100.)
		RelCol= 4,                            -- Relative [%] for each column (Relative frequencies for each column. Each frequency is divided by the sum of frequencies in its column and multiplied by 100.)
};

lm.codes.KLQuantifierType = {
		Sum= 1,                               -- Sum of frequencies (Sum of frequencies from given part of contingency table)
		Min= 2,                               -- Min frequency (Minimal frequency from given part of contingency table)
		Max= 3,                               -- Max frequency (Maximal frequency from given part of contingency table)
		Avg= 4,                               -- Average frequency (Average frequency from given part of contingency table)
		Some= 5,                              -- Some frequency (At least one frequency from given part of contingency table)
		CramerV= 16,                          -- Cramer's V coefficient (Cramer's V (association of two nominal variables) in <0;1> (the farther is value from 0 the more dependant))
		Kendall= 14,                          -- Kendall's TauB coefficient (Kendall's TauB (coefficient of ordinal correlation of two variables) in <-1;1> (the farther is value from 0 the more dependant))
		ChiSq= 7,                             -- Chi-square test (Chi-square test of similarity (the greater value the more dependant))
		Variation= 6,                         -- Variation from pattern (Total variation from pattern)
		ConditionalEntropy= 10,               -- Conditional entropy H(C|R) (Conditional entropy of columns given rows (the lower value the more dependant <0;log2(L)>))
		MutualInformation= 13,                -- Mutual information MI(R,C) normalized (Mutual information between rows and columns (the greater value the more dependant <0;1>))
		InformationDependence= 11,            -- Inf. dependence ID(R,C) (Information dependence between rows and columns (the greater value the more dependant <0;1>))
		AsymetricInformation= 15,             -- Asymetric information coefficient AIC(R,C) (Value of asymetric information coefficient Theta (the greater value the more dependant <0;1>))
		PattDiffSum= 17,                      -- PattDiffSum (Sum of absolute values of differences of frequencies in the contingency table and a given pattern)
		PattDiffMin= 18,                      -- PattDiffMin (The minimal of absolute values of differences of frequencies in the contingency table and a given pattern)
		PattDiffMax= 19,                      -- PattDiffMax (The maximal of absolute values of differences of frequencies in the contingency table and a given pattern)
};

lm.codes.KLQuantifierValueType = {
		Abs= 4,                               -- Absolute number (Absolute number. Threshold value is left as given.)
		RelCondition= 1,                      -- Relative [%] to act condition (Relative to number of rows matching condition. Threshold value [%] is multiplied by (number of rows matching condition)/100)
		RelAll= 2,                            -- Relative [%] to all objects (Relative to number of all rows in the data matrix. Threshold value [%] is multiplied by (number of rows in the whole matrix)/100)
		RelFrequencyMax= 3,                   -- Relative [%] to max frequency (Relative to maximal frequency in the whole contingency table. Threshold value [%] is multiplied by (the highest frequency in the whole KL-table)/100)
};

lm.codes.LaqMapType = {
		Antecedent= 1,                        -- Antecedent (Mapping attributes to antecedent)
		Succedent= 2,                         -- Succedent (Mapping attributes to succedent)
		Condition= 3,                         -- Condition (Mapping attributes to condition)
		FirstSet= 4,                          -- FirstSet (Mapping attributes to the firstset)
		SecondSet= 5,                         -- SecondSet (Mapping attributes to the secondset)
		Quantifier= 6,                        -- Quantifier (Mapping of quantifier)
		Filter= 7,                            -- Filter (Mapping of filtering)
};

lm.codes.LaqPatternGridFlagType = {
		NotSet= 1,                            -- Not set (Influence not set yet)
		DontCare= 2,                          -- Don't care (Not interested in this combination)
		ToBeMined= 3,                         -- To be mined (Waiting for to be mined)
		Processed= 4,                         -- Being processed (Beeing processed)
		Solved= 5,                            -- Solved (Results obtained)
};

lm.codes.LaqTaskType = {
		FTMiner= 1,                           -- 4ftMiner (4ftMiner Task)
		CFMiner= 2,                           -- CF-Miner (CF-Miner Task)
		KLMiner= 3,                           -- KL-Miner (KL-Miner Task)
		SD4ftMiner= 4,                        -- SD4ft-Miner (SD4ft-Miner Task)
		SDCFMiner= 5,                         -- SDCF-Miner (SDCF-Miner Task)
		SDKLMiner= 6,                         -- SDKL-Miner (SDKL-Miner Task)
};

lm.codes.LiteralType = {
		Basic= 1,                             -- Basic (Literal must be included in every cedent)
		Remaining= 2,                         -- Remaining (Literal is obligatory in cedent)
};

lm.codes.MCAlgorithmType = {
		KMeans= 1,                            -- k-Means / k-Mode (Flat level k-Means or k-Mode clustering)
		RBKMeans= 2,                          -- Repeated bisection k-Means / k-Mode (Top-down recursive bi-section clustering producing a tree of clusters)
		HAC= 3,                               -- Hierarchical Agglomerative Clustering (Bottom-up hierarchical agglomerative clustering using distance matrix)
};

lm.codes.MCCenterType = {
		CatMean= 1,                           -- Mean (Mean of category-index values)
		CatModus= 2,                          -- Modus (The most frequent category)
};

lm.codes.MCDistanceType = {
		Euclidean= 1,                         -- Euclidean distance (Euclidean measure of distance between two objects)
		Cosinus= 2,                           -- Cosinus similarity (Cosinus measure of similarity between two objects)
		SimpleMatch= 3,                       -- Simple match (Simple match of categories (Sokal and Michener))
		Eskin= 4,                             -- Eskin measure (Esking similarity for nominal variables (Eskin et al.))
		VariableEntropy= 5,                   -- Variable Entropy (Variable Entropy similarity measure of nominal variables (Sulc))
		VariableMutability= 6,                -- Variable Mutability (Variable Mutability similarity measure of nominal variables (Sulc))
};

lm.codes.MCLinkageType = {
		Simple= 1,                            -- Simple (Simple linkage of clusters (the minimal distance))
		Complete= 2,                          -- Complete (Complete linkage of clusters (the maximal distance))
		Average= 3,                           -- Average (Average linkage of clusters (the average distance))
};

lm.codes.MissingsType = {
		Deleting= 1,                          -- Delete (Not including missing values)
		Pesimistic= 2,                        -- Pesimistic fill up (Pesimistic fill up of missing values)
		Optimistic= 3,                        -- Optimistic fill up (Pesimistic fill up of missing values)
		Ignore= 4,                            -- Ignore X-categories (Ignoring X-categories)
};

lm.codes.MutualInfluenceScopeType = {
		NotSet= 1,                            -- Not set (Scope not set yet)
		BackgroundKnowledge= 3,               -- Background knowledge (Dependency follows from the domain background knowledge)
		DataSpecific= 4,                      -- Data specific (Dependency follows from data anomalies)
		Unknown= 2,                           -- Unknown (Scope is unknown)
};

lm.codes.MutualInfluenceType = {
		NotSet= 1,                            -- Not set (Influence not set yet)
		SomeInfluence= 5,                     -- Some influence (There is some influence but not examined in detail)
		PositiveInfluence= 6,                 -- Positive influence (If the row attribute increases then the column attribute increases too)
		NegativeInfluence= 7,                 -- Negative influence (If the row attribute increases then the column attribute decreases)
		PositiveFrequency= 8,                 -- Positive frequency (If the row attribute increases then the relative frequency of objects satisfying column attribute increases)
		NegativeFrequency= 9,                 -- Negative frequency (If the row attribute increases then the relative frequency of objects satisfying column attribute decreases)
		PositiveBoolean= 10,                  -- Positive boolean (If truthfulness of the row attribute increases then relative frequency of true values of column attribute increases too)
		NegativeBoolean= 11,                  -- Negative boolean (If truthfulness of the row attribute increases then relative frequency of true values of column attribute decreases)
		Functional= 12,                       -- Functional (There is a strong function-like dependency)
		None= 2,                              -- None (No influence at all)
		DontCare= 3,                          -- Don't care about influence (There maybe some influence but we don't care)
		Unknown= 4,                           -- Unknown (There could be an influence, no details are known)
};

lm.codes.MutualInfluenceValidityType = {
		NotSet= 1,                            -- Not set (Validity not set yet)
		Proven= 3,                            -- Proven (Dependency proven)
		Rejected= 4,                          -- Rejected (Dependency was rejected)
		Unknown= 2,                           -- Unknown (Validity not know)
};

lm.codes.QuantityBinarizeType = {
		None= 1,                              -- None (Not set)
		EqualNotEqual= 2,                     -- Equal versus Not-equal (One category against all others. As many dichotimized attributes with categories '=' and '<>' as there is categories in the original attribute. Suitable for nominal attributes.)
		UpToAbove= 3,                         -- Up-to versus Above (Disjunction of all categories up to a certain category against all other categories. As many dichotomized attributes with categories '<=' and '>' as there is categories in the original attribute minus one. Suitable for ordinal and cardinal attributes.)
};

lm.codes.RMAssignType = {
		Random= 1,                            -- Random (Column values generated randomly)
		Init= 2,                              -- Initialized by formula (Column values initially computed by a mathematical formula)
		Update= 3,                            -- Updated by formula (Column values continuously updated by a mathematical formula)
		Copy= 4,                              -- Copied from the underlying data (Column values initialized by copying values from the underlying data)
};

lm.codes.RMCaseType = {
		Evolution= 1,                         -- Evolution (Generating artificial data using evolutionary algorithm)
		Randomizer= 2,                        -- Randomizer (Randomization of previously generated data using evolution algorithm)
};

lm.codes.RMDistributionType = {
		Uniform= 1,                           -- Uniform (Uniform distribution of values across possible range)
		Gaussian= 2,                          -- Gaussian (A bell-shaped distribution with defined mean value and standard deviation)
		Manually= 3,                          -- Manually user-specified (Manually specified frequencies (for enumerations only))
};

lm.codes.RMDiversityType = {
		Random= 1,                            -- Random (Randomly generated values for each individual)
		Permutation= 2,                       -- Permutation (Permutation of a one-time pregenerated random values)
};

lm.codes.RMCharibType = {
		Enumeration= 1,                       -- Enumeration (Column could contain values only from a pre-defined list)
		Range= 2,                             -- Range of values (Column with any value within a given range)
		RangeEnum= 3,                         -- Range with predefined values (Column with any value within a given range with some predefined values)
};

lm.codes.SDConstructionType = {
		Simple= 1,                            -- FirstSet versus SecondSet (Comparison of the first set versus the second set)
		JoinedSet= 2,                         -- FirstSet versus FirstSet and SecondSet (The second set is treated as a subset specification to the first set)
		InverseSet= 3,                        -- FirstSet versus not FirstSet (The second set is inverse of the first set)
};

lm.codes.SDQuantifierSourceType = {
		FirstSet= 1,                          -- First set frequencies (Quantifier test applied to the first set data only)
		SecondSet= 2,                         -- Second set frequencies (Quantifier test applied to the second set data only)
		DiffAbs= 3,                           -- Delta of absolute frequencies values (Quantifier test applied to the frequency table computed by substracting of corresponding frequencies)
		DiffRel= 4,                           -- Delta of relative frequencies values (Quantifier test applied to the frequency table computed by substracting of corresponding relative frequencies)
		ValDiff= 5,                           -- Difference of interest-measures (Test applied to the difference of quantifier values computed separately from each frequency table)
		ValDiffAbs= 6,                        -- Absolute difference of interest-measures (Test applied to the absolute difference of interest-measures computed separately from each frequency table)
		ValRation= 7,                         -- Ratio of interest-measures (Test applied to the ratio of interest-measures computed separately from each frequency table)
		ValRatioMax= 8,                       -- Higher of ratios of interest-measures (Test applied to the higher of two ratios of interest-measures (im1/im2 or im2/im1))
};

lm.codes.TaskSubType = {
		FTMiner= 1,                           -- 4ft-Miner (4ft-Miner task for 4ft-association rules with rich syntax)
		CFMiner= 7,                           -- CF-Miner (CF-Miner task for conditonal frequencies of a single multi-categorical attribute)
		KLMiner= 6,                           -- KL-Miner (KL-Miner task for conditional frequencies of two multi-categorical attributes)
		SD4ftMiner= 9,                        -- SD4ft-Miner (SD4ft-Miner task for set difference in terms of two 4ft-association rules)
		SDCFMiner= 10,                        -- SDCF-Miner (SDCF-Miner task for set difference in terms of two frequencies of a single attribute)
		SDKLMiner= 8,                         -- SDKL-Miner (SDKL-Miner task for set difference in terms of two frequencies of two multi-categorical attributes)
		Ac4ftMiner= 11,                       -- Ac4ft-Miner (Ac4ft-Miner task for 4ft-action rules)
		ETreeMiner= 12,                       -- ETree-Miner (ETree-Miner task for decision and exploration trees)
		MClusterMiner= 13,                    -- MCluster-Miner (MCluster-Miner task for clustering analysis)
		KEx= 3,                               -- Knowledge Explorer (Knowledge Explorer (KEx) task for classifications using machine learning)
};

lm.codes.TestingType = {
		TrainingSet= 1,                       -- Use training set (Use same records as for training)
		CrossValidation= 2,                   -- Cross-validation (Cross-validating each of n-folds)
		RandomSplit= 3,                       -- Random split (Random split of available data in given ration)
};

lm.codes.ValueSubType = {
		Integer= 1,                           -- Integer number (Integer number between -2E09 and 2E09)
		Float= 2,                             -- Decimal number (Floating-point number with double precision)
		String= 3,                            -- Text (String of characters)
		Boolean= 4,                           -- Boolean (Boolean value of TRUE/FALSE)
		DateTime= 5,                          -- Date/Time (Value with date, time or both)
};

