-- LISp-Miner Control Language script, for details see http://lispminer.vse.cz/lmcl
-- EverMiner Simple Demo

-- EverMinerSimple Metabase namespace
ems.metabase = {};

-- Data and metabase initialization function
function ems.metabase.createDataAndMetabase( inputParams)

--	lm.logIndentUp();

	-- Import a text file with data and create a MDB database with a given table
	importParams= {
		pathNameSrc= inputParams.pathNameDataSrc,				-- path and file name to source text file	
		pathNameDest= inputParams.pathNameDataDest,			-- path and file name of the database to create (optional)
		tableName= inputParams.tableName,						-- database table name to be created (optional)
	};
	lm.data.importTXT( importParams);
	
	-- Create new metabase and associate it with the previously created database with data
	-- an example of a "shorthand" without creating list of params first
	lm.metabase.createAndAssociateWithDataMDB({
		pathNameMetabase= inputParams.pathNameMetabase,		-- path and file name of the metabase to create
		pathNameData= inputParams.pathNameDataDest,			-- used data
		dsnBase= inputParams.dsnBase 								-- common ODBC DataSourceName for both metabase and data
	});

	-- Open a metabase 
	lm.metabase.open({
		dataSourceName= ems.metabase.getMetabaseDSN( inputParams)});
	
	-- Since it is the first this metabase is opened, we need to 
	-- initialize the meta data (list of tables and columns in analyzed data)
	-- This function needs to be called every time the structure of analyzed data changes
	lm.metabase.updateMetadata();

	lm.metabase.close();
	
	-- Create a backup copy for debug
	lm.metabase.backupMDB({
		pathNameSrc= inputParams.pathNameMetabase,
		pathNameDest= inputParams.pathNameMetabase.."_bkup.create.mdb"
	});
	
--	lm.logIndentDown();
	
end;

function ems.metabase.getMetabaseDSN( inputParams)
	return "LM "..inputParams.dsnBase.." MB";
end;

return ems.metabase;