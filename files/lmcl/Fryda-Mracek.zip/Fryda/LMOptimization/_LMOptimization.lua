--- IMPORTY
package.path = package.path..";"..lm.getScriptFolder().."?.lua"; -- Vyhledavat balicky take v aktualni slozce

local lm = require("Exec/Lib/LMGlobal");
require("config/Params");
require("OptimizationManager");
require("Output");

--- HLAVNI TELO SKRIPTU

lm.log("START of the script");
lm.metabase.open({dataSourceName = dataSourceName});

createNewReport();
for i,j in ipairs(config) do
	k = doTask(j);
	addToReport(j, k);
end
finishReport();

lm.metabase.close(); -- Uzavreni metabase a ukonceni skriptu
lm.log("END of the script");
