-- Vraci unarni funkci, ktera aplikuje unarni funkci "a" na vystup unarni funkce "b"
function combine(a,b)
    return function(x)
        return a(b(x))
    end
end

-- Provede redukci zleva doprava s pouzitim funkce fn na zbytek parametru
function foldl(fn, ...)
    local arg = {...}
    local val = arg[1]
    for i,f in ipairs(arg) do
        if i > 1 then
            val=fn(val,f)
        end
    end
    return val
end

-- -- funkce ktera byvala pouzita pro dependecy injection
-- function optimize(quant1,quant2)
-- 	return function(fun)
--     return fun(quant1,quant2)
-- 	end
-- end


-- unarni funkce, ktera vrati svuj parametr
function identity(coll)
	return coll
end

-- vraci true pokud a je podmnozina b
function isSubset(a,b)
	if a == nil then
		return true
	end
	if b == nil then
		return false
	end
	
	items = {}
	for _, elem in ipairs(b) do
		items[elem.Text] = true	
	end
	
	for _, elem in ipairs(a) do
		if not (items[elem.Text]) then
			return false
		end
	end
	return true
end

-- unarni funkce, ktera pri pravdivosti binarniho predikatu odebere prvni
-- argument predikatu
function removeUsingBinaryPredicate(coll, pred)
	local to_remove = {}
	for i, el1 in ipairs(coll) do
		for j, el2 in ipairs(coll) do
			if pred(el1, el2) and (i ~= j) then
				table.insert(to_remove, i)
				break
			end
		end
	end
  
	local idx = 1
	local res = {}
	for i, el in ipairs(coll) do
		if to_remove[idx] == i then
			idx = idx + 1
		else
			res[i-idx+1] = el
		end
	end
	return res
end

-- unarni funkce, ktera vraci funkci, ktera vrati prvnich N prvku z kolekce
function topN(N)
	return function(coll)
		local slice ={}
		for i, k in ipairs(coll) do
			if i>N then
				break
			end
		slice[i]=k
    end
    return slice
  end
end

-- ***** DALSI POMOCNE FUNKCE *****

local function removeHypothesisWithRedundantCondition(results)
	to_remove = {}

	for i, hypothesis in ipairs(results) do
		antRes = hypothesis.prepareFTPartialCedentArray({nCedentTypeCode = lm.codes.CedentType.Antecedent})
		sucRes = hypothesis.prepareFTPartialCedentArray({nCedentTypeCode = lm.codes.CedentType.Succedent})
		conRes = hypothesis.prepareFTPartialCedentArray({nCedentTypeCode = lm.codes.CedentType.Condition})
		
		if (not(conRes[1]==null)) then
			local cnt = 0
			for j, tmpHypothesis in ipairs(results) do
				antTmp = tmpHypothesis.prepareFTPartialCedentArray({nCedentTypeCode = lm.codes.CedentType.Antecedent})
				sucTmp = tmpHypothesis.prepareFTPartialCedentArray({nCedentTypeCode = lm.codes.CedentType.Succedent})	
				if((antRes[1].Text == antTmp[1].Text) and (sucRes[1].Text == sucTmp[1].Text)) then
					cnt = cnt + 1
				end
			end
			if(cnt > 1) then
				table.insert(to_remove,i)
			end
		end
	end

	local idx = 1
	local res = {}
	for i, el in ipairs(results) do
		if to_remove[idx] == i then
			idx = idx + 1
		else
			res[i-idx+1] = el
		end
	end
	return res
end

-- Unarni funkce, ktera odstrani duplicitni hypotezy; k odhaleni duplicit pouziva
-- hypotezy prevedene do HTML
local function removeDuplicitHypothesis(coll)
	return removeUsingBinaryPredicate(coll, function (a, b) return (a.TextHTML == b.TextHTML) end)
end

-- Unarni funkce, ktera odstrani hypotezy, ktere jsou mene obecne
-- pro porovnani obecnosti pouzivame nasledujici pravidla:
-- Necht A je antecedent, S je succedent a C je podminka,
-- S' podmnozina S a C' podmnozina C, pak hypoteza A ~ B' / C' je obecnejsi nez
-- A ~ B / C, kde ~ je kvantifikator
local function removeLessGeneralHypothesis(coll)
	return removeUsingBinaryPredicate(coll, function (a,b)
		antA = a.prepareFTPartialCedentArray({nCedentTypeCode = lm.codes.CedentType.Antecedent})
		antB = b.prepareFTPartialCedentArray({nCedentTypeCode = lm.codes.CedentType.Antecedent})

		for i, h in ipairs(antA) do
			if not (antB[i] and (h.Text == antB[i].Text)) then
				return false
			end
		end
		sucA = a.prepareFTPartialCedentArray({nCedentTypeCode = lm.codes.CedentType.Succedent})
		sucB = b.prepareFTPartialCedentArray({nCedentTypeCode = lm.codes.CedentType.Succedent})
		conA = a.prepareFTPartialCedentArray({nCedentTypeCode = lm.codes.CedentType.Condition})
		conB = b.prepareFTPartialCedentArray({nCedentTypeCode = lm.codes.CedentType.Condition})
		
		return (isSubset(sucB,sucA) and isSubset(conB,conA))
	end)
end

-- funkce, která pro vystup z TextHTML u hypotezy vrati pocet cedentu te hypotezy
local function countCedents(str)
	local i=0
	local cnt = 0
	while true do
		k,i=string.find(str,"<b>", i)
		if i == nil then
			return cnt
		end
		cnt = cnt + 1
	end
end

-- funkce, ktera radi podle poctu cedentu
local function sortBySimplicity(coll)
	table.sort(coll, function (a,b)
		return countCedents(a.TextHTML) < countCedents(b.TextHTML)
		end)
	return coll
end

-- Pro moznou registraci novych funkci
sortDispatcher={
	simplicity = sortBySimplicity
}

filterDispatcher={
	top1 = topN(1),
	top2 = topN(2),
	top3 = topN(3),
	top4 = topN(4),
	top5 = topN(5),
	top6 = topN(6),
	top7 = topN(7),
	top8 = topN(8),
	top9 = topN(9),
	top10 = topN(10),
	redundantConditionals = removeHypothesisWithRedundantCondition,
	rc = removeHypothesisWithRedundantCondition,
	duplicits = removeDuplicitHypothesis,
	d = removeDuplicitHypothesis,
	lessGeneralHypothesis = removeLessGeneralHypothesis,
	lgh = removeLessGeneralHypothesis
}


-- Rozhraní pro uzivatele
function sortBy(what)
  return sortDispatcher[what]
end

function filter(how)
  return filterDispatcher[how]
end
