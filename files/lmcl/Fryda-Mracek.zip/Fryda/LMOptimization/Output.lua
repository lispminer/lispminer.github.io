require("config/Params")

-- Vytvori report (vice v EMSResults.lua)
function createNewReport()
	pathNameReportOutput= lm.getScriptFolder().."../Export/LMOptimization_Results.html";
	outputFile = io.open(pathNameReportOutput, "w");
	
	outputFile:write( "<!DOCTYPE html>\n");
	outputFile:write( "<html lang=\"en\">\n");
	outputFile:write( "<head><link rel=\"stylesheet\" href=\"ems.css\" type=\"text/css\" /></head>\n");
	outputFile:write( "<body>\n");
	
	outputFile:write( "<center><font size=\"+3\">Vysledky automaticky resenych uloh</font></center>")
end

-- Prida dalsi vyreseny task do reportu
function addToReport(actTaskConfig, results) 
	
	local hypCountMin
	local hypCountMax
	
	if(actTaskConfig.hypCount == nil) then
		hypCountMin = defaultConfig.hypCount.min
		hypCountMax = defaultConfig.hypCount.max		
	else
		hypCountMin = actTaskConfig.hypCount.min
		hypCountMax = actTaskConfig.hypCount.max	 
	end
		
	line = string.format( "<h1>%s</h1>\n", task.Name); 
	outputFile:write( line);
	
	line = string.format( "<p>Rozmezi pro hledani hypotez: (%s, %s)</p>\n", actTaskConfig.hypCount.min, actTaskConfig.hypCount.max); 
	outputFile:write( line);	
		
	if ( (#results >= hypCountMin) and (#results <= hypCountMax)) then
		line = string.format("<p>USPECH: Nalezeny pocet hypotez: %s</p>\n", #results); 
		outputFile:write( line);
		
		local firstQuant, secondQuant = actTaskConfig.method.first, actTaskConfig.method.second
		local quantifiersSet = task.prepareFTQuantifierSettingArray()
		local tmpQuant = firstQuant

		-- Pro kazdy ze zadanych kvantifikatoru vypsat nalezenou hodnotu
		for i=1,2 do
			local q
			if(quantifierMapping[tmpQuant] == "base") then
				q = task.findFTQuantifierSetting({nFTQuantifierTypeCode = lm.codes.FTQuantifierType.BASE}).getThresholdValue();
			elseif (quantifierMapping[tmpQuant] == "pim") then
				q = task.findFTQuantifierSetting({nFTQuantifierTypeCode = lm.codes.FTQuantifierType.PImplication}).getThresholdValue();
			elseif (quantifierMapping[tmpQuant] == "aad") then
				q = task.findFTQuantifierSetting({nFTQuantifierTypeCode = lm.codes.FTQuantifierType.AboveAverage}).getThresholdValue();
			end
			
			line = string.format("<p>Optimalizovany kvantifikator %s = %s</p>\n", tmpQuant, q); 
			outputFile:write( line);
				
			if (secondQuant == null) then
				break
			else
				tmpQuant = secondQuant
			end

		end
		
		outputFile:write( "<p><b>Nalezene hypotezy: </b></p><ul>\n");
		
		for i, hypothesis in ipairs(results) do

			line= string.format( "<li>%s</li>\n", hypothesis.TextHTML); 
			outputFile:write( line);
				
		end;
	
		outputFile:write( "</ul>\n");
	else
		line = string.format("<p>NEUSPECH: Nalezeny pocet hypotez: %s</p>\n", #results); 
		outputFile:write( line);

		if(#results > 0) then
			for i, hypothesis in ipairs(results) do
				line= string.format( "<li>%s</li>\n", hypothesis.TextHTML); 
				outputFile:write( line);				
			end;	
		end;
	end;

end;

-- Uzavre HTML soubor
function finishReport()
	outputFile:write( "</body>\n");
	outputFile:write( "</html>\n");
	
	io.close(outputFile);
	
	cmd = string.format("start %s", pathNameReportOutput); 
	os.execute(cmd);
end;