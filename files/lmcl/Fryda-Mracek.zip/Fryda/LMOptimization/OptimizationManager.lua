-- Binarni puleni, obj_func je unarni funkce, ktera vraci hodnotu optimalizacniho kriteria
-- provede se maximalne max_iterations iteraci, min a max je rozmezi optimalizovane veliciny,
-- target_min a target_max je interval prijatelne hodnoty opt. kriteria
function binarySearch(obj_func, target_min, target_max, min, max, max_iterations)
	
	local mid = 0
	local value = 0
	local target_value = (target_max+target_min)/2
	local iteration = 0
	
	if target_max < obj_func(max)  then
		return nil
	end
  
	while min <= max do
		
		mid = (max+min)/2
		value = obj_func(mid)
		
		if value > target_value then
			max = mid
		elseif value < target_value then
			min = mid
		end
    
		iteration = iteration + 1
		if (value >= target_min and value <= target_max) or (iteration > max_iterations) then
			return mid
		end
	end
	return nil
end

-- Systematicke prohledavani dekrementaci max o dekrement dokud je max >= min a obj_func
-- vraci hodnotu mimo <target_min,target_max>. (pro blizsi popis viz binarni puleni)
function iterativeSearch(obj_func, target_min, target_max, min, max, decrement)

	local cur_val = max
	local value = 0

	if target_max < obj_func(max)  then
		return nil
	end
  
	while cur_val >= min do
		value = obj_func(cur_val)
    
		if value >= target_min and value <= target_max then
			return cur_val
		end
		cur_val = cur_val - decrement
	end
	return nil
end


-- Zpracovani jednoho tasku
function doTask(params)
	task = lm.tasks.findTask({nID = params.taskId});

	-- Zpracovani aktualniho tasku
	lm.logIndentUp(); --odsadit vystup o uroven doprava
	lm.log("Task found - NAME: "..task.Name);

	local x,y = params.method.fn(task, params)
	local srt = params.sort or defaultConfig.sort
	local flt = params.filter or defaultConfig.filter

	local res = flt(srt(task.prepareHypothesisArray()))

	if x then
		lm.log("Konec pri hodnote X = "..x)
	else
		lm.log("Chyba - pozadovany pocet hypotez nebyl nalezen. Pravdepodobna pricina je prilis nizka hranice pro maximalni pocet hypotez nebo nebyl nalezeny pozadovany pocet hypotez.")
	end

	lm.logIndentDown(); --odsadit vystup o uroven doleva
	return res
end;
