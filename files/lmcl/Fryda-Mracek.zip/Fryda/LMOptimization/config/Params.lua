require("../DefaultParams")
dataSourceName = "LM Hotel MB"
config = { -- kolekce konfiguraci pro n uloh
	{ -- zacatek konfigurace ulohy
		taskId = 6, -- id ulohy (lze nalezt ve workspacu vpravo nahore pri otevreneuloze)
		method = optimize("pim"), -- zpusob optimalizace (viz zprava k semestralni praci)
		hypCount = { -- nastavuje rozmezi pro pocet hypotez
			min=2,
			max=10
		},
		pim = { -- nastavuje rozmezi testovane (fundovane) p-implikace
			min = 0.4,
			max = 1
		},
		sort=sortBy("simplicity"), -- razeni podle poctu cedentu
		filter=filter("lgh")
	},
	{ -- zacatek konfigurace druhe ulohy
		taskId = 7,
		method = optimize("base"),
		hypCount = {
			min=2,
			max=20
		},
		base = {
			min = 20,
			max = 100
		},
		filter = filter("rc")
	},
	{
		taskId = 7,
		method = optimize("base","aad"),
		hypCount = {
			min=2,
			max=8
		},
		base = {
			min = 10,
			max = 100,
			max_iterations = 100,
			decrement = 10
		},
		aad = {
			min = 0.4,
			max = 1
		},
		filter = combine(filter("rc"), filter("d"))
	}
};
