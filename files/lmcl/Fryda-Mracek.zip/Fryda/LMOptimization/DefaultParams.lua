require("Functions")

defaultConfig = {
	hypCount = { -- nastaveni poctu hypotez
		min=0,
		max=5
	},
	base = { -- nastaveni pro kvantifikator base
		min = 10,
		max = 100,
		max_iterations = 100, -- pouzite v binarnim puleni
		decrement = 10 -- pouzite v iterativnim vyhledavani
	},
	pim = { -- nastaveni pro kvantifikator pim
		min = 0.4,
		max = 1,
		max_iterations = 10, -- pouzite v binarnim puleni
		decrement = 0.1 -- pouzite v iterativnim vyhledavani
	},
	aad = { -- nastaveni pro kvantifikator aad
		min = 0.4,
		max = 1,
		max_iterations = 100, -- pouzite v binarnim puleni
		decrement = 0.1 -- pouzite v iterativnim vyhledavani
	},
	sort=identity, -- nebo treba sortBy("simplicity")
	filter=identity -- nebo treba filter("top1") .. filter("top10") nebo topN(12)
}

-- vrati funkci, ktera vraci hodnotu pro kvantifikator qtype pro dany task
local function getQuant(qtype)
	return function(task)
		q = task.findFTQuantifierSetting({nFTQuantifierTypeCode = qtype});
		return q.getThresholdValue()
	end
end

-- vrati funkci, ktera nastavi hodnotu na value pro kvantifikator
-- qtype v danem tasku
local function setQuant(qtype)
	return function(task,value)
		q = task.findFTQuantifierSetting({nFTQuantifierTypeCode = qtype});
		q.setThresholdValue(value)
	end
end

quantifier = {
	base={
		set=setQuant(lm.codes.FTQuantifierType.BASE),
		get=getQuant(lm.codes.FTQuantifierType.BASE)
	},
	pim={
		set=setQuant(lm.codes.FTQuantifierType.PImplication),
		get=getQuant(lm.codes.FTQuantifierType.PImplication)
	},
	aad={
		set=setQuant(lm.codes.FTQuantifierType.AboveAverage),
		get=getQuant(lm.codes.FTQuantifierType.AboveAverage)
	}
}

quantifierMapping = {
	["aad"] = "aad",
	["Aad"] = "aad",
	["AAD"] = "aad",
	["base"] = "base",
	["Base"] = "base",
	["BASE"] = "base",
	["pim"] =  "pim",
	["Pim"] =  "pim",
	["p-im"] = "pim",
	["P-IM"] = "pim",
	["P-Im"] = "pim",
}


-- Funkce, ktera vrati minimalni hodnotu kvantifikatoru
-- nejdrive koukne do na hodnotu v nastaveni tasku,
-- pak do lispmineru a pokud ani tam nenajde, tak do
-- vychoziho nastaveni (promenna defaultConfig)
local function getMinValue(quant, params,task)
	local tmin = nil
	
	if not (params[quantifierMapping[quant]] == nil) then
		tmin = params[quantifierMapping[quant]].min
	end
	
	if tmin == nil then
		tmin = quantifier[quantifierMapping[quant]].get(task)
		if tmin == nil then
			tmin = defaultConfig[quantifierMapping[quant]].min
		end
	end
	return tmin
end

-- Ziska hodnotu (res) minima nebo maxima (prop) daneho atributu (attr)
local function getProperty(params, attr, prop)
	local res = nil
	if not (params[attr] == nil) then
		res = params[attr][prop]
	end
	if res == nil then
		res = defaultConfig[attr][prop]
	end
	return res
end



-- funkce, ktera vraci optimalizacni funkce
function optimize(primary, secondary)
  
	if secondary == nil then
		return {first = primary, second = secondary,
			fn = function (task,params)
			local quantName = quantifierMapping[primary]
			local quant = quantifier[quantName]
			local min = getMinValue(primary, params, task)
			local filter = params.filter or defaultConfig.filter
			local result = binarySearch(
				function (x)
					quant.set(task,x)
					task.runAndWaitForResults({nTargetPlatform = "TaskPooler"})
					local res = filter(task.prepareHypothesisArray())
					return (res and #res) or 0
				end,
			getProperty(params,"hypCount","min"),
			getProperty(params,"hypCount","max"),
			min,
			getProperty(params,quantName, "max"),
			getProperty(params,quantName, "max_iterations"))
			return result
		end}
	else
		return {first = primary, second = secondary,
			fn=function (task, params)
			local quant1Name = quantifierMapping[primary]
			local quant2Name = quantifierMapping[secondary]
			local quant1 = quantifier[quant1Name]
			local quant2 = quantifier[quant2Name]
			local primary_min = getMinValue(primary, params, task)
			local filter = params.filter or defaultConfig.filter
			local secondary_min = getMinValue(secondary, params, task)
			local result = iterativeSearch(
				function (x)
					quant2.set(task,x)
					binarySearch(
						function (y)
							quant1.set(task,y)
							task.runAndWaitForResults({nTargetPlatform = "TaskPooler"})
							local res = filter(task.prepareHypothesisArray())
							return (res and #res) or 0
						end,
						getProperty(params,"hypCount", "min"),
						getProperty(params,"hypCount", "max"),
						primary_min,
						getProperty(params,quant1Name, "max"),
						getProperty(params,quant1Name, "max_iterations")
					)
					local res = filter(task.prepareHypothesisArray())
					return (res and #res) or 0
				end,
				getProperty(params,"hypCount", "min"),
				getProperty(params,"hypCount", "max"),
				secondary_min,
				getProperty(params,quant2Name, "max"),
				getProperty(params,quant2Name, "decrement")
			)
			if result then
				return quant1.get(task), quant2.get(task)
			else
				return nil, nil
			end
		end}
	end
end
