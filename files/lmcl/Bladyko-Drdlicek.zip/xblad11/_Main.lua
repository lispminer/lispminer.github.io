-- Import predefined constants
local lm= require( "Exec/Lib/LMGlobal");

-- Log start
lm.log( "Seminar project");
lm.log( "Authors: Michael Drdlicek (qdrdm00), Daniil Bladyko (xblad11)");
lm.log( "University of Economics in Prague");
lm.log( "Course: 4iz460 Advanced approaches to KDD");
lm.log( "Date: 12/7/2015");

-- Look-up packages also in the script folder
package.path= string.format("%s;%s?.lua", package.path, lm.getScriptDirectory());

require( "scripts/Base");
require( "scripts/Metabase");
require( "scripts/Explore");
require( "scripts/Report");
require( "scripts/Prepro");
require( "scripts/Algorithm");
require( "scripts/Tasks");
require( "scripts/Utils");
require( "scripts/Iterations")
require( "scripts/Output");

-- =============================================================================
-- Summary of this script input parameters

-- Database name
assert( lm.ScriptParam.databaseName, "\nYou need to specify dataset name.\nIt must be located in"..
	"folder Data, in format .txt or .csv. Use /ScriptParam:databaseName=%NAME% construction in cmd.exe.");
databaseName= lm.ScriptParam.databaseName;

-- input file format (txt is default)
inputFileFormat= lm.ScriptParam.inputFileFormat and lm.ScriptParam.inputFileFormat or "txt";

-- algorithm is obligatory parameter for script running
algorithms= db.algorithm.getAlgorithmsArray( lm.ScriptParam.algorithm );

-- get output file names array for SV (comma/tabulator separated values file) and Report (HTML)
outputNames, pathNameSVOutputs, pathNameReportOutputs= db.output.getOutputNames( databaseName, alogorithms, inputFileFormat )

inputParams= {

	-- path and file name to source text file	
	pathNameDataSrc= lm.getScriptFolder()..string.format("Data/%s.%s", databaseName, inputFileFormat),			

	-- path and file name of the database to create
	pathNameDataDest= lm.getScriptFolder()..string.format("Databases/%s.DB.mdb", databaseName),

	-- path and file name of the metabase to create
	pathNameMetabase= lm.getScriptFolder()..string.format("Databases/%s.LM.mdb", databaseName), 

	-- database table name to be created
	tableName= databaseName,												

	-- base ODBC DataSourceName for both metabase and data
	dsnBase= "Exec "..databaseName,

	-- output file names array without directories and file formats
	outputNames= outputNames,

	-- output SV (separated values file) paths
	pathNameSVOutputs= pathNameSVOutputs,
	
	-- analytical report to be created
	pathNameReportOutputs= pathNameReportOutputs,

	-- target platform
	nTargetPlatform= lm.codes.TargetPlatform.TaskPooler,

	-- minimum number of hypothesis to be created
	nHypothesisCountMin= 1
};

-- store old level of log verbosity
lm.setLogVerbosityLevel( lm.codes.LogVerbosityLevel.Normal);

-- =============================================================================
-- Data and metabase initialization

lm.log( "Data and metabase initialization.");
lm.logIndentUp();

db.metabase.createDataAndMetabase( inputParams); --- tables creating and metabase in Metabase.lua

lm.logIndentDown();

-- =============================================================================
-- Data exploration

lm.log( "Data exploration.");
lm.logIndentUp();

db.explore.initTables( inputParams); -- tables initialization in Explore.lua

lm.logIndentDown();

-- =============================================================================
-- Searching for missed values in columns

lm.log( "Getting missed values array...");
lm.logIndentUp();

missedValues= db.prepro.missedValuesSpecification( inputParams); -- in Prepro.lua

lm.logIndentDown();

-- =============================================================================
-- Algorithms running

lm.log( "Running algorithm(s)...");
lm.logIndentUp();

db.algorithm.run( algorithms); -- running algorithms in Algorithms.lua

lm.logIndentDown();

-- =============================================================================
-- Log finish
lm.logInfo( "Success, congratulations!"); -- Uh-uuu!
