-- Seminar project
-- Authors: Michael Drdlicek (qdrdm00), Daniil Bladyko (xblad11)
-- University of Economics in Prague
-- Course: 4iz460 Advanced approaches to KDD
-- Date: 12/7/2015

-- LISp-Miner Control Language script, for details see http://lispminer.vse.cz/lmcl
-- code below is based on EverMiner Simple Demo

-- Definition of prepro namespace
db.prepro = {};

-- Creating attributes
function db.prepro.missedValuesSpecification( inputParams)
	
	-- metabase opening
	bOpened= false;
	if ( not lm.metabase.isOpen()) then
	
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

	-- get database table
	dataTable= lm.explore.findDataTable({
		name= inputParams.tableName
	});
	assert( dataTable, "Database table not found!");


	lm.log( "Data columns");

	dataColumnArray = dataTable.prepareDataColumnArray();

	-- primary key data column
	dataColumnID = db.explore.getPrimaryKeyColumn( dataTable);
	ids = dataColumnID.prepareDataArray();

	missedValues = {};
	columnsWithMissedValuesIDs = {};
	missedValues.colsList= {};

	for i, dataColumn in ipairs( dataColumnArray) do

		if ((dataColumn.getDataColumnSubTypeCode() == lm.codes.DataColumnSubType.Ordinary) and
			  (not dataColumn.isPrimaryKeyPart()) and (dataColumn.getValueSubTypeCode() ~= lm.codes.ValueSubType.DateTime)) then

			colName = dataColumn.Name;
			columnData = dataColumn.prepareDataArray();

			missedValues[colName]={};
			for j= 1, #columnData, 1 do

				if(columnData[j] == nil) then
					table.insert(missedValues[colName],ids[j]); -- IDs of rows with NULL value adding to list
				end

			end
			
			if (next(missedValues[colName]) == nil) then
				missedValues[colName].hasMissedValues = false; -- column without missed values
			else
				missedValues[colName].hasMissedValues = true; -- column with missed values
				table.insert(columnsWithMissedValuesIDs,dataColumn.ID);
				table.insert(missedValues.colsList, colName);

				idsMissed = table.concat(missedValues[colName],", ");
				lm.log( string.format("Missed values row IDs for %s: %s.",
						colName,
						idsMissed
					));
				lm.log( string.format("Missed values count for %s: %s.",
						colName,
						#missedValues[colName]
					));
			end

		end

	end
	lm.log("Columns with missed values IDs: "..table.concat( columnsWithMissedValuesIDs,", ")..".");
	lm.log("Names of columns with missed values: "..table.concat( missedValues.colsList, ", ")..".")

	-- metabase closing
	if ( bOpened) then
		lm.metabase.close();
	end;
	
	return missedValues;
end

function db.prepro.createAttributes( inputParams)

	lm.log( "Creating attributes for data tables");
	lm.logIndentUp();

	rootAttributeGroup= lm.prepro.getRootAttributeGroup();

	-- Prepare database table
	-- get database table
	dataTable= lm.explore.findDataTable({
		name= inputParams.tableName
	});
	assert( dataTable, "Database table not found!");

	
	-- Columns	
	local dataColumnArray= dataTable.prepareDataColumnArray();
	
	-- Iterate through all the columns
	for i, column in ipairs( dataColumnArray) do

		attribute= nil;
	
		if ( (not column.isPrimaryKeyPart()) and
			  (column.getValueSubTypeCode() ~= lm.codes.ValueSubType.DateTime)) then
		-- not processing columns part of the primary key
		-- not processing DateTime columns (will process theirs DateTimePart derived columns instead)
			
			attribute= lm.prepro.Attribute({
				name= column.Name,
				pAttributeGroup= rootAttributeGroup,
				pDataColumn= column
			});

			-- Creating categories of type based on type of values in underlying column
			
			if ( attribute.getValueSubTypeCode() == lm.codes.ValueSubType.Float) then
			-- Floats => equidistant intervals
			
				attribute.autoCreateIntervalEquidistant({ 
					nCount= 10
				});
				
			elseif ( attribute.getValueSubTypeCode() == lm.codes.ValueSubType.Integer) then
			-- Integers
			
				if ( (column.getDatePartSubTypeCode() == lm.codes.DatePartSubType.NotSet) or
				 	  (column.getDatePartSubTypeCode() == lm.codes.DatePartSubType.Year) or
					  (column.getDatePartSubTypeCode() == lm.codes.DatePartSubType.DayOfRange) or
					  (column.getDatePartSubTypeCode() == lm.codes.DatePartSubType.MonthOfRange)) then
				-- ordinary integer or years
				
					nDistinctValueCount= column.getDistinctValueCount();
					
					if ( nDistinctValueCount < 20) then			
					-- Small number of distinct integers => enumeration
					
						attribute.autoCreateEnumeration({});
						
					else
					-- Large number of distinct integers => equifrequency intervals
					
						attribute.autoCreateIntervalEquifrequency({ 
							nCount= 7
						});
						
					end;
				elseif ((column.getDatePartSubTypeCode() == lm.codes.DatePartSubType.DayOfYear) or
					     (column.getDatePartSubTypeCode() == lm.codes.DatePartSubType.WeekOfYear)) then
				-- DayOfYear, WeekOfYear
				
						attribute.autoCreateIntervalEquifrequency({ 
							nCount= 7
						});
					
				else
				-- DatePart derived column (month, day, DayOfWeek...)
				
					attribute.autoCreateEnumeration({});
				
				end;
			else
			-- String, boolean

				attribute.autoCreateEnumeration({ 
					nCount= 100
				});
			
			end;

			if ( attribute.getCategoryCount() <= 1) then
			-- not valid => remove

				lm.log( "No categories for attribute "..attribute.Name.." - removing");
									
				attribute.onDel();
				attribute= nil;
				
			end;
			
		else
			-- Derived 'DatePart' columns will be created for DateTime
		end;
		lm.logIndentDown();			
	end;
end;

-- Creating preprocessing
function db.prepro.createPreprocessing( inputParams)

	lm.log( "Preprocessing of attributes and group of attributes");
	lm.logIndentUp();

	-- metabase opening
	bOpened= false;
	if ( not lm.metabase.isOpen()) then
	
		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.explore.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});
	
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

	lm.metabase.clearLocalDataCache(); -- to assure a fresh new start

	db.prepro.createAttributes( inputParams);

	-- metabase closing
	if ( bOpened) then
		lm.metabase.close();
	
		-- Create a backup copy for debug
		lm.metabase.backupMDB({
			pathNameSrc= inputParams.pathNameMetabase,
			pathNameDest= inputParams.pathNameMetabase.."_bkup.prepro.mdb"
		});
	end;
		
	lm.logIndentDown();
	
end;

return db.prepro;