-- Seminar project
-- Authors: Michael Drdlicek (qdrdm00), Daniil Bladyko (xblad11)
-- University of Economics in Prague
-- Course: 4iz460 Advanced approaches to KDD
-- Date: 12/7/2015

-- Definition of algorithm namespace
db.algorithm = {};

-- function returns clear array of algorithms, input is string of comma separated algorithms names
function db.algorithm.getAlgorithmsArray( algorithmsStr)
	algorithms= {};
	assert( algorithmsStr, "\nYou need to specify an algorithm (or algorithms) and the params of them.");
	mixOfAlgorithms= "mixOfAlgorithms";
	if ( algorithmsStr == sysParams.all or algorithmsStr == mixOfAlgorithms) then -- if string is equal to @all or "mixOfAlgoritms"
		algorithms= sysParams.allAlgorithmsNames.algNamesArray;
	else -- string is comma separated string of algoritms names
		algorithms= db.utils.split(algorithmsStr, sysParams.separator);
		-- clear array from algorithms, which are not in sysParams.allAlgorithmsNames array
		local i= 1;
		local size= #algorithms;
		while i <= size do
			alg= algorithms[i];
			if sysParams.allAlgorithmsNames[alg] then
				i= i+ 1;
			else
				table.remove( algorithms, i); -- if name isn't the name of algorithm
				lm.log( "'"..alg.."' algorithm doesn't exist.");
			end
			size= #algorithms;
		end
	end

	return algorithms; -- array of algorithms
end

-- function calls one or more algorithms
function db.algorithm.run( algorithms)
	if #algorithms == 1 then -- one algorithm
		currentAlgorithm= algorithms[1];
		valuesTable= db.algorithm[algorithms[1]]( inputParams);

		-- OUTPUT AND REPORT --
		db.output.createOutput( valuesTable); -- create output file
		db.report.print( inputParams); -- report file creating
	else -- more than one algorithm
		db.algorithm.mixOfAlgorithms( algorithms, inputParams);
	end
end

-- all algorithms are called in sequence one by one, function also construct the general output, mix of algorithms
function db.algorithm.mixOfAlgorithms( algorithmsArray, inputParams)
	sysParams.showReport= false; -- don't show reports in browser

	results= {};
	-- execution of all algorithms in alogrithms array
	for i, alg in ipairs( algorithmsArray) do
		currentAlgorithm= alg;

		lm.log( sysParams.lineSeparator); -- only for orientation in code
		lm.log( currentAlgorithm); -- only for orientation in code
		lm.log( sysParams.lineSeparator); -- only for orientation in code

		results[alg]= db.algorithm[alg]( inputParams);

		-- OUTPUTS AND REPORTS --
		db.output.createOutput( results[alg]); -- create output file
		db.report.print( inputParams); -- report file creating
	end

	-- get relevant names of columns (with missed values)
	colNames= db.algorithm.columnNamesHandling( inputParams);
	-- prepare table of values, which is ready for output
	valuesTable= db.output.prepareOutput.mixOfAlgorithms( colsList, algorithmsArray, results, inputParams);

	return valuesTable;
end

function db.algorithm.simpleStats( inputParams)
	algName= currentAlgorithm;

	-- script params handling
	fType= lm.ScriptParam.funcType or sysParams.FunctionTypes.Mod; -- type of function will be lm.ScriptParam.funcType, if specified, otherwise it will be Mode function
	lm.ScriptParam.funcType= fType; -- if someone will want to use it in future

	-- get relevant names of columns (with missed values)
	colNames= db.algorithm.columnNamesHandling( inputParams);
	-- prepare candidates for replacement missed values
	colReplaceValues= db.algorithm.missedValuesCandidatesForReplacement( colNames, inputParams);

	-- prepare table of values, which can be used for output creation
	valuesTable= db.output.prepareOutput[algName]( colReplaceValues, inputParams);

	return valuesTable;
end

function db.algorithm.ETree( inputParams)

	algName= "ETree";
	valuesTable= db.algorithm.TaskBasedAlgorithm( algName, inputParams);

	return valuesTable;

end

function db.algorithm.MCluster( inputParams)

	algName= "MCluster";
	valuesTable= db.algorithm.TaskBasedAlgorithm( algName, inputParams);

	return valuesTable;

end

-- running algorithms, which are based on task (ETree, MCluster etc.)
function db.algorithm.TaskBasedAlgorithm( algName, inputParams)

	db.prepro.createPreprocessing( inputParams); -- attribute definition
	colsList= db.algorithm.columnNamesHandling( inputParams); -- get relevant names of columns (with missed values)
	db.tasks.createTask( algName, colsList, inputParams); -- task definition
	db.iterations.runAll( algName, inputParams); -- asyncronical running of all tasks


	lm.setLogVerbosityLevel( lm.codes.LogVerbosityLevel.Normal);

	valuesTable= db.output.prepareOutput.HypoDerivedColumns( inputParams); -- prepare table of values, which can be used for output creation

	return valuesTable;

end

function db.algorithm.columnNamesHandling( inputParams)

	-- @allWithMissedValues columns or specified columns
	colNames= {};
	if lm.ScriptParam.columnNames then
		if ( lm.ScriptParam.columnNames == sysParams.allWithMissedValues) then
			colNames= missedValues.colsList;
		else
			colNames= db.utils.split( lm.ScriptParam.columnNames, ","); -- spliting names of columns
		end
	else
		colNames= missedValues.colsList;
	end

	-- clear column names array from columns without missed values
	local i= 1;
	local size= #colNames;
	while i <= size do

		colName= colNames[i];
		if missedValues[colName] then
			if ( not missedValues[colName].hasMissedValues) then
				lm.logInfo( "'"..colName.."' doesn't have missed values.");
				table.remove( colNames, i);
			else
				lm.log( "'"..colName.."' has "..#missedValues[colName].." missed values.");
				i= i+ 1;
			end
		else
			lm.log( "'"..colName.."' column doesn't exist in database.");
			table.remove( colNames, i);
		end
		size= #colNames;

	end

	-- if all columns specified by user are bad, or if columns list is empty
	assert(#colNames ~= 0, "You have specified bad names of columns or none of specified columns doesn't have missed values. Try again.");

	return colNames;
end

-- function adding missed values in category
function db.algorithm.addMissedValuesInCategory( category )
	category.IncludeNULLFlag= true;
	attribute= category.getAttribute();
	if ( attribute.getDataCharacterTypeCode() == lm.codes.DataCharacterType.Nominal) then
		for i, xCat in ipairs(sysParams.constantsXCat) do
			category.includeValue({ value= xCat}); -- N/A, ?, -, not set
		end
	end
end

-- find relevant category of attribute for value
function db.algorithm.findCategoryForValue( attribute, value)
	categoryArray= attribute.prepareCategoryArray();
	for i, category in ipairs(categoryArray) do
		if category.getCategorySubTypeCode() == lm.codes.CategorySubType.Interval then
			intervalArray= category.prepareIntervalArray(); -- in our case might be only one interval
			interval= intervalArray[1];
			valueFrom= interval.getValueFrom(); -- lower bound of interval
			valueTo= interval.getValueTo(); -- upper bound of interval
			-- value is above lower boundary
			if interval.getLeftBracketTypeCode() == lm.codes.BracketType.Sharp then
				isMoreThanLowerBoundary= (value >= valueFrom);
			else
				isMoreThanLowerBoundary= (value > valueFrom);
			end
			-- value is below upper boundary
			if interval.getRightBracketTypeCode() == lm.codes.BracketType.Sharp then
				isLessThanUpperBoundary= (value <= valueTo);
			else
				isLessThanUpperBoundary= (value < valueTo);
			end
			-- inside of interval
			if isMoreThanLowerBoundary and isLessThanUpperBoundary then
				return category;
			end
		else
			if value == category.Name then -- if name of category is same as value
				return category;
			end
		end
	end

	return nil;
end


-- function select the candidates for replacement, function is primary used in simpleStats algorithms
function db.algorithm.missedValuesCandidatesForReplacement( colNames, inputParams)

	bOpened= false;
	if ( not lm.metabase.isOpen()) then
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;
	
	-- get database table
	dataTable= lm.explore.findDataTable({
		name= inputParams.tableName
	});
	assert( dataTable, "Database table not found!");

	lm.log( "Data columns");

	local rootAttributeGroup= lm.prepro:getRootAttributeGroup();

	colReplaceValues= {};
	colReplaceValues.colNames= {};
	for key,colName in ipairs(colNames) do
		dataColumn= dataTable.findDataColumn({
			name= colName;
		});

		-- group of attributes creating
		attributeGroup= lm.prepro.AttributeGroup({
			name= colName,
			pParentGroup= rootAttributeGroup
		});

		--attribute adding
		attribute= lm.prepro.Attribute({
			name= dataColumn.Name.."_m_"..fType,
			pAttributeGroup= attributeGroup,
			pDataColumn= dataColumn
		});

		characterType= attribute.getDataCharacterTypeCode();
		if dataColumn.getValueSubTypeCode() ~= lm.codes.ValueSubType.Float then
			attribute.autoCreateEnumeration({ nCount= 100 });
		else
		attribute.autoCreateIntervalEquidistant({
				nCount= 7,
			});
		end

		-- pseudo X-Category creating
		x_category= lm.prepro.CategoryEnumeration({
			name= "Missed Values",
			pAttribute= attribute
		});
		x_category.XCategoryFlag= true;
		db.algorithm.addMissedValuesInCategory( x_category);
		x_category.XCategoryFlag= false; -- it is pseudo X-Category, we will join it with other category, or we will make the new category
		v = nil;
		if (fType == sysParams.FunctionTypes.Avg) then -- average function
			if (characterType == lm.codes.DataCharacterType.Nominal) then
				note= "Mean can't be calculated for nominal attribute";
				noteForLog= string.format(note.." (attribute %s).",
					colName);
				attribute.Note= note..".";
				lm.logInfo( noteForLog);
				
				goto continue; -- go to next attribute
			else
				v = math.floor( dataColumn.getAvg() + 0.5); -- math.floor( x+ 0.5) is equivalent to math.round( x) (this function isn't defined)
			end
		elseif ( fType == sysParams.FunctionTypes.Mod) then -- mode function
				v = db.explore.getMode( dataColumn);
		elseif ( fType == sysParams.FunctionTypes.Median) then -- median function
			if ( characterType == lm.codes.DataCharacterType.Nominal) then
				note= "Median can't be calculated for nominal attribute";
				noteForLog= string.format(note.." (attribute %s).",
					colName);
				attribute.Note= note..".";
				lm.logInfo( noteForLog);

				goto continue; -- go to next attribute
			else
				v = db.explore.getMedian( dataColumn);
			end
		else
			lm.logInfo( "Function type "..fType.." is not defined.");
		end
		-- trying to find category with same value, as avg, mod or mean.
		sCategory = db.algorithm.findCategoryForValue( attribute, v);

		if ( sCategory == nil) then -- if there is not category with same value as avg, mod or mean.
			x_category.setName( v);
			attribute.calcCategoryFrequencies();
		else -- delete pseudo x-category and add missed values in that category
			db.algorithm.addMissedValuesInCategory( sCategory);
			x_category.onDel();
			attribute.calcCategoryFrequencies();
		end

		colReplaceValues[colName]= v;
		table.insert( colReplaceValues.colNames, colName);
		
		::continue::
	end

	-- metabase closing
	if ( bOpened) then
		lm.metabase.close();
	end;

	return colReplaceValues;
end

return db.algorithm;