-- Seminar project
-- Authors: Michael Drdlicek (qdrdm00), Daniil Bladyko (xblad11)
-- University of Economics in Prague
-- Course: 4iz460 Advanced approaches to KDD
-- Date: 12/7/2015

-- Definition of output namespace
db.output= {};
db.output.prepareOutput= {};

-- function returns array of output names and directories
function db.output.getOutputNames( databaseName, alogorithms, inputFileFormat )
	outputNames= {};
	pathNameSVOutputs= {};
	pathNameReportOutputs= {};
	for i, alg in ipairs(algorithms) do
		outputNames[alg]= databaseName.."_"..alg;
		pathNameSVOutputs[alg]= lm.getScriptFolder().."Output/"..outputNames[alg].."."..inputFileFormat;
		pathNameReportOutputs[alg]= lm.getScriptFolder().."Reports/"..outputNames[alg]..".html";
	end

	return outputNames, pathNameSVOutputs, pathNameReportOutputs;
end

-- function prepare output for mix of algorithms
function db.output.prepareOutput.mixOfAlgorithms( colsList, algorithmsArray, results, inputParams)

	-- metabase opening
	bOpened= false;
	if ( not lm.metabase.isOpen()) then
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

	dataTable= lm.explore.findDataTable({
		name= inputParams.tableName
	});

	currentAlgorithm= "general";
	valuesTable= {};
	valuesTable.rowHeaders= {};
	v= nil;

	-- ID column joining
	idName= "ID_LM";
	table.insert(valuesTable.rowHeaders, idName);
	valuesTable[idName]= {};
	for i=1, dataTable.getRecordCount() do
		table.insert(valuesTable[idName], i);
	end

	for ii, colName in ipairs( colsList) do

		altName= colName.."_"..currentAlgorithm;
		valuesTable[altName]= {};
		for i=1, dataTable.getRecordCount() do
		
			values= {};
			-- get values in row for each algorithm
			for iii, alg in ipairs( algorithmsArray) do
				table.insert( values, results[alg][colName.."_"..alg][i]);
			end

			-- selecting some representative value, if value was missed
			v= values[1];
			if db.utils.contains(missedValues[colName], i) then
				if db.explore.maxFreq( values) > 1 or type(values[1]) == "string" then
					v= db.explore.modeCalc( values); -- mode calculation
				else
					v= math.floor(db.explore.mean( values)+ 0.5); -- rounded average calculation
				end
			end
			table.insert(valuesTable[altName], v);

			if not db.utils.contains(valuesTable.rowHeaders, altName) then
				table.insert(valuesTable.rowHeaders, altName);
			end
		end
	end

	outputNames[currentAlgorithm]= databaseName.."_"..currentAlgorithm;
	pathNameSVOutputs[currentAlgorithm]= lm.getScriptFolder().."Output/"..outputNames[currentAlgorithm].."."..inputFileFormat;

	-- metabase closing
	if ( bOpened) then
		lm.metabase.close();
	end;

	return valuesTable;
end

-- valuesForUpdate - values, which we will use for replacing NULL values (i.e. average, modus or median)
function db.output.prepareOutput.simpleStats( valuesForUpdate, inputParams )

	-- metabase opening
	bOpened= false;
	if ( not lm.metabase.isOpen()) then
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

	dataTable= lm.explore.findDataTable({
		name= inputParams.tableName
	});

	dataColumnArray= dataTable.prepareDataColumnArray();

	valuesTable= {};
	valuesTable.rowHeaders= {};
	for i, dataColumn in ipairs(dataColumnArray) do

		-- fulling all values in temp table (used in CSV)
		-- ID column will be joined to output table in any case
		-- sysParams.all returns all columns names except DateTime columns
		if dataColumn.isPrimaryKeyPart() or
			(lm.ScriptParam.output == sysParams.all and dataColumn.getValueSubTypeCode() ~= lm.codes.ValueSubType.DateTime) then

			valuesTable[dataColumn.Name]= {};
			columnData= dataColumn.prepareDataArray();
			for j= 1, #columnData do
				table.insert(valuesTable[dataColumn.Name], columnData[j] == nil and "" or columnData[j]); -- if NULL, then empty string, otherwise original value
			end

			table.insert(valuesTable.rowHeaders, dataColumn.Name); -- row headers list filling
			
		end

	end

	for i, dataColumn in ipairs(dataColumnArray) do

		if dataColumn.getValueSubTypeCode() ~= lm.codes.ValueSubType.DateTime then
			altName = dataColumn.Name.."_"..currentAlgorithm;
			valuesTable[altName]= {};
			columnData= dataColumn.prepareDataArray();

			if valuesForUpdate[dataColumn.Name] then
				
				for j= 1, #columnData do
					if (columnData[j] == nil) then -- if value is NULL
						columnData[j]= valuesForUpdate[dataColumn.Name]; -- set value from list of candidates for replacement (average, median, mode)
					end
					table.insert(valuesTable[altName], columnData[j]); -- add value in table
				end

				table.insert(valuesTable.rowHeaders, altName); -- row headers list filling
			end

		end

	end

	-- metabase closing
	if ( bOpened) then
		lm.metabase.close();
	end;

	return valuesTable;
end

-- output for columns derived from hypothesis
function db.output.prepareOutput.HypoDerivedColumns( inputParams )

	-- metabase opening
	bOpened= false;
	if ( not lm.metabase.isOpen()) then
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

	dataTable= lm.explore.findDataTable({
		name= inputParams.tableName
	});
	assert( dataTable, "Database table not found!");

	dataColumnArray= dataTable.prepareDataColumnArray();

	valuesTable= {};
	valuesTable.rowHeaders= {};
	
	for i, dataColumn in ipairs(dataColumnArray) do

		-- fulling all values in temp table (used in SV)
		-- ID column will be added in table of values in any case
		-- sysParams.all returns all columns names except DateTime columns
		if dataColumn.isPrimaryKeyPart() or (lm.ScriptParam.output == sysParams.all
			and dataColumn.getValueSubTypeCode() ~= lm.codes.ValueSubType.DateTime 
			and dataColumn.getDataColumnSubTypeCode() ~= lm.codes.DataColumnSubType.Hypothesis) then

			valuesTable[dataColumn.Name]= {};
			columnData= dataColumn.prepareDataArray();
			for j= 1, #columnData do
				table.insert(valuesTable[dataColumn.Name], columnData[j] == nil and "" or columnData[j]); -- if NULL, then empty string, otherwise original value
			end

			table.insert(valuesTable.rowHeaders, dataColumn.Name); -- row headers list filling
			
		end

	end

	for i, dataHypoColumn in ipairs(dataColumnArray) do
		-- select only columns derived from Hypothesis
		if (dataHypoColumn.getValueSubTypeCode() ~= lm.codes.ValueSubType.DateTime 
				and dataHypoColumn.getDataColumnSubTypeCode() == lm.codes.DataColumnSubType.Hypothesis) then

			hypoColumnName= dataHypoColumn.Name;
			-- get name of original column (i.e. class for ETree or MClaster hypothesis)
			originalColumnName= string.gsub(hypoColumnName, "_"..currentAlgorithm, "");
			valuesTable[hypoColumnName]= {};

			dataOriginalColumn= dataTable.findDataColumn({
					name= originalColumnName
				});
			attribute= lm.prepro.findAttribute({
					name= originalColumnName
				});

			datasetHypo= dataHypoColumn.prepareDataArray();
			datasetOriginal= dataOriginalColumn.prepareDataArray();
			categoryArray= attribute.prepareCategoryArray();

			for i= 1,#datasetHypo do
				if (datasetOriginal[i] == nil) then -- if value is NULL
					cat= categoryArray[datasetHypo[i]];
					if ( cat.getCategorySubTypeCode() == lm.codes.CategorySubType.Interval) then -- interval
						intervalArray= cat.prepareIntervalArray(); -- in our case might be only one interval
						valueFrom= intervalArray[1].getValueFrom(); -- lower bound of interval
						valueTo= intervalArray[1].getValueTo(); -- upper bound of interval
						value= math.floor(( valueFrom+ valueTo)/ 2+ 0.5); -- the rounded average with math.round(x) analogy
					else -- enumeration
						value= cat.Name; -- because category name is the same as value in category in our case
					end
				else
					value= datasetOriginal[i]; -- if value isn't NULL
				end
				table.insert(valuesTable[hypoColumnName], value); -- add value in table
			end

			table.insert(valuesTable.rowHeaders, hypoColumnName); -- add header in headers list

		end

	end

	-- metabase closing
	if ( bOpened) then
		lm.metabase.close();
	end;

	return valuesTable;

end

function db.output.createOutput( valuesTable )
	rh= valuesTable.rowHeaders;
	rowCount= #valuesTable[rh[1]];
	sep= "\t";

	-- CSV
	outputFile= io.open( inputParams.pathNameSVOutputs[currentAlgorithm], "w");
	outputFile:write(table.concat(rh, sep)); -- row of column names
	outputFile:write("\n");

	-- writing all values to CSV
	for i= 1, rowCount do
		for j= 1, #rh-1 do
			outputFile:write(valuesTable[rh[j]][i]..sep); -- inserting all values in row except last value
		end
		outputFile:write(valuesTable[rh[#rh]][i].."\n"); -- inserting last value in row
	end

	io.close(outputFile);
	lm.log("Output is ready!");
end

return db.output;