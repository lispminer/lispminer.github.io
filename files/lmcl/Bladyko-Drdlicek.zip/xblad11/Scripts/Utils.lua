-- Seminar project
-- Authors: Michael Drdlicek (qdrdm00), Daniil Bladyko (xblad11)
-- University of Economics in Prague
-- Course: 4iz460 Advanced approaches to KDD
-- Date: 12/7/2015

-- Definition of utils namespace
db.utils= {};

-- Decompousing items from string to array
function db.utils.split( inputStr, sep )
	if sep == nil then
    	sep= "%s";
    end
    local t= {} ; i= 1
    for str in string.gmatch(inputStr, "([^"..sep.."]+)") do
        t[i]= str;
        i= i + 1;
    end
    return t;
end

-- if table contains an element
function db.utils.contains(table, element)
  for _, value in ipairs(table) do
    if value == element then
      return true
    end
  end
  return false
end



return db.utils;