-- Seminar project
-- Authors: Michael Drdlicek (qdrdm00), Daniil Bladyko (xblad11)
-- University of Economics in Prague
-- Course: 4iz460 Advanced approaches to KDD
-- Date: 12/7/2015

-- based on Bilík: Automatické předzpracování dat v LMCL

-- Definition of explore namespace
db.explore = {};

-- Initialization of tables function
function db.explore.initTables( inputParams)

	-- metabase opening
	bOpened= false;
	if ( not lm.metabase.isOpen()) then

		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.create.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});

		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

	lm.log( "Initializing data tables");
	lm.logIndentUp();

	-- Prepare dataTableArray
	local dataTableArray= lm.explore.prepareDataTableArray();

	-- Iterate through all the dataTables
	for i, dataTable in ipairs( dataTableArray) do

		lm.log( "Initializing data table ".. dataTable.Name);
		lm.logIndentUp();

		dataTable.init();
		
		if ( not dataTable.isPrimaryKeyDefined()) then
		-- Primary key not set yet
		
			-- Use the default ID column created during the text data import
			dataTable.markPrimaryKey({ 
				columnName= lm.data.IDColumnNameDefault		
					-- name of column to become the primary key
			});			
		
		end;
		
		-- Check the primary key being set properly and stop if not
		assert( dataTable.checkPrimaryKey(), 
				  "Error checking the primary key for table "..dataTable.Name);

		-- Enable data caching to speed-up analytical task processing
		dataTable.LocalDataCacheFlag= true;

		
		lm.logIndentDown();
	
	end;

	-- metabase closing
	if ( bOpened) then
		lm.metabase.close();
	
		-- Create a backup copy for debug
		lm.metabase.backupMDB({
			pathNameSrc= inputParams.pathNameMetabase,
			pathNameDest= inputParams.pathNameMetabase.."_bkup.explore.mdb"
		});
	
	end;
		
	lm.logIndentDown();

end;

-- function for finding and returning  primary key column in dataTable
function db.explore.getPrimaryKeyColumn( dataTable)
	assert( dataTable.checkPrimaryKey(),
		"Error checking the primary key for table "..dataTable.Name);

	dataColunmArray= dataTable.prepareDataColumnArray();
	for i, dataColumn in ipairs( dataColumnArray) do

		if (dataColumn.isPrimaryKeyPart()) then
			dataColumnID = dataColumn;
			lm.log("Finded ID column: "..dataColumnID.Name);
		end
	end

	return dataColumnID;
end

-- funciton for median calculation
function db.explore.getMedian( dataColumn)
	set = dataColumn.prepareDataArray();
	for i=1,#set do
		if (set[i] == nil) then table.remove(set, i); end -- clear set from NULL values
	end
	table.sort(set); -- sorting values in dataset
	if ((#set + 1)%2 == 0) then -- odd count of values in dataset
		median = set[(#set + 1)/2];
	else -- even count of values in dataset
		median = math.floor((set[math.floor((#set + 1)/2)] + set[math.ceil((#set + 1)/2)]) / 2 + 0.5); -- math.floor( x+ 0.5) is alternative for math.round( x) function (math.round() function isn't defined in lua)
	end
	return median;
end

-- function for calculation of mode
function db.explore.getMode( dataColumn)
	dSet, f = dataColumn.prepareDistinctValueArray(); -- get dataset of distinct values and their frequencies
	clearedIDs, dSet = db.explore.prepareClearedArray(dSet); -- clear dataset from NULL values
	for i= 1, #clearedIDs do
		table.remove(f, clearedIDs[i]); -- remove frequency of NULL value in set as well
	end

	mods= {};
	maxFreq= math.max(unpack(f)); -- get maximum frequency in dataset
	for i= 1, #f do
		if (f[i] == maxFreq) then -- values with maximum frequency
			table.insert(mods, dSet[i]);
		end
	end
	
	-- randomly choose one of modes in case their count is more than one
	mod= mods[math.random(1, #mods)];
	return mod;
end

function db.explore.modeCalc( array )
	f= {}; -- frequencies array
	for i, v in ipairs(array) do
		table.insert(f, db.explore.valueFrequency( array, v));
	end
	mods= {};
	maxFreq= math.max(unpack(f)); -- get maximum frequency in array
	for i= 1, #f do
		if (f[i] == maxFreq) then -- values with maximum frequency
			table.insert(mods, array[i]);
		end
	end

	mod= mods[math.random(1, #mods)];
	return mod;
end

function db.explore.maxFreq( array )
	f= {}; -- frequencies array
	for i, v in ipairs(array) do
		table.insert(f, db.explore.valueFrequency( array, v));
	end
	mods= {};
	maxFreq= math.max(unpack(f)); -- get maximum frequency in array

	return maxFreq;
end

-- function returns mean of array
function db.explore.mean( array )
  local sum= 0;
  local count= 0;

  for k,v in pairs(array) do
    if type(v) == 'number' then
      sum = sum + v;
      count = count + 1;
    end
  end

  return (sum / count);
end

function db.explore.valueFrequency( array, value )
	local f= 0;
	for i, v in ipairs(array) do
		if v == value then f= f+ 1 end;
	end
	return f;
end

-- clear array from NULL values, returns IDs of NULL values in array and cleared set of values
function db.explore.prepareClearedArray( set)
	clearedIDs = {};
	for i=1, #set do
		if (set[i] == nil) then table.remove(set, i); table.insert(clearedIDs, i) end
	end

	return clearedIDs, set;
end

return db.explore;