-- Seminar project
-- Authors: Michael Drdlicek (qdrdm00), Daniil Bladyko (xblad11)
-- University of Economics in Prague
-- Course: 4iz460 Advanced approaches to KDD
-- Date: 12/7/2015

-- based on Bilík: Automatické předzpracování dat v LMCL

-- Definition of report namespace
db.report= {};

-- report printing funciton
function db.report.print( inputParams)
	
	-- metabase opening
	bOpened= false;
	if ( not lm.metabase.isOpen()) then
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

	-- association with file
	outputFile= io.open( inputParams.pathNameReportOutputs[currentAlgorithm], "w");
	local dataTableArray= lm.explore.prepareDataTableArray();
	outputFile:write(db.report.htmlHeader());
	outputFile:write("\t\t<div style=\"color:#666;\">Missing values replace method: <em>"..currentAlgorithm.."</em></div>\n");
	if lm.ScriptParam.funcType then
		outputFile:write("\t\t<div style=\"color:#666;\">Value for replacement: <em>"..sysParams.fullNames[lm.ScriptParam.funcType].."</em></div>\n<br />\n");
	end

	for ii, dataTable in ipairs( dataTableArray) do
		outputFile:write("\t\t<h1>Table: "..dataTable.Name.." (records count: <span style=\"color:blue;\">"..dataTable.getRecordCount().."</span>)</h2>\n");
		outputFile:write("\t\t<h2 style=\"background:#ccc;\">Columns with missed values:</h2>\n");

		for i= 1, #missedValues.colsList do
			outputFile:write("\t\t<div><strong>Column "..missedValues.colsList[i].."</strong>"..
				" (count of missed values: <span style=\"color:blue;\">"..#missedValues[missedValues.colsList[i]].."</span>)</div>\n");
			outputFile:write("\t\t<div>Records without value IDs: <em>"..table.concat( missedValues[missedValues.colsList[i]], ", ").."</em></div>\n");
			if colReplaceValues then -- simpleStats
				if colReplaceValues[missedValues.colsList[i]] then
					outputFile:write("\t\t<div>NULL values was replaced by <span style=\"color:red;\">"..colReplaceValues[missedValues.colsList[i]].."</span></div>\n");
				else
					outputFile:write("\t\t<div>NULL values <span style=\"color:red;\">weren't replaced</span>.</div>\n");
				end
			else -- ETree or MCluster
				if db.utils.contains(colsList, missedValues.colsList[i]) then
					outputFile:write("\t\t<div>New derived column <span style=\"color:red;\">"..missedValues.colsList[i].."_"..currentAlgorithm.."</span> was created.</div>\n");
				else
					outputFile:write("\t\t<div>For this column <span style=\"color:red;\">derived column wasn't created</span>.</div>\n");
				end
			end
			outputFile:write("\t\t<hr />");
		end
		outputFile:write("\t\t<h2>Output file link (csv format): <a href=\"file:///"..inputParams.pathNameSVOutputs[currentAlgorithm].."\">"..inputParams.outputNames[currentAlgorithm].."."..inputFileFormat.."</a></h2>");

	end
	-- html Footer
	outputFile:write(db.report.htmlFooter());
	io.close(outputFile);
	lm.log("Report is ready!");
	
	if sysParams.showReport then
		db.report.openReport( inputParams);
	end

	-- metabase closing
	if ( bOpened) then
		lm.metabase.close();
	end;
end

-- html Header
function db.report.htmlHeader()
  header= "<!DOCTYPE html>\n"..
				 "<html lang=\"en\">\n"..
                 "\t<head>\n"..
                 --"\t\t<link rel=\"stylesheet\" href=\"../doc/css/ems.css\" type=\"text/css\" />\n"..
                 "\t\t<meta charset=\"utf-8\">\n"..
                 "\t\t<title>Seminar Paper \"Missing values searching and replacement\" - Report</title>\n"..
                 "\t</head>\n"..
				 "\t<body>\n"..
				 "\t\t<div align=\"center\" style=\"font-size: 250%;\">Missing values searching and replacement - Report</div>\n"
	
	return header
end


-- html Footer
function db.report.htmlFooter()
	vypisFooter= 	"\t</body>\n"..
					"</html>\n"
	return vypisFooter
end

-- report opening
function db.report.openReport( inputParams)
-- Open an application (browser) associated with .HTML files

	cmd= string.format( "start %s", 
			inputParams.pathNameReportOutputs[currentAlgorithm]
	); 
	
	os.execute( cmd);
end

return db.report;