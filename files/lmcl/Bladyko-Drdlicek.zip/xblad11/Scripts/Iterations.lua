-- Seminar project
-- Authors: Michael Drdlicek (qdrdm00), Daniil Bladyko (xblad11)
-- University of Economics in Prague
-- Course: 4iz460 Advanced approaches to KDD
-- Date: 12/7/2015

-- LISp-Miner Control Language script, for details see http://lispminer.vse.cz/lmcl
-- code below is based on EverMiner Simple Demo

-- Definition of iterations namespace
db.iterations = {};

-- Main functions

function db.iterations.runAll( taskSuffix, inputParams)
-- run each task in iterations till number of hypotheses is in the given interval

	lm.setLogVerbosityLevel( lm.codes.LogVerbosityLevel.Fine);
	lm.setLogFunctionParameterValuesFlag( false);

	lm.log( "Solving all tasks to get an acceptable number of patterns");
	lm.logIndentUp();

	lm.tasks.setPoolerShutdownDelay( 3);
	-- force xxPooler application to stay open for a while even if its queue is empty
	-- because another task will be inserted in a short time
	
	-- metabase opening
	bOpened= false;
	if ( not lm.metabase.isOpen()) then
	
		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.tasks.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});
	
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

	-- get database table
	dataTable= lm.explore.findDataTable({
		name= inputParams.tableName
	});
	assert( dataTable, "Database table not found!");
	
	-- prepare tasks queue
	taskQueueArray= lm.tasks.prepareTaskArray({
		pDataTable= dataTable
	});
	
	-- sort tasks by ID (just for cosmetic reason to process tasks in the order they were created)
	table.sort( taskQueueArray, function ( task1, task2) return task1.ID < task2.ID; end);
		
	nTaskFinishedCount= 0;
	nMaxIterationsCount= 100;
	nActualIteration= 0;
	
	while ( #taskQueueArray > 0) do

		-- lm.log("Number of tasks in Queue: "..#taskQueueArray);
		-- pop the topmost task from the queue (task is removed from the queue)
		task= table.remove( taskQueueArray, 1);
		assert( task);

--		lm.logInfo( task.Name..": "..task.getTaskGenerationStatusStr());
	
		if (task.isTaskGenerationStatusInProcess()) then
		-- running ( lm.TaskGenerationStatus.Request or lm.TaskGenerationStatus.Waiting or lm.TaskGenerationStatus.Running)
		-- need to query if its state has changed
		
			if ( task.queryTaskGenerationStatus() > 0) then
			-- Task was running and has just finished
		
				lm.metabase.reloadResults();			-- reload newly found results
				nActualIteration= 1;
			end
		end
		
		-- lm.log( task.Name..": "..task.getTaskGenerationStatusStr());
		-- calculate iterations only for running tasks
		if ( task.TaskGenerationStatus == lm.codes.TaskGenerationStatus.Running or task.TaskGenerationStatus == lm.codes.TaskGenerationStatus.Waiting) then
			nActualIteration= nActualIteration+ 1;
		end
		-- lm.log( "current iteration for "..task.Name..": "..nActualIteration..", limit: "..nMaxIterationsCount);

			
		-- select an appropriate action based on the current TaskGenerationStatus
		if ( task.TaskGenerationStatus == lm.codes.TaskGenerationStatus.None) then
		-- not running yet => need to be launched
			
			-- run asynchronously (stars task in a parallel thread and returns immediatelly)
			task.runAsync({
				nTargetPlatform= inputParams.nTargetPlatform
			});
	
			-- add the task at the end of queue
			table.insert( taskQueueArray, task);
			
		elseif (task.isTaskGenerationStatusInProcess()) then
		-- task still in the process
		-- re-insert the task at the end of queue
			if ( nActualIteration <= nMaxIterationsCount) then
				table.insert( taskQueueArray, task);
			else	
				lm.log( "Task '"..task.Name.."' not finished successfully (maximum iterations count is exceed) and therefore removed from processing");

				task.Note= "Not finished successfully and therefore removed from processing (exceed of maximumum iterations count)";

				nActualIteration= 1;
			end

		elseif ( task.TaskGenerationStatus == lm.codes.TaskGenerationStatus.Solved)
			or ( task.TaskGenerationStatus == lm.codes.TaskGenerationStatus.Interrupted and task.getHypothesisCount() > 0) then
		-- Successfully solved

			nTaskFinishedCount= nTaskFinishedCount+ 1;

			-- Check the number of found hypotheses
			nHypoCount= task.getHypothesisCount();

			lm.log( "Task '"..task.Name.."' finished with "..nHypoCount.." hypotheses");

			lm.logIndentUp();

			lm.log( "Looking-up the most interesting results");

			-- 'Final results' group
			hypothesisGroup= lm.tasks.results.HypothesisGroup({
				name= lm.tasks.results.HypothesisGroupNameFinal,
				pTask= task
			});

			if ( nHypoCount > 0) then
				
				hypothesisArray= task.prepareHypothesisArray();
				
				for i, hypothesis in ipairs( hypothesisArray) do
				
					if ( i > inputParams.nHypothesisCountMin) then break; end;
					
					hypothesis= hypothesisArray[i];	-- should choose the best hypothesis!
				
					hypothesisGroup.insertHypothesis({
						pHypothesis= hypothesis
					});

					if task.TargetSetting then -- KTree
						nameOfColumn= task.TargetSetting.getAttribute().Name.."_"..taskSuffix
					elseif task.TargetClassAttribute then -- MCluster
						nameOfColumn= task.TargetClassAttribute.Name.."_"..taskSuffix
					end

					-- create derived column for task
					hypothesis.createDerivedDataColumn({
							name= nameOfColumn
						})
			
				end;
				
			end;

		else
		-- finished, but in this case it means "not successfully" (lm.TaskGenerationStatus.Failed)
		-- because a "succesfully solved or interrupt with hypothesis" was already handled above

--			lm.logInfo( task.getTaskGenerationStatusStr());
			
			assert( task.isTaskGenerationStatusFinished(), "Task '"..task.Name.."' is in an unknown state");
	
			lm.log( "Task '"..task.Name.."' not finished successfully and therefore removed from processing");

			task.Note= "Not finished successfully and therefore removed from processing";
			
			-- we have finished with the task so no need to re-insert it to queue

		end;
		
		-- leave processor cores alone for a while
		lm.sleep( 250);

	end;	-- while
			
	-- Force the still running Pooler to shutdown (it shouldn't have anything to process already)
	lm.tasks.shutdownPoolerOnIdle();
	lm.sleep( 1000);	-- give some (short) time to shutdown
	
--	lm.sleep( 1000*( lm.tasks.getPoolerShutdownDelay()+ 2));
		-- or alternative way: to wait till the xxPooler application delayed close occurs and
		-- the metabase would be unlocked
	
	-- metabase closing
	if ( bOpened) then

		lm.metabase.close();
	
		-- Create a backup copy for debug
		lm.metabase.backupMDB({
			pathNameSrc= inputParams.pathNameMetabase,
			pathNameDest= inputParams.pathNameMetabase.."_bkup.iterations.mdb"
		});
	
	end;
		
	lm.logIndentDown();
		
	return nTaskFinishedCount;
	
end;	

return db.iterations;