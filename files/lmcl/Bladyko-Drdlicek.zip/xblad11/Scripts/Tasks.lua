-- Seminar project
-- Authors: Michael Drdlicek (qdrdm00), Daniil Bladyko (xblad11)
-- University of Economics in Prague
-- Course: 4iz460 Advanced approaches to KDD
-- Date: 12/7/2015

-- Definition of tasks namespace
db.tasks= {};

-- ETree task creation
function db.tasks.ETree( colsList, inputParams)

	dataTable= lm.explore.findDataTable({
			name= inputParams.tableName,
		});

	attributeArray= lm.prepro.prepareAttributeArray();

	defaultTaskGroup= lm.tasks.findTaskGroup({
			nID= 1, -- default task group
		});
	for i, targetAttributeName in ipairs(colsList) do
		-- attribute with missed value
		targetAttribute= lm.prepro.findAttribute({
				name= targetAttributeName,
			});

		-- ETree task creating
		taskET= lm.tasks.TaskET({ 
				name= "ETree task: "..targetAttribute.Name,
				pDataTable= dataTable,
				pTaskGroup= defaultTaskGroup,
			});

		-- target attribute settings
		ETTargetSettings= taskET.TargetSetting;
		ETTargetSettings.setAttribute(targetAttribute);

		ETPartialGroupSetting= lm.tasks.settings.ETPartialGroupSetting({
				pTaskET= taskET,
			});

		-- ETree partial cedent attributes settings
		for ii, attribute in ipairs(attributeArray) do
			if attribute.Name ~= targetAttributeName then
				lm.tasks.settings.ETAttributeSetting({
						pAttribute= attribute,
						pETPartialGroupSetting= ETPartialGroupSetting
					});
			end
		end

		-- Condition: Empty partial cedent

		conditionFTPartialCedentSetting= 
			db.tasks.createFTPartialCedent( 
				lm.codes.CedentType.Condition, 
				taskET, 
				dataTable, 
				nil					-- empty AttributeGroup
		);

		-- params from cmd.exe
		if lm.ScriptParam.TestingType then
			taskET.setTestingTypeCode(lm.ScriptParam.TestingType); -- 1 - TrainingSet, 2 - CrossValidation, 3 - RandomSplit
		end

		if lm.ScriptParam.NodePurityMin then
			taskET.NodePurityMin= lm.ScriptParam.NodePurityMin;
		end

		if lm.ScriptParam.NodeFrequencyMin then
			taskET.NodePurityMin= lm.ScriptParam.NodeFrequencyMin;
		end

		if lm.ScriptParam.SplitAttributesMax then
			taskET.SplitAttributesMax= lm.ScriptParam.SplitAttributesMax;
		end

	end
end

-- MCluster task creation
function db.tasks.MCluster( colsList, inputParams)

	dataTable= lm.explore.findDataTable({
			name= inputParams.tableName,
		});

	attributeArray= lm.prepro.prepareAttributeArray();

	defaultTaskGroup= lm.tasks.findTaskGroup({
			nID= 1, -- default task group
		});
	for i, targetAttributeName in ipairs(colsList) do
		-- attribute with missed value
		targetAttribute= lm.prepro.findAttribute({
				name= targetAttributeName,
			});

		-- MCluster task creating
		taskMC= lm.tasks.TaskMC({ 
				name= "MCluster task: "..targetAttribute.Name,
				pDataTable= dataTable,
				pTaskGroup= defaultTaskGroup,
			});

		-- target attribute settings
		taskMC.TargetClassAttribute= targetAttribute;
		taskMC.TargetClusterMax= targetAttribute.getCategoryCount();
		taskMC.TargetClusterMin= taskMC.TargetClusterMax;

		MCPartialGroupSetting= lm.tasks.settings.MCPartialGroupSetting({
				pTaskMC= taskMC,
			});

		-- MCluster partial cedent attributes settings
		for ii, attribute in ipairs(attributeArray) do

			if (missedValues[attribute.Name] and (not missedValues[attribute.Name].hasMissedValues)) then
				lm.tasks.settings.MCAttributeSetting({
						pAttribute= attribute,
						pMCPartialGroupSetting= MCPartialGroupSetting
					});
			end
		end

		-- Condition: Empty partial cedent

		conditionFTPartialCedentSetting= 
			db.tasks.createFTPartialCedent( 
				lm.codes.CedentType.Condition, 
				taskMC, 
				dataTable, 
				nil					-- empty AttributeGroup
		);

		-- params from cmd.exe, optional parameters

		if lm.ScriptParam.HypothesisCountMax  then
			taskMC.HypothesisCountMax= lm.ScriptParam.HypothesisCountMax;
		else
			taskMC.HypothesisCountMax= 10;
		end

		if lm.ScriptParam.RandSeedInit then
			taskMC.RandSeedInit= lm.ScriptParam.RandSeedInit;
		end

		if lm.ScriptParam.IterationCountMax then
			taskMC.IterationCountMax= lm.ScriptParam.IterationCountMax;
		end
	end
end

function db.tasks.createTask( taskName, colsList, inputParams)
	-- metabase opening
	bOpened= false;
	if ( not lm.metabase.isOpen()) then
	
		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.prepro.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});
	
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end

	db.tasks[taskName]( colsList, inputParams);

	-- metabase closing
	if ( bOpened) then
	
		lm.metabase.close();
	
		--Create a backup copy for debug
		lm.metabase.backupMDB({
			pathNameSrc= inputParams.pathNameMetabase,
			pathNameDest= inputParams.pathNameMetabase.."_bkup.tasks.mdb"
		});
	
	end
	
	lm.logIndentDown();
end

function db.tasks.createFTPartialCedent( cedentTypeCode, task, dataTable, attributeGroup)
	-- Creates a single FTPartialCedentSetting with all attributes from given group of attributes
	
		ftpartialCedentSetting= lm.tasks.settings.FTPartialCedentSetting({
			pTask= task,
			nCedentTypeCode= cedentTypeCode,
			name= attributeGroup and 
						attributeGroup.Name or 
						lm.tasks.settings.FTPartialCedentNameDefault
		});
		
		if ( attributeGroup) then
		
			attributeArray= attributeGroup.prepareAttributeArray({
				pDataTable= dataTable
			});
				
			for j, attribute in ipairs( attributeArray) do
			-- add literal for each attribute
			
				ftliteralSetting= lm.tasks.settings.FTLiteralSetting({
					pFTPartialCedentSetting= ftpartialCedentSetting,
					pAttribute= attribute
				});
			
			end;
		end;
			
		return ftpartialCedentSetting;
		
	end;

return db.tasks;