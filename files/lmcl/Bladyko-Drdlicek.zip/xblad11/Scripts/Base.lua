-- Seminar project
-- Authors: Michael Drdlicek (qdrdm00), Daniil Bladyko (xblad11)
-- University of Economics in Prague
-- Course: 4iz460 Advanced approaches to KDD
-- Date: 12/7/2015

-- based on Bilík: Automatické předzpracování dat v LMCL

-- Definition of base namespace
db= {};

sysParams= {
		separator= ",", -- standard string separator
		lineSeparator= "========================================================", -- lines separator (for instance can be used in log file)
		all= "@all", -- all algoritms, all columns and so on, used as user input parameter
		allWithMissedValues= "@allWithMissedValues", -- all columns with missed values, used as user input parameter

		allAlgorithmsNames= { -- list of all avalible algoritms
			simpleStats= "simpleStats",
			ETree= "ETree",
			MCluster= "MCluster",
			algNamesArray= {"ETree", "MCluster", "simpleStats"},
		},

		showReport= true, -- if we want to show report in browser after generation

		fullNames= { -- full names of functions
			avg= "mean",
			mdn= "median",
			mod= "mode"
		},

		FunctionTypes= { -- function input names
			Avg= "avg",
			Median= "mdn",
			Mod= "mod"
		},

		-- string constants for X-Categories
		constantsXCat= {
			"?",
			"-",
			"N/A",
			"not set"
		},
}

return db;