-- Semestralna praca Predspracovanie dat - Detekcia odlahlych pozorovani
-- Author: Trcka, části kódu převzaty z práce Bilík: Automatické předzpracování dat v LMCL
-- Date: 1. 5. 2015


-- Subor ma na starosti vytvorenie zakladnych atributov

db.cleaning = {};

-- creates attribute group for every column and name it same as column name
function db.cleaning.createAttributeGroups(inputParams)

	lm.log( "Creating attribute group for every column of tables");

	rootAttributeGroup= lm.prepro.getRootAttributeGroup();

	-- Prepare database tables array
	local dataTableArray= lm.explore.prepareDataTableArray();
	-- Iterate through all the database tables
	for i, dataTable in ipairs( dataTableArray) do
		if ( dataTable.isInitialized()) then
			dataTable.setLocalDataCacheFlag(true)
			lm.log( "Creating attribute groups for table "..dataTable.Name);
			
			local dataColumnArray= dataTable.prepareDataColumnArray();
			
			-- Iterate through all the columns
			for j, column in ipairs( dataColumnArray) do
				-- create attribute group for every column that is not primary key or has date type
				if ( (not column.isPrimaryKeyPart()) and
					  (column.getValueSubTypeCode() ~= lm.codes.ValueSubType.DateTime)) then
						attributeGroup= lm.prepro.AttributeGroup({ 
						name= column.Name, 
						pParentGroup= rootAttributeGroup
					});
				end
			end

		end
	end
end

-- Iterate through tables in external info table list and if name matches, return info about that table
function db.cleaning.findInfoAboutTable(tableList, tableName)
	if (not tableList) then -- tableList not exists, return nil
		return nil
	end
	for i, tableInfo in ipairs( tableList) do
		if(tableInfo.tableName == tableName) then -- match
			return tableInfo
		end
	end
	return nil
end

-- Iterate through columns in external info columns list and if name matches, return info about that column
function db.cleaning.findInfoAboutColumn(columnList, columnName) 
	if (not columnList) then
		return nil
	end
	for i, columnInfo in ipairs( columnList) do
		if(columnInfo.name == columnName) then
			return columnInfo
		end
	end
	return nil
end

-- Marks X-Category with known value from external info
function db.cleaning.markKnownXCategory(attribute, extColumn)
	
	local category= lm.prepro.CategoryEnumeration({
		name= "X-Category",
		pAttribute= attribute});
	category.XCategoryFlag= true;
	category.includeValue({ value = extColumn["X-Cat"]});
end

-- Marks X-Category with unknown values that are common for the most cases
function db.cleaning.markUnknownXCategory(attribute, dataType) 
	
	categoryName= "X-Category";	-- not neccessary to set
	
	local category= lm.prepro.CategoryEnumeration({
		name= categoryName,
		pAttribute= attribute
	});
	category.XCategoryFlag= true;
	
	-- including all the values deemed as "unknown", but only for string type of column		
	if( dataType == lm.codes.ValueSubType.String) then
		db.prepro.enumerationXCatString(category)

	end
	category.IncludeNULLFlag= true;
		
end

-- iterate through categories names from external info and set them to attribute
function db.cleaning.createCategoriesFromExternalInfo(extColumn, attribute) 
	-- if we have further info about column data type, set it to attribute
	if(extColumn["dataType"] == "nominal" ) then
		attribute.setDataCharacterTypeCode(lm.codes.DataCharacterType.Nominal)
	end

	if(extColumn["dataType"] == "ordinal" ) then
		attribute.setDataCharacterTypeCode(lm.codes.DataCharacterType.Ordinal)
	end

	for i, categoryDesc in ipairs (extColumn["categories"]) do
		local catName = categoryDesc["value"]
		local catKey = categoryDesc["code"]
		local category= lm.prepro.CategoryEnumeration({
			name= catName,
			pAttribute= attribute,
			nOrder = i
		});
		category.includeValue({ value = catKey});

		lm.log("Calculating category frequencies")
		attribute.calcCategoryFrequencies()
	end

end

-- create attribute for column with external info 
function db.cleaning.createAttributeWithExternalInfo(extColumn, column)
	attributeGroup= lm.prepro.findAttributeGroup({
		name= column.Name
	});

	attribute= lm.prepro.Attribute({
		name= column.Name,
		pAttributeGroup= attributeGroup,
		pDataColumn= column
	});
	
	
	-- if we have some info about x-category, mark it down
	if(extColumn["X-Cat"]) then
		db.cleaning.markKnownXCategory(attribute, extColumn)
	else -- else mark general x-category

		db.cleaning.markUnknownXCategory(attribute, column.getDataColumnSubTypeCode())
	end
	if( extColumn["dataType"] == "nominal" or extColumn["dataType"] == "ordinal") then -- if dataType of column is nominal or ordinal set its categories names (if exists)
		
		db.cleaning.createCategoriesFromExternalInfo(extColumn, attribute, column)
	end
	attribute.autoCreateEnumeration({});

end




-- if we have no external info about column, create only attribute and its categories create with auto enumeration of distinct values in column
function db.cleaning.createAttributeUninformative(column)
	attributeGroup= lm.prepro.findAttributeGroup({
		name= column.Name
	});

	attribute= lm.prepro.Attribute({
		name= column.Name,
		pAttributeGroup= attributeGroup,
		pDataColumn= column
	});

	db.cleaning.markUnknownXCategory(attribute,column.getDataColumnSubTypeCode())
	-- naplnenie atributu celym stlpcom
	attribute.autoCreateEnumeration({}); 
end



-- function that perofmrs cleaning of attributes
function db.cleaning.cleanAttributes(inputParams)
	lm.log( "Marking xcategories and naming categories of nominal/ordinal value");
	rootAttributeGroup= lm.prepro.getRootAttributeGroup();
	-- Prepare database tables array
	local dataTableArray= lm.explore.prepareDataTableArray();

	-- check for external info about tables
	if(inputParams.extInfo) then
		extTables = inputParams.extInfo["tables"]
	end

	if (not extTables) then
		lm.log("No tables in external info")
	end

	-- Iterate through all the database tables
	for i, dataTable in ipairs( dataTableArray) do
		if ( dataTable.isInitialized()) then
			
			local dataColumnArray= dataTable.prepareDataColumnArray();
			-- finds info about this table
			local extTable = db.cleaning.findInfoAboutTable(extTables, dataTable.Name)

			if(not extTable) then
				lm.log("Cant find external info about table "..dataTable.Name)
			end

			-- Iterate through all the columns
			for j, column in ipairs( dataColumnArray) do
				if ( (not column.isPrimaryKeyPart()) and (column.getValueSubTypeCode() ~= lm.codes.ValueSubType.DateTime)) then
					
					if(extTables and extTable) then --if exists external info about this table
						local extColumn = db.cleaning.findInfoAboutColumn(extTable["columns"], column.Name) -- find actual column
						if(extColumn) then -- create attribute with external info
							db.cleaning.createAttributeWithExternalInfo(extColumn, column)
						else -- create automatic attribute 
							db.cleaning.createAttributeUninformative(column)
						end
					else -- create automatic attribute 
						db.cleaning.createAttributeUninformative(column)    -- dolezita vec 
					end
					-- calculate cateogies frequency
					attribute.calcCategoryFrequencies()
				end
			end

		end
	end
end

-- main function of cleaning. Create attribute group for every column and then tries to clean all columns
function db.cleaning.performCleaning(inputParams) 
	lm.log( "Cleaning of attributes");

	bOpened= false;
	if ( not lm.metabase.isOpen()) then
	
		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.explore.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});
	
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

    db.cleaning.createAttributeGroups(inputParams)
    db.cleaning.cleanAttributes(inputParams)

	if (bOpened) then
		lm.metabase.markChanged();	
		lm.metabase.close();
	
		-- Create a backup copy for debug
		lm.metabase.backupMDB({
			pathNameSrc= inputParams.pathNameMetabase,
			pathNameDest= inputParams.pathNameMetabase.."_bkup.prepro_clean.mdb"
		});
	end;
		
end

return db.cleaning;