-- Semestralna praca Predspracovanie dat - Detekcia odlahlych pozorovani
-- Author: Trcka, části kódu převzaty z práce Bilík: Automatické předzpracování dat v LMCL
-- Date: 1. 5. 2015

-- Subor obsahuje skript na vypis reportu pre uzivatela co bolo vytvorene

db.report ={};



function db.report.getStringBracket(position,bracketType)
	
	if(bracketType==lm.codes.BracketType.Round) then
		if (position==1) then
			return ("(")
		else
			return (")")
		end
	else
		if (position==1) then
			return ("<")
		else
			return (">")
		end
	end
end

-- funkcia vracia retazec vytvoreny z kategorie
function db.report.getStringCategory(category)
			  local strCat=	""
				if (category.getCategorySubTypeCode()==lm.codes.CategorySubType.Interval) then
					--pre interval 
					categoryArray= category.prepareIntervalArray ()
					--luaTable
					for i, interval in ipairs( categoryArray) do
						if (i>1) then strCat = strCat ..", "end
																		-- toto je vystup z interval.getNameDefault()
						strCat=strCat..tostring(db.report.getStringBracket(1,interval.getLeftBracketTypeCode())..
																			interval.getValueFrom()..", "..
																			interval.getValueTo()..
																			db.report.getStringBracket(2,interval.getRightBracketTypeCode()))
					end
				
				else
				-----------pre kategoriua category.getNameDefault() -> vrati mi to iste ako tento cyklus
					categoryArray= category.prepareValueArray()
					-- array
					for i=1, #categoryArray do
						if (i>1) then strCat=strCat..", " end
						strCat=strCat..tostring(categoryArray[i])
					end
				---------------------------------------	
				end
				-- ak X-kategoria obsahuje Null hodnotu
				if(category.isIncludeNULLFlag() ) then
					if(strCat~="") then strCat=strCat..", " end
					strCat=strCat.."NULL"
				end
			return strCat
end


-- funkcia zapise vysledky do suboru
function db.report.createReport(inputParams) 
	lm.log( "Printing report");
	

	bOpened= false;
	if ( not lm.metabase.isOpen()) then
	
		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.prepro_transform.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});
	
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;
		-- ????
	lm.setLogVerbosityLevel( lm.codes.LogVerbosityLevel.Normal);
	lm.setLogFunctionParameterValuesFlag( false);
	
    db.report.printReport(inputParams)

	if (bOpened) then
		lm.metabase.close();
	
		-- Create a backup copy for debug
		lm.metabase.backupMDB({
			pathNameSrc= inputParams.pathNameMetabase,
			pathNameDest= inputParams.pathNameMetabase.."_bkup.report.mdb"
		});
	end;
end


-- funkcia zapisuje dynamicky do suboru report z metabaze
function db.report.printReport(inputParams) 


	rootAttributeGroup= lm.prepro.getRootAttributeGroup();
	attributeGroupArray= rootAttributeGroup.prepareSubAttributeGroupArray();
	
	--asociacia so suborom
	outputFile= io.open( inputParams.pathNameReportOutput, "w");
	local dataTableArray= lm.explore.prepareDataTableArray();
	outputFile:write(db.report.headSuboru())
	
	for ii, dataTable in ipairs( dataTableArray) do
		outputFile:write("<h1>Tabulka: "..dataTable.Name.."</h2>")
		outputFile:write("<h2>V nasledujucich atributoch boli oznacene X-kategorie:</h2>")
		outputFile:write("______________________________________________________________________________________<br /><br />")
	
				for i, attributeGroup in ipairs( attributeGroupArray) do
				-- priprava atributov zo skupin 
					attributeArray= attributeGroup.prepareAttributeArray({
						pDataTable= dataTable
					});
					-- pre vsetky atributy v skupinach
					for i, attribute in ipairs( attributeArray) do
						-- zvolenie X-kategorie
						local strCat=""
						if(attribute.hasXCategory()) then
						category=attribute.getXCategory()
						
						--ak X-kategoria nie je prazna
						
							strCat=db.report.getStringCategory(category)
							
						else
							strCat="X-kategoria nebola najdena"
						end
								outputFile:write("<strong>"..attribute.getName().."</strong>: ")
								outputFile:write(strCat.."<br />")	
		
					end
					outputFile:write("______________________________________________________________________________________<br /><br />")
				end

	end
	-- zatvorenie suboru	
	outputFile:write(db.report.footSuboru())
	io.close(outputFile)
end

-- retazec pre hlavicku
function db.report.headSuboru()
  vypisHlavicka= "<!DOCTYPE html>\n"..
				 "<html lang=\"en\">\n"..
                 "<head><link rel=\"stylesheet\" href=\"../doc/css/ems.css\" type=\"text/css\" /></head>\n"..
				 "<body>\n"..
				 "<center><font size=\"+3\">Predspracovanie dat Detekcia odlahlych pozorovani - Report</font></center>\n"
	
	return vypisHlavicka
end


--retazec pre zapatie
function db.report.footSuboru()
	vypisFooter= 	"</body>\n"..
					"</html>\n"
	return vypisFooter
end


	
return db.report