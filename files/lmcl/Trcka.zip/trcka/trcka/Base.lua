-- Semestral work about automatic preprocessing for lecture Knowledge Discovery in Databases
-- Author: David Bilik
-- Date: 3. 1. 2015

-- Definition of base namespace
db = {};

sysParams={
		-- konstanty pre nazvy atributov
		konstantyStr ={
			grubs="_Grubs", -- postfix pre atribut s x kategoriou podla grubsovho testu
			boxPlot="_BoxPlot", -- postfix pre atribut s x kategoriou podla BoxPlot metody
			fourSigma="_4Sigma",  -- postfix pre atribut s x kategoriou podla 4Sigma metody
			alternative="_alternativnyNazov",  -- postfix pre atribut s x kategoriou podla relativnych cetnosti
		},

		-- ciselne konstanty pouzite v kode
		konstantyInt ={
			minimalnaCetnost=0.005, -- minimalna cenost pre odlahle hodnoty testovane podla metody relativnych cetnosti
			distinctVal=20, -- minimalny pocet roznych hodnot aby sme atribut povazovali za nespojity, a mohli uplanit numericke metody
		},

		-- textove konstanty pre x kategorie
		konstantyXCat ={
			"?",
			"-",
			"N/A",
			"not set",
		},
}




return db;