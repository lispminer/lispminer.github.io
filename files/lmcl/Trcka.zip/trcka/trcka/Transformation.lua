-- Semestralna praca Predspracovanie dat - Detekcia odlahlych pozorovani
-- Author: Trcka, části kódu převzaty z práce Bilík: Automatické předzpracování dat v LMCL
-- Date: 1. 5. 2015

-- V subore ma na starosti spracovanie dat, detekciu odlahlych pozorovani podla 4 Sigma metody, Grubsovej metody a BoxPlot metody

db.prepro = {};
-- vytvori intervaly pre X kategorie podla metody BoxPlot
function db.prepro.createAttributeWithIntervals(column, minValOut,maxValOut)
-- sem poslem potom stlpec, s min, max, a toto mi urci atribut


		
		if (column.getMin() < minValOut or  maxValOut < column.getMax()) then
				-- najdenie adresara kategorii
				attributeGroup= lm.prepro.findAttributeGroup({
					name= column.Name
				});

				--konstruktor + specialny nazov
				attribute= lm.prepro.Attribute({
					name= column.Name..sysParams.konstantyStr.boxPlot,
					pAttributeGroup= attributeGroup,
					pDataColumn= column
				});
				
				

				category= lm.prepro.CategoryInterval({
					name= categoryName,
					pAttribute= attribute
				});
				category.XCategoryFlag= true
				category.IncludeNULLFlag= true;				

				-- vytvorenie dolneho intervalu pre X kategoriu
				if (column.getMin() < minValOut) then
					interval= lm.prepro.Interval({
						pCategoryInterval= category,
						valueFrom= column.getMin(), 
						valueTo= minValOut
					});
					interval.setRightBracketTypeCode( lm.codes.BracketType.Sharp);
				end
				
				-- vytvorenie horneho intervalu pre X kategoriu
				if ( maxValOut<column.getMax()) then
					interval= lm.prepro.Interval({
						pCategoryInterval= category,
						valueTo= column.getMax(), 
						valueFrom= maxValOut
					});
					interval.setRightBracketTypeCode( lm.codes.BracketType.Sharp);
				end
		attribute.autoCreateEnumeration({});

		end
		

		
		

end


-- 4Sigma a Grubsova metoda funguju iba na krajne hodnoty, preto musia byt X categorie urcene vymenovanim

-- vytvorenie X-categorie podla 4 sigma metody
function db.prepro.createAttributeByEnumaration4Sig(column, minValOut, maxValOut)

	
	if (column.getMin() <= minValOut or column.getMax() >= maxValOut) then
			
			attributeGroup= lm.prepro.findAttributeGroup({
				name= column.Name
			});
			--konstruktor + specialny nazov
			attribute= lm.prepro.Attribute({
				name= column.Name..sysParams.konstantyStr.fourSigma,
				pAttributeGroup= attributeGroup,
				pDataColumn= column
			});
			
			local category= lm.prepro.CategoryEnumeration({
				name= categoryName,
				pAttribute= attribute
			});
			category.XCategoryFlag= true;
			category.IncludeNULLFlag= true;
				
		if( column.getMin() <= minValOut) then
			category.includeValue({ value = column.getMin()});
		end
			
		if( column.getMax() >= maxValOut) then
			category.includeValue({ value = column.getMax()});
		end
		attribute.autoCreateEnumeration({});

																	

		
	end

end



-- vytvorenie X-categorie podla grubsovho metody
function db.prepro.createAttributeByEnumarationGrubs(column, gStat, avgVal, sigma)

	-- grubsove kriterium pre minimalnu hodnotu
	local kriteriumMin = avgVal-column.getMin()/sigma
	-- grubsove kriterium pre minimalnu hodnotu
	local kriteriumMax = column.getMax()-avgVal/sigma	
	
	if (kriteriumMin <= gStat or kriteriumMax >= gStat) then
	local retazec = ""
		attributeGroup= lm.prepro.findAttributeGroup({
				name= column.Name
		});
		--konstruktor + specialny nazov
		attribute= lm.prepro.Attribute({
			name= column.Name..sysParams.konstantyStr.grubs,
			pAttributeGroup= attributeGroup,
			pDataColumn= column
		});
		
		
		local category= lm.prepro.CategoryEnumeration({
			name= categoryName,
			pAttribute= attribute
		});
		category.XCategoryFlag= true;
		category.IncludeNULLFlag= true;
				
	
			if( kriteriumMin <= gStat) then
				category.includeValue({ value = column.getMin()});
			end
			
			
			if( kriteriumMax >= gStat) then
				category.includeValue({ value = column.getMax()});
			end
			attribute.autoCreateEnumeration({});
	end
end



-- vypocet uhrnu radu degree 
function db.prepro.getSumFromColumn(column,degree)
	vals, frequencies = column.prepareDistinctValueArray({})
	
	local sumFromColumn=0
	local n=0
	for i= 1, #vals do
		if(vals[i]) then
			sumFromColumn=frequencies[i] * vals[i]^degree+sumFromColumn
			n=n+frequencies[i]
		end
	end;
	sumFromColumn = sumFromColumn/n
	return sumFromColumn, n
end

-- urcenie smerodatnej chyby v stlpci
function db.prepro.getSigma(m2,avgVal)
	sumSquared = m2
	var = sumSquared-avgVal^2
	local sigma = var^(0.5)
	return sigma
end

-- vypocet critickej hodnoty minima a maxima pre 4 sigma test
function db.prepro.criticalValue4Sigma(avgVal,valueSigma)
	local maxCriticalValue4Sigma =  avgVal + valueSigma *4
	local minCriticalValue4Sigma =  avgVal - valueSigma *4
	return minCriticalValue4Sigma, maxCriticalValue4Sigma
end

-- urcenie G statistiky na porovnanie
function db.prepro.grubsStats(n)
	G=(n-1)/n*1.41
	return G
end

function db.prepro.getQuartils(column,n)
	vals, frequencies = column.prepareDistinctValueArray({})
	
	local tabulka={}
	local pos=1
	for i= 1, #vals do
		if (vals[i]) then
			for j=1, frequencies[i] do
				tabulka[pos]=vals[i]
				pos=pos+1
				--lm.log("hodnoty valls:  "..tabulka[i+j-1])
			end
		end
	end;
	
	--table.sort(tabulka, function(a,b) return a<b end)
	
	local sumFromColumn=0
	local nQuantil=0
	local lowQuartile=nil
	local highQuartile=nil
	
	

	for i= 1, #tabulka do
		if(i>=n*0.25 and i<1+n*0.25) then
			lowQuartile= tabulka[i]
		end
		if(i>=n*0.75 and i<1+n*0.75) then
			highQuartile= tabulka[i]
			break
		end
	end

	return lowQuartile, highQuartile
	
end
-- vrati extremne hodnoty medzikvartiloveho rozpatia
function db.prepro.getIqrExtreme(lowQuartile, highQuartile)
	
	local iqr = highQuartile-lowQuartile
	local lowExtreme= lowQuartile-1.5*iqr
	local highExtreme= highQuartile+1.5*iqr
	
	return lowExtreme, highExtreme
end

-- vytvori X kategorie pre jednotlive atributy
function db.prepro.createXCatForNumAttributes(column, numOfBins) 
	vals, frequencies = column.prepareDistinctValueArray({})
	-- prepareDistinctValueArray returns even a nil value so we make other array without that value

	-- vypocet zakladnych statistik pre urcenie kritickych hodnot
		m2, n = db.prepro.getSumFromColumn(column,2)
		columnAvgVal = column.getAvg()
		valSigma = db.prepro.getSigma(m2,columnAvgVal)
	
	-- kriticke hodnoty metoda 4 sigma
		minValOut, maxValOut = db.prepro.criticalValue4Sigma(columnAvgVal,valSigma)
		db.prepro.createAttributeByEnumaration4Sig(column, minValOut, maxValOut)

	
	-- kriticke hodnoty metoda Grubsov Test
		gStat=db.prepro.grubsStats(n)
		db.prepro.createAttributeByEnumarationGrubs(column, gStat, columnAvgVal,valSigma)
	
	-- kriticke intervaly metoda BoxPlot
		dolnyQuartil, hornyQuartil = db.prepro.getQuartils(column,n)
		lowExtreme, highExtreme = db.prepro.getIqrExtreme(dolnyQuartil, hornyQuartil)

		db.prepro.createAttributeWithIntervals(column, lowExtreme,highExtreme)
		

end


function db.prepro.markUnknownXCat(column, nazovStlpca) 
	
	attributeGroup= lm.prepro.findAttributeGroup({
		name= column.Name
	});

	
	--konstruktor + specialny nazov
	attribute= lm.prepro.Attribute({
		name= column.Name..sysParams.konstantyStr.alternative,
		pAttributeGroup= attributeGroup,
		pDataColumn= column
	});
	
	local category= lm.prepro.CategoryEnumeration({
		name= categoryName,
		pAttribute= attribute
	});
	
	category.XCategoryFlag= true;
	
		mistakes = db.prepro.getOverStrike(column)
		for i=1, #mistakes do
			category.includeValue({ value = mistakes[i] })
		end
		
		category.IncludeNULLFlag= true;
		db.prepro.enumerationXCatString(category) 

		attribute.autoCreateEnumeration({});
end

-- funkcia naplni xKategoriu podla nastevej konstanty konstantyXCat
function db.prepro.enumerationXCatString(category)
	for jj, xCatStr in ipairs( sysParams.konstantyXCat) do
		category.includeValue({ value = xCatStr});
	end 
end



-- funkcia vrati retazce, ktore obsahuju preklpey
function db.prepro.getOverStrike(column)
	vals, frequencies = column.prepareDistinctValueArray({})
	
	local sumFromColumn=0
	local n=0
	for i= 1, #vals do
		if(vals[i]) then
			n=n+frequencies[i]
		end
	end;
	
	local mistakes={}
	pos=1
	for i= 1, #frequencies do
		if(frequencies[i]<sysParams.konstantyInt.minimalnaCetnost*n) then
			mistakes[pos]=vals[i]
			pos=pos+1
		end
	end;

	return mistakes
end

-- iterate through every table and every column and if column is numeric, than perform transformation of that column
function db.prepro.transformAttributes()

	lm.log("Transforming data")
	rootAttributeGroup= lm.prepro.getRootAttributeGroup();
	-- Prepare database tables array
	local dataTableArray= lm.explore.prepareDataTableArray();

	-- Iterate through all the database tables
	for i, dataTable in ipairs( dataTableArray) do
		if ( dataTable.isInitialized()) then
			local dataColumnArray= dataTable.prepareDataColumnArray();
			-- Iterate through all the columns
			for j, column in ipairs( dataColumnArray) do
				if (not column.isPrimaryKeyPart()) then
				
					if(column.getDatePartSubTypeCode()==lm.codes.DatePartSubType.NotSet) then
						if(column.getValueSubTypeCode() == lm.codes.ValueSubType.Integer or  column.getValueSubTypeCode() == lm.codes.ValueSubType.Float) then -- numerical data type
							distinctValueCount= column.getDistinctValueCount();
							if(distinctValueCount >= sysParams.konstantyInt.distinctVal) then	
								db.prepro.createXCatForNumAttributes(column);
							end
						else
							if(column.getValueSubTypeCode() == lm.codes.ValueSubType.String) then
								db.prepro.markUnknownXCat(column,"relativnaCetnost")
							end
						end
					end
				end
			end
		end
	end
end



-- main function of transforming that is opening a metabase and calling a trasnforming function
function db.prepro.performTransforming(inputParams) 
	bOpened= false;
	if ( not lm.metabase.isOpen()) then
	
		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.prepro_clean.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});
	
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

    db.prepro.transformAttributes();
	if (bOpened) then
		--lm.metabase.markChanged();	
		lm.metabase.close();
		lm.log("After close")

		-- Create a backup copy for debug
		lm.metabase.backupMDB({
			pathNameSrc= inputParams.pathNameMetabase,
			pathNameDest= inputParams.pathNameMetabase.."_bkup.prepro_transform.mdb"
		});
	end;

end

return db.prepro;