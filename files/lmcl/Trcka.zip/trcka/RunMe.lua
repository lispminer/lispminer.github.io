-- Semestralna praca Predspracovanie dat - Detekcia odlahlych pozorovani
-- Author: Trcka, části kódu převzaty z práce Bilík: Automatické předzpracování dat v LMCL
-- Date: 1. 5. 2015


-- Tento subor riadi celu automatizaciu detekovania odlahlych pozorovani.
-- Importuje vsetky dolezite kniznice a subory





--================================================================
--                        NAZOV SUBORU 
                     nazovDB = "HotelBooking"
--
--================================================================


























--======================================================================================================================================================================================
--======================================================================================================================================================================================
--======================================================================================================================================================================================

-- import preddefinovanych konstant
local lm= require( "Exec/Lib/LMGlobal");









-- LM log uvodny popis
lm.log( "SEMESTRALNA PRACA - DETEKCIA ODLAHLYCH POZOROVANI");
lm.log( "Autor: Peter Trcka");
lm.log( "Import kniznic ...");

-- Look-up packages also in the script folder
package.path= package.path..";"..lm.getScriptDirectory().."?.lua";

-- Import funkcii, ktore su potrebne pre chod programu
require( "trcka/Base");
require( "trcka/Metabase");
require( "trcka/Explore");
require( "trcka/Cleaning");
require( "trcka/Transformation");
require( "trcka/Report");


-- Log start
-- Helpful functions

-- read file with json and use JSON library to convert it to table
function readJSON(path) 
	JSON = assert(loadfile (lm.getScriptDirectory().."trcka/JSON.lua"))() -- one-time load of the routines
	return JSON:decode(readFileAsString(path))
end

-- read data from file and return them as string
function readFileAsString(path) 
	 local f = assert(io.open(path, "r"))
	 local content  = f:read("*all")
	 f:close()
	 return content
end

-- =============================================================================
-- Deklaracia zakladnych parametrov skriptu

-- databaze Entry
		inputParams= {

			-- path and file name to source text file	
			pathNameDataSrc=  lm.getScriptDirectory().."data/"..nazovDB..".txt",

			-- path and file name of the database to create
			pathNameDataDest= lm.getScriptDirectory().."DB/"..nazovDB..".DB.mdb",

			-- path and file name of the metabase to create
			pathNameMetabase= lm.getScriptDirectory().."DB/"..nazovDB..".LM.mdb", 

			-- database table name to be created
			tableName= nazovDB,												

			-- base ODBC DataSourceName for both metabase and data
			dsnBase= "Exec "..nazovDB,

			-- analytical report to be created
			pathNameReportOutput= lm.getScriptDirectory().."report/"..nazovDB..".html",

			-- table with external info about table
			extInfo = readJSON(lm.getScriptDirectory().."data/entry_info.json"),

		};


-- store old level of log verbosity
oldLevel = lm.setLogVerbosityLevel(lm.codes.LogVerbosityLevel.Normal)

-- =============================================================================
-- Data and metabase initialization
--Beh kodu------
-- =============================================================================
lm.log( "Data and metabase initialization.");
lm.logIndentUp();

db.metabase.createDataAndMetabase( inputParams); --- vytvorenie tabuliek lispminer a spol, subor Metabase.lua

lm.logIndentDown();

-- =============================================================================

-- =============================================================================
-- Data exploration

lm.log( "Data exploration.");
lm.logIndentUp();

db.explore.initTables(inputParams); --vytvorenie tabuliek a priparneho kluca, subor Explore.lua

lm.logIndentDown();

-- =============================================================================

-- =============================================================================
-- Data preprocessing
lm.log( "Data cleaning. ");
lm.logIndentUp();

db.cleaning.performCleaning( inputParams); -- subor Cleaning.lua
lm.logIndentDown();

lm.log("Data transformation.")

lm.logIndentUp()
db.prepro.performTransforming( inputParams); -- subor Transformation.lua
lm.logIndentDown();


-- =============================================================================
-- Print out report file

db.report.createReport(inputParams) -- subor Report.lua

-- =============================================================================
-- Close the metabase
lm.metabase:close();

-- Log finish
lm.logInfo( "LMExec Script End");
-- Set old log verbosity level
lm.setLogVerbosityLevel(oldLevel)