-- Semestral work about automatic preprocessing for lecture Knowledge Discovery in Databases
-- Author: David Bilik
-- Date: 3. 1. 2015

-- In this file the information about performed operation on data are printed to report file 

db.report ={};

function db.report.printReport(inputParams) 
	outputFile= io.open( inputParams.pathNameReportOutput, "w");

	local dataTableArray= lm.explore.prepareDataTableArray();

	for i, dataTable in ipairs( dataTableArray) do
		outputFile:write("Table: "..dataTable.Name.."\n")
		if ( dataTable.isInitialized()) then

			local dataColumnArray= dataTable.prepareDataColumnArray();
			-- Iterate through all the columns
			for j, column in ipairs( dataColumnArray) do
				outputFile:write("\tColumn: "..column.Name.."\n")
				if(#reportHolder[column.Name] > 0) then 
					for k = 1, #reportHolder[column.Name] do
						outputFile:write("\t\t"..(reportHolder[column.Name])[k].."\n")
					end
				else
					outputFile:write("\t\tNo info about this column\n")
				end
			end
		end
	end
	io.close(outputFile)
end


function db.report.createReport(inputParams) 
	lm.log( "Printing report");
	

	bOpened= false;
	if ( not lm.metabase.isOpen()) then
	
		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.prepro_transform.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});
	
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

    db.report.printReport(inputParams)

	if (bOpened) then
		lm.metabase.close();
	
		-- Create a backup copy for debug
		lm.metabase.backupMDB({
			pathNameSrc= inputParams.pathNameMetabase,
			pathNameDest= inputParams.pathNameMetabase.."_bkup.report.mdb"
		});
	end;
end

return db.report