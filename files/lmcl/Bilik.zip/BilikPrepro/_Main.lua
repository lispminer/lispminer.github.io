-- Semestral work about automatic preprocessing for lecture Knowledge Discovery in Databases
-- Author: David Bilik
-- Date: 3. 1. 2015

-- This file is main entry to the program. It loads all important libraries and functions and control its running

-- Import predefined constants
local lm= require( "Exec/Lib/LMGlobal");

-- holder that contains info about performing operations on every columns
reportHolder = {}

-- Import functions that are needed for 
require( "Exec/BilikPrepro/Base");
require( "Exec/BilikPrepro/Metabase");
require( "Exec/BilikPrepro/Explore");
require( "Exec/BilikPrepro/Cleaning");
require( "Exec/BilikPrepro/Transformation");
require( "Exec/BilikPrepro/Report");

-- Log start
lm.log( "SEMESTRAL PROJECT - PREPROCESSING");


-- Helpful functions

-- read file with json and use JSON library to convert it to table
function readJSON(path) 
	JSON = assert(loadfile (lm.getLMRootDirectory().."Exec/BilikPrepro/JSON.lua"))() -- one-time load of the routines
	return JSON:decode(readFileAsString(path))
end

-- read data from file and return them as string
function readFileAsString(path) 
	 local f = assert(io.open(path, "r"))
	 local content  = f:read("*all")
	 f:close()
	 return content
end

-- =============================================================================
-- Summary of this script input parameters
inputParams= {

	-- path and file name to source text file	
	pathNameDataSrc=  lm.getLMRootDirectory().."Exec/BilikPrepro/data/Entry.txt",

	-- path and file name of the database to create
	pathNameDataDest= lm.getLMRootDirectory().."Exec/BilikPrepro/DB/Entry.DB.mdb",

	-- path and file name of the metabase to create
	pathNameMetabase= lm.getLMRootDirectory().."Exec/BilikPrepro/DB/Entry.LM.mdb", 

	-- database table name to be created
	tableName= "Entry",												

	-- base ODBC DataSourceName for both metabase and data
	dsnBase= "Exec Entry",

	-- analytical report to be created
	pathNameReportOutput= lm.getLMRootDirectory().."Exec/BilikPrepro/report/Entry.html",

	-- table with external info about table
	extInfo = readJSON(lm.getLMRootDirectory().."Exec/BilikPrepro/data/entry_info.json"),

};
-- store old level of log verbosity
oldLevel = lm.setLogVerbosityLevel(lm.codes.LogVerbosityLevel.Normal)

-- =============================================================================
-- Data and metabase initialization

lm.log( "Data and metabase initialization.");
lm.logIndentUp();

db.metabase.createDataAndMetabase( inputParams);

lm.logIndentDown();

-- =============================================================================
-- Data exploration

lm.log( "Data exploration.");
lm.logIndentUp();

db.explore.initTables( inputParams);

lm.logIndentDown();

-- =============================================================================
-- Data preprocessing
lm.log( "Data cleaning. ");
lm.logIndentUp();

db.prepro.performCleaning( inputParams);
lm.logIndentDown();
lm.log("Data transformation.")

lm.logIndentUp()
db.prepro.performTransforming( inputParams);
lm.logIndentDown();

-- =============================================================================
-- Print out report file

db.report.createReport(inputParams)

-- =============================================================================
-- Close the metabase
lm.metabase:close();

-- Log finish
lm.logInfo( "LMExec Script End");
-- Set old log verbosity level
lm.setLogVerbosityLevel(oldLevel)


