
-- Semestral work about automatic preprocessing for lecture Knowledge Discovery in Databases
-- Author: David Bilik
-- Date: 3. 1. 2015

-- This file is responsible for transformation of data, especially of making equal-height binning of numerical data. Intervals are made in two ways - from equal width intervals and with genetic algorithm


-- creates attribute with intervals array. this function is common for both ways of creating intervals
function createAttributeWithIntervals(column, intervals, numOfBins, nameSuffix)


	attributeGroup= lm.prepro.findAttributeGroup({
		name= column.Name
	});

	

	attributeName = column.Name.."_eqf_"..nameSuffix.."#"..numOfBins
	attribute= lm.prepro.Attribute({
		name= attributeName,
		pAttributeGroup= attributeGroup,
		pDataColumn= column
	});
	-- probable bug, if i uncomment this lines, the LmExec crashes
	--baseAttribute = lm.prepro.findAttribute({name = column.Name}) 
	--if(baseAttribute and baseAttribute.hasXCategory()) then
	--		attribute.setXCategory(baseAttribute.getXCategory())
	--	end

	for i, intervalStruct in ipairs(intervals) do 
		categoryName= "interval";	-- just a temporary name
		category= lm.prepro.CategoryInterval({
			name= categoryName,
			pAttribute= attribute
		});
			
		interval= lm.prepro.Interval({
			pCategoryInterval= category,
			valueFrom= intervalStruct.left,
			valueTo= intervalStruct.right
		});
		if(i == numOfBins) then
			interval.setRightBracketTypeCode( lm.codes.BracketType.Sharp);
		else
			interval.setRightBracketTypeCode( lm.codes.BracketType.Round);
		end
		
		category.Name= category.getNameDefault();
	end
end

-- generate one gene with random initial values. (numOfBins - 1) ones are placed to genes data array
function generateRandomGene(vals, numOfBins)
	gene = {}
	size = #vals - 1
	gene.data = {n = size}
	gene.size = size
	
	i = 1
	while i <= numOfBins -1 do
		pos = math.random(size)
		if(not gene.data[pos]) then -- not filled, then filled it and increment counter
			gene.data[pos] = true
			i = i + 1
		end
	end
	return gene
end

-- helpful function for string representation of gene - true = 1, nil = 0
function getGeneBitString(gene)
	s = ""
	for i = 1, gene.size do
		if(gene.data[i]) then
			s = s.."1"
		else
			s = s.."0"
		end
	end
	return s
end

-- function that computes fitness of gene. It comptues sum of differences each interval from ideal width of interval
function computeFitness(gene, vals, frequencies, idealWidth) 
	prevPos = 0
	sum = 0
	sumInInterval = 0
	for i = 1, #vals do 
		sumInInterval = sumInInterval + frequencies[i]
		if(i < #vals and gene.data[i]) then
			sum = sum + math.abs(idealWidth - sumInInterval)
			sumInInterval = 0
		end
	end
	--last intervals
	sum = sum + math.abs(idealWidth - sumInInterval)
	return sum
end

-- generates random population and compute its initial fitness
function generateRandomPopulation(vals, frequencies, numOfBins, populationCount, idealWidth)
	population = {n = populationCount}
	for i = 1, populationCount do
		population[i] = generateRandomGene(vals, numOfBins)
		population[i].fitness = computeFitness(population[i], vals, frequencies, idealWidth)
 	end
 	return population
end

-- get ideal width of interval. The equation is N / k, where N is number of observation and k is number of bins
function getIdealWidth(frequencies, numOfBins)
	numberOfObservations = 0
	for i = 1, #frequencies do
		numberOfObservations = numberOfObservations + frequencies[i]
	end

	return math.ceil(numberOfObservations / numOfBins)
end

-- perform roulette wheel selection from population.
function rouletteWheelSelection(population, fitnessSum)
    randFitness = math.random(fitnessSum)
    sum = 0
    for i, gene in ipairs(population) do
        sum = sum + gene.fitness
        if (sum >= randFitness) then
            return gene
        end
    end

end

-- correction of gene. Three cases may happen: 
-- 1) gene has correct number of ones, in that case no modification is performed. 
-- 2) gene has more ones that should have, in that case random ones are removed to desired count
-- 3) gene has less ones that should have, int that case random ones are placed to empty places
function correct(gene, numOfBins)
	numOfOnes = 0
	for i = 1, gene.size do
		if(gene.data[i]) then
			numOfOnes = numOfOnes + 1
		end
	end
	if(numOfOnes == numOfBins - 1) then -- everything is fine, return original gene
		return gene
	end
	if(numOfOnes < numOfBins -1) then -- too little ones, generate random ones
		
		while(numOfOnes < numOfBins - 1) do
			pos = math.random(gene.size)
			if(not gene.data[pos]) then
				gene.data[pos ] = true
				numOfOnes = numOfOnes + 1
			end
		end
	else  -- too much ones, remove random ones
		while(numOfOnes > numOfBins - 1) do
			pos = math.random(gene.size)
			if(gene.data[pos]) then
				gene.data[pos ] = nil
				numOfOnes = numOfOnes - 1
			end
		end
	end
	return gene
end

-- perform cross over of two genes. Random number of ones is taken from first gene and the rest is taken from second gene. For other new gene the genes are switched. This may lead to invalid genes that needs to be corrected
function crossOver(first, second, numOfBins) 
	onesFromFirst = math.random(numOfBins - 1) -- random number of ones from one gene
	onesFromSecond = numOfBins - 1 - onesFromFirst -- the rest is taken from second gene
	newFirst = {}
	newSecond = {}
	j = 1
	currentOnes = 0
	newFirst.data = {n = first.size}
	newFirst.size = first.size
	newSecond.data = {n = first.size}
	newSecond.size = first.size
	-- creating first gene
	while(j <= first.size) do -- takes from first 
		if(currentOnes <= onesFromFirst) then
			newFirst.data[j] = first.data[j]
		else
			break;
		end
		if(newFirst.data[j]) then
			currentOnes = currentOnes + 1
		end 
		j  =j + 1
	end
	j = first.size
	currentOnes = 0
	while j >=1 do -- takes from second
		if(currentOnes <= onesFromSecond) then
			newFirst.data[j] = second.data[j]
		else
			break;
		end
		if(newFirst.data[j]) then
			currentOnes = currentOnes + 1
		end 
		j = j - 1
	end
    j = 0
    -- creating second gene
	while(j <= first.size) do -- takes from first
		if(currentOnes <= onesFromFirst) then
			newSecond.data[j] = second.data[j]
		else
			break;
		end
		if(newSecond.data[j]) then
			currentOnes = currentOnes + 1
		end 
		j = j + 1
	end
	j = first.size
	currentOnes = 0
	while(j >= 1 ) do -- takes from second
		if(currentOnes <= onesFromSecond) then
			newSecond.data[j] = first.data[j]
		else
			break;
		end
		if(newSecond.data[j]) then
			currentOnes = currentOnes + 1
		end 
		j = j - 1
	end
	return newFirst, newSecond
end

-- mutation of gene. With MUTATION_PROB probability the 1 is moved to left/right position. All cases of 1s position have to be checked
function mutate(gene)
	MUTATION_PROB = 0.01
	for i = 1, gene.size do
		if(gene.data[i]) then
			if(math.random() < MUTATION_PROB) then
				if(i == 1 and (not gene.data[i + 1] )) then -- first 1 in array and next is nil
					gene.data[i] = nil
					gene.data[i+1] = true
				else
					if(i == #gene.data and (not gene.data[i - 1] )) then -- last 1 in array and previous is nil
						gene.data[i] = nil
						gene.data[i-1] = true	
					else
						if((not gene.data[i-1]) and not(gene.data[i+1])) then -- both sides are empty, switch a coin and on one side place 1
							side = math.random(2)
							gene.data[i] = nil
							if(side == 1) then
								gene.data[i+1] = true
							else
								gene.data[i-1] = true
							end
						else
							if (not gene.data[i-1]) then -- left is nil
								gene.data[i] = nil
								gene.data[i-1] = true
							end
							if (not gene.data[i+1]) then -- right is nil
								gene.data[i] = nil
								gene.data[i+1] = true
							end
						end
					end
				end
			end
		end
	end
	return gene
end

-- create new population from the old one. Performs selection, crossover, mutation and correction
function createNewPopulation(oldPopulation, vals, frequencies, numOfBins) 
	CROSSOVER_PROB = 0.8
	
	newPopulation = {}
	fitnessSum = 0
	for i = 1, #oldPopulation do
		fitnessSum = fitnessSum + oldPopulation[i].fitness
	end

	for i = 1, #oldPopulation, 2 do
		first = rouletteWheelSelection(oldPopulation, fitnessSum)
		second = rouletteWheelSelection(oldPopulation, fitnessSum)	
		if(math.random() < CROSSOVER_PROB) then --perform cross over
			first, second = crossOver(first, second, numOfBins)
		end
		--mutation
		first = mutate(first)
		second = mutate(second)
		-- correct invalid values
		first = correct(first, numOfBins)
		second = correct(second, numOfBins)
		-- add to new population
		newPopulation[i] = first
		newPopulation[i+1] = second
	end
	return newPopulation
end

-- create intervals from best found gene
function getIntervalsFromGene(gene,vals) 
	intervals = {}
	currentInterval = {}
	-- first interval start
	currentInterval.left = vals[1]
	intervalPos = 1
	for i = 1, gene.size do
		if(gene.data[i]) then
			currentInterval.right = vals[i+1]
			intervals[intervalPos] = currentInterval
			intervalPos = intervalPos + 1
			currentInterval = {}
			currentInterval.left = vals[i+1]
		end
	end
	--last interval end
	currentInterval.right = vals[#vals]
	intervals[intervalPos] = currentInterval

	return intervals
end

-- generate intervals using genetic algorithm. Contains main GA loop 
function getIntervalsUsingGA(vals, frequencies, numOfBins, column)
	generations = 500
	populationCount = 100
	idealWidth = getIdealWidth(frequencies, numOfBins)
	-- generate random intitial population
	population = generateRandomPopulation(vals, frequencies, numOfBins, populationCount, idealWidth)
	bestEverGene = nil
	
	for genereation = 1, generations do
		
		--compute new fitness
		for i, gene in ipairs(population) do
			gene.fitness = computeFitness(gene, vals, frequencies, idealWidth)
		end

		-- remember best one
		currentBest = population[1]
		for i, gene in ipairs(population) do
			if gene.fitness < currentBest.fitness then
				currentBest = gene
			end
		end
		if not bestEverGene or currentBest.fitness < bestEverGene.fitness then
			bestEverGene = currentBest
		end
		-- we have the best solution, we can end
		if(bestEverGene.fitness == 0) then
			break;
		end
	--	lm.log("Best one: "..bestEverGene.fitness .. " repre: "..getGeneBitString(bestEverGene))
	--	lm.log("Best one in population : "..currentBest.fitness .. " repre: "..getGeneBitString(currentBest))
		population = createNewPopulation(population, vals, frequencies, numOfBins)
	end
	return getIntervalsFromGene(bestEverGene, vals)
end

-- create attribute with genetic algorithm
function createIntervalsWithGA(column, vals, frequencies ,numOfBins) 

	intervals = getIntervalsUsingGA(vals,frequencies, numOfBins, column)
	
	createAttributeWithIntervals(column, intervals, numOfBins, "ga")
end

-- get count of the same number that is on border of interval that divider is separating. This is counting the numbers in previous interval
function getNumberCountBeforeDivider(vals, divider) 
	nums = 0
	num = vals[divider]
	for i = divider, 1,-1 do
		if vals[i] ~= num then
			break
		end
		nums = nums + 1
	end
	return nums
end

-- get count of the same number that is on border of interval that divider is separating. This is counting the numbers in next interval
function getNumberCountAfterDivider(vals, divider, n) 
	nums = 0
	num = vals[divider]
	for i = divider, n do
		if vals[i] ~= num then
			break
		end
		nums = nums + 1
	end
	return nums
end

-- create intervals from computed interval dividers
function createIntervalsFromDividers(values, dividers, numOfBins, n)
	intervals = {}
	for i =1,  numOfBins do
		currentInterval = {}
		currentInterval.left = values[dividers[i]+1]
		if (i==numOfBins) then -- special case for last one, place the last position in values array
			currentInterval.right = values[n]
		else
			currentInterval.right = values[dividers[i+1]+1]
		end
		currentInterval.count = dividers[i+1] - dividers[i]
		intervals[i] = currentInterval 
	end
	return intervals
end

-- get intervals with the best equally distributed values
function getIntervals(values, frequencies, numOfBins)
	numberOfObservations = 0
	for i = 1, #frequencies do
		numberOfObservations = numberOfObservations + frequencies[i]
	end

	approxWidth = math.ceil(numberOfObservations / numOfBins)
	dividers = {}
	fullArray = {}
	pos = 1

	for i= 1, #values do
		for j = 1, frequencies[i] do
			fullArray[pos] = values[i]
			pos = pos + 1
		end
	end
	dividers[1] = 0
	-- first place dividers with the same width across all values. This may lead to placing divider between the same numbers and it needs to be corrected
	for i = 2, numOfBins do
		dividers[i] =  approxWidth * (i-1)
	end
	dividers[numOfBins+1] = numberOfObservations
	i = 2
	while i < numOfBins do 
		intervalEnd = fullArray[dividers[i]]
		nextIntervalStart = fullArray[dividers[i]+1]
		-- if divider is between the same numbers
		if intervalEnd == nextIntervalStart then
			-- computes count of number in each interval and the rest place to the one that will lead to smaller error 
			numBefore = getNumberCountBeforeDivider(fullArray, dividers[i])
			numAfter = getNumberCountAfterDivider(fullArray, dividers[i]+1, numberOfObservations)
			prevIntervalSize = dividers[i] - dividers[i-1]
			nextIntervalSize = dividers[i+1] - dividers[i]
			toFirst =  math.abs(prevIntervalSize + numAfter - approxWidth) + math.abs(nextIntervalSize - numAfter - approxWidth)
			toSecond = math.abs(prevIntervalSize - numBefore - approxWidth) + math.abs(nextIntervalSize + numBefore - approxWidth)

			if(numAfter >= nextIntervalSize) then -- if number count in next interval is greater than size of that interval, create special interval just for this one number and move the remaining dividers equally distributed at the rest of array
				dividers[i] = dividers[i] - numBefore
				dividers[i+1] = dividers[i] + numBefore + numAfter
				rem = numberOfObservations - dividers[i+1]
				remDividers = numOfBins - i 
				newWidth = math.ceil(rem / remDividers)
				for j = i + 2, numOfBins do

					dividers[j] = dividers[i+1] + (j - i - 1) * newWidth
				end
				i = i + 1
			else
				if toFirst < toSecond then -- its better to give same values to first interval
					dividers[i] = dividers[i]  + numAfter
				else -- its better to give same values to second interval
					dividers[i] = dividers[i]  - numBefore
				end
			end
		end
		i = i + 1
	end


	return createIntervalsFromDividers(fullArray, dividers,numOfBins ,numberOfObservations)
	
end

-- create automatic equal-frequency intervals that are built inside lmcl framework
function createAutomaticEQF(column, numOfBins) 
	attributeGroup= lm.prepro.findAttributeGroup({
		name= column.Name
	});

	attributeName = column.Name.."_eqf_auto#"..numOfBins
	attribute= lm.prepro.Attribute({
		name= attributeName,
		pAttributeGroup= attributeGroup,
		pDataColumn= column
	});

	attribute.autoCreateIntervalEquifrequency({nCount = numOfBins})
end

-- create equifreqnecy interval with all possible methods
function createEquiFrequenceAttribute(column, numOfBins) 
	vals, frequencies = column.prepareDistinctValueArray({})
	-- prepareDistinctValueArray returns even a nil value so we make other array without that value
    valsWithoutNil = {}
    freqs = {}
    pos = 1
	for i= 1, #vals do
		if(vals[i]) then
			valsWithoutNil[pos] = vals[i]
			freqs[pos] = frequencies[i]
			pos = pos + 1
		end
	end;
	intervals = getIntervals(valsWithoutNil, freqs, numOfBins, column)
	createAttributeWithIntervals(column, intervals, numOfBins, "div")
	createIntervalsWithGA(column, valsWithoutNil, frequencies, numOfBins)
	createAutomaticEQF(column, numOfBins)
end

-- iterate through every table and every column and if column is numeric, than perform transformation of that column
function db.prepro.transformAttributes()

	lm.log("Transforming data")
	rootAttributeGroup= lm.prepro.getRootAttributeGroup();
	-- Prepare database tables array
	local dataTableArray= lm.explore.prepareDataTableArray();

	-- Iterate through all the database tables
	for i, dataTable in ipairs( dataTableArray) do
		if ( dataTable.isInitialized()) then
			local dataColumnArray= dataTable.prepareDataColumnArray();
			-- Iterate through all the columns
			for j, column in ipairs( dataColumnArray) do
				if (not column.isPrimaryKeyPart()) then
					if(column.getValueSubTypeCode() == lm.codes.ValueSubType.Integer or  column.getValueSubTypeCode() == lm.codes.ValueSubType.Float) then -- numerical data type
						distinctValueCount= column.getDistinctValueCount();
						if(distinctValueCount >= 20) then -- probably not nominal with that count of distinct values
							-- possible feature of this program is to perfom some kind of guess of bins count
							numOfBins = 20
							(reportHolder[column.Name])[#reportHolder[column.Name]+1] = "Creating intervals of size "..numOfBins.." with algorithm adjusting equal-width intervals"
							(reportHolder[column.Name])[#reportHolder[column.Name]+1] = "Creating intervals of size "..numOfBins.." with genetic algorithm"
							(reportHolder[column.Name])[#reportHolder[column.Name]+1]= "Creating intervals of size "..numOfBins.." with built-in algorithm"
							createEquiFrequenceAttribute(column,numOfBins);
						end
					end
				end
			end
		end
	end
end

-- main function of transforming that is opening a metabase and calling a trasnforming function
function db.prepro.performTransforming(inputParams) 
	bOpened= false;
	if ( not lm.metabase.isOpen()) then
	
		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.prepro_clean.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});
	
		lm.metabase.open({
			dataSourceName= db.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

    db.prepro.transformAttributes();
	if (bOpened) then
		--lm.metabase.markChanged();	
		lm.metabase.close();
		lm.log("After close")

		-- Create a backup copy for debug
		lm.metabase.backupMDB({
			pathNameSrc= inputParams.pathNameMetabase,
			pathNameDest= inputParams.pathNameMetabase.."_bkup.prepro_transform.mdb"
		});
	end;

end

return db.prepro;