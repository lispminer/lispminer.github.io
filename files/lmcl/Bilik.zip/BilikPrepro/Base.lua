-- Semestral work about automatic preprocessing for lecture Knowledge Discovery in Databases
-- Author: David Bilik
-- Date: 3. 1. 2015

-- Definition of base namespace
db = {};

return db;