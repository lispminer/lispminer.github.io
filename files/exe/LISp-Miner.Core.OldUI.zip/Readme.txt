========================================================================
* 		   LISp-Miner system readme file		       *	
========================================================================

CONTENTS
////////////////////////////////////////////////////////////////////////

1) Preface
2) Downlaoad
3) Basic of installation
4) Setting-up database
5) List of files

1) PREFACE
////////////////////////////////////////////////////////////////////////

This file contains basic summary of download, installation and what you 
will find in the each of LISp-Miner packages.

For detail information please refer to the home page of the LISp-Miner
system at http://lispminer.vse.cz.

2) Download
////////////////////////////////////////////////////////////////////////

There is no all-in-one file for download. You have to download each
LISp-Miner subsystem separately. We recommend to download the LM.4ft.zip
file for start. It contains the 4ft-Miner subsystem modules with all the
additional files needed to begin work.

The LMAdmin.exe, LM DataSource.exe and LMEmpty.mdb are neccessary for
all the subsystems. They can be download in the standalone file
LM.PP.zip or together with the 4ft-Miner subsystem in the LM.4ft.zip
file.

3) Basic of installation
////////////////////////////////////////////////////////////////////////

You can install each module simply by extracting all the contents of
the downloaded ZIP file into any directory on you hard disk drive
(maintaining the ZIP subdirectory structure). We recommend
to extract all the LISp-Miner subsystems into the same directory.

4) Setting-up database
////////////////////////////////////////////////////////////////////////

You have to setup-up any particular database before you can analyze 
data. You need the database with analyzed data and a so called
LM Metabase. This metabase can be created from the LMEmpty.mdb file and
givenn it a new name (e.g. LMMyMetabase.mdb). This pair of files needs
to be linked together using LM Admin module. Please start LM Admin
module and select "Create new data source". Fill-in the path and file
name of database and a ODBC data source name which should be associated
with. The same for the metabase. 

Press OK when you have filled all the fields. Now you can start the 
LM DataSource and start data mining analysis by data exploration and
preparation phase. For more details please see the home page.

For details see http://lispminer.vse.cz/how/index.html.

5) List of files
////////////////////////////////////////////////////////////////////////

Common applications:
--------------------

  LMAdmin.exe
	User administration module. Creating a new data source.

  LMDataSource.exe
	Data understanding and data preparation phase for all subsystems.

4ft-Miner subsystem:
--------------------
 
  4ftTask.exe
	Task definition and hypotheses generation phase.

  4ftResult.exe
	Interpretation phase.

  4ftGridGen.exe
	Generation of hypotheses on a single core (for parallel processing).

KL-Miner subsystem:
--------------------
 
  KLTask.exe
	Task definition and hypotheses generation phase.

  KLResult.exe
	Interpretation phase.

  KLGridGen.exe
	Generation of hypotheses on a single core (for parallel processing).

CF-Miner subsystem:
--------------------
 
  CFTask.exe
	Task definition and hypotheses generation phase.

  CFResult.exe
	Interpretation phase.

  CFGridGen.exe
	Generation of hypotheses on a single core (for parallel processing).
	
SDCF-Miner subsystem:
---------------------
 
  SDCFTask.exe
	Task definition and hypotheses generation phase.

  SDCFResult.exe
	Interpretation phase.

  SDCFGridGen.exe
	Generation of hypotheses on a single core (for parallel processing).

SDKL-Miner subsystem:
---------------------
 
  SDKLTask.exe
	Task definition and hypotheses generation phase.

  SDKLResult.exe
	Interpretation phase.

  SDKLGridGen.exe
	Generation of hypotheses on a single core (for parallel processing).

SD4ft-Miner subsystem:
----------------------
 
  SD4ftTask.exe
	Task definition and hypotheses generation phase.

  SD4ftResult.exe
	Interpretation phase.

  SD4ftGridGen.exe
	Generation of hypotheses on a single core (for parallel processing).

Action4ft-Miner subsystem:
--------------------------
 
  Ac4ftTask.exe
	Task definition and hypotheses generation phase.

  Ac4ftResult.exe
	Interpretation phase.

  Ac4ftGridGen.exe
	Generation of hypotheses on a single core (for parallel processing).

ETree-Miner subsystem:
----------------------
 
  ETTask.exe
	Task definition and hypotheses generation phase.

  ETResult.exe
	Interpretation phase.

  ETGridGen.exe
	Generation of hypotheses on a single core (for parallel processing).

MCluster-Miner subsystem:
-------------------------
 
  MCTask.exe
	Task definition and hypotheses generation phase.

  MCResult.exe
	Interpretation phase.

  MCGridGen.exe
	Generation of hypotheses on a single core (for parallel processing).


Knowledge-EXplorer subsystem:
-----------------------------

  KEXTask.exe
	Task definition and knowledge base generation phase.

  KEXResult.exe
	Interpretation (consultation) phase.

LM TaskPooler:
------------------

	Manages batch solving of tasks in the background.

	Input parameters:
		/DSN:<data-source-name>		... data source name of metabase (if the data source name contains spaces, the whole /DSN parameter has to be enclosed in quotations mark, e.g. "/DSN:LM Barbora MB")
		/TaskID:<TaskID>		... TaskID of the selected task
		/TaskName:<TaskName>		... Task.Name of the selected task
		/RMCaseID:<RMCaseID>		... ReverseMiner CaseID to run all tasks in this case
		/BitStringCache:<file_name>	... (O) to read bitstrings from the file and not to connect to the analyzed data database at all
		/TaskCancel			... (O) to cancel task of given TaskID or name (if already running) or to remove it from queue
		/CancelAll			... (O) to cancel any running task and to empty the queue
		/TimeOut:<sec>			... (O) time-out in seconds (approx.) after a task generation (excluding initialisation) is automatically interrupted
		/ShutdownDelaySec:<n>		... (O) number of seconds <0;86400> before the LM TaskPooler server is shutted down after currently the last waiting task is solved (default: 10)
		/TimeMaxHours:<n>		... (O) maximal number of hours the server is running (to allow for periodical re-start) (default: 1)
		/Server				... (O) this instance becomes the server (the Task parameter is ignored)
		/Quiet				... (O) for run in the background -- no information dialog boxes shown and no user's interaction is expected (errors reported to the _AppLog.dat only)
		/NoProgress			... (O) for run in the background -- no progress dialog is displayed
		/AppLog:<log_file>		... (O) alternative path and file name for logging
		/TimeLog:<log_file>		... (O) path and file name for time profiling

	To add a new task to the batch processing queue just
	specify either the TaskID or task name. 
	The TaskID has preference if both are specified.

	To cancel a task both /TaskCancel parameter and a task identification must be present

	The /CancelAll parameter doesn't require any task identification and has precedence over /TaskCancel

	The first LM TaskPooler to start becomes the server and while running it
	handles every other later launched LM TaskPoolers requests to add a task to
	the queue. Nor LM ProcPooler neither LM GridPooler could run simultaneously.

	If the "Server" parameter is specified, the TaskID/TaskName parameters are
	ignored and this instance of the LM TaskPooler explicitly becomes
	the server (no other LM TaskPooler must be already running).

LM ProcPooler:
------------------

	Manages batch solving of tasks in the background with parallel jobs on multiple processor cores.

	Input parameters:
		/DSN:<data-source-name>		... data source name of metabase (if the data source name contains spaces, the whole /DSN parameter has to be enclosed in quotations mark, e.g. "/DSN:LM Barbora MB")
		/TaskID:<TaskID>		... TaskID of the selected task
		/TaskName:<TaskName>		... Task.Name of the selected task
		/TaskGroupID:<TaskGroupID>	... TaskGroupID to run all the not solved tasks (from any GUHA procedure) within this group
		/RMCaseID:<RMCaseID>		... ReverseMiner CaseID to run all tasks in this case
		/BitStringCache:<file_name>	... (O) to read bitstrings from the file and not to connect to the analyzed data database at all
		/TaskCancel			... (O) to cancel task of given TaskID or name (if already running) or to remove it from queue
		/CancelAll			... (O) to cancel any running task and to empty the queue
		/ParallelProcessCountMax:n	... (O) maximal number of concurent parallel processes (default: 4). Could also be specified via the LM Admin misc setting
		/TimeOut:<sec>			... (O) time-out in seconds (approx.) after a task generation (excluding initialisation) is automatically interrupted
		/ShutdownDelaySec:<n>		... (O) number of seconds <0;86400> before the LM ProcPooler server is shutted down after currently the last waiting task is solved (default: 10)
		/TimeMaxHours:<n>		... (O) maximal number of hours the server is running (to allow for periodical re-start) (default: 1)
		/Server				... (O) this instance becomes the server (the Task parameter is ignored)
		/Quiet				... (O) for run in the background -- no information dialog boxes shown and no user's interaction is expected (errors reported to the _AppLog.dat only)
		/NoProgress			... (O) for run in the background -- no progress dialog is displayed
		/AppLog:<log_file>		... (O) alternative path and file name for logging
		/TimeLog:<log_file>		... (O) path and file name for time profiling

	To add a new task to the batch processing queue just
	specify either the TaskID or task name. 
	The TaskID has preference if both are specified.

	To cancel a task both /TaskCancel parameter and a task identification must be present

	The /CancelAll parameter doesn't require any task identification and has precedence over /TaskCancel

	The first LM ProcPooler to start becomes the server and while running it
	handles every other later launched LM ProcPoolers requests to add a task to
	the queue. Nor LM TaskPooler neither LM GridPooler could run simultaneously.

	If the "Server" parameter is specified, the TaskID/TaskName parameters are
	ignored and this instance of the LM ProcPooler explicitly becomes
	the server (no other LM ProcPooler must be already running).

LM GridPooler:
------------------

	Manages batch solving of tasks on the PC-Grid. The grid-connection must be properly setup.

	Input parameters:
		/DSN:<data-source-name>		... data source name of metabase (if the data source name contains spaces, the whole /DSN parameter has to be enclosed in quotations mark, e.g. "/DSN:LM Barbora MB")
		/TaskID:<TaskID>		... TaskID of the selected task
		/TaskName:<TaskName>		... Task.Name of the selected task
		/RMCaseID:<RMCaseID>		... ReverseMiner CaseID to run all tasks in this case
		/TaskCancel			... (O) to cancel task of given TaskID or name (if already running) or to remove it from queue
		/CancelAll			... (O) to cancel any running task and to empty the queue
		/GridBinariesPath:<Path>	... (O) an optional path to the PCGrid/Binaries directory (if not in a default location as subdirectory)
		/GridDataPath:<Path>		... (O) an optional path to the PCGrid/Binaries directory (if not in a default location as subdirectory)
		/TimeOut:<sec>			... (O) time-out in seconds (approx.) after a task generation (excluding initialisation) is automatically interrupted
		/ShutdownDelaySec:<n>		... (O) number of seconds <0;86400> before the LM TaskPooler server is shutted down after currently the last waiting task is solved (default: 10)
		/TimeMaxHours:<n>		... (O) maximal number of hours the server is running (to allow for periodical re-start) (default: 1)
		/Server				... (O) this instance becomes the server (the Task parameter is ignored)
		/Quiet				... (O) for run in the background -- no information dialog boxes shown and no user's interaction is expected (errors reported to the _AppLog.dat only)
		/NoProgress			... (O) for run in the background -- no progress dialog is displayed
		/AppLog:<log_file>		... (O) alternative path and file name for logging
		/TimeLog:<log_file>		... (O) path and file name for time profiling

	To add a new task to the batch processing queue just
	specify either the TaskID or task name. 
	The TaskID has preference if both are specified.

	To cancel a task both /TaskCancel parameter and a task identification must be present

	The /CancelAll parameter doesn't require any task identification and has precedence over /TaskCancel

	The first LM GridPooler to start becomes the server and while running it
	handles every other later launched LM GridPoolers requests to add a task to
	the queue. Nor LM TaskPooler neither LM ProcPooler could run simultaneously.

	If the "Server" parameter is specified, the TaskID/TaskName parameters are
	ignored and this instance of the LM GridPooler explicitly becomes
	the server (no other LM GridPooler must be already running).

SEWEBAR Exporter:
------------------

	Exports the metabase data (task, results...) into a text file (PMML, XML, HTML) 
	using template.

	Input parameters:
		/DSN:<data-source-name>		... data source name of metabase (if the data source name contains spaces, the whole /DSN parameter has to be enclosed in quotations mark, e.g. "/DSN:LM Barbora MB")
		/MatrixID:<MatrixID>		... MatrixID of the selected matrix
		/MatrixName:<MatrixName>	... Matrix.Name of the selected matrix
		/TaskID:<TaskID>		... TaskID of the selected task
		/TaskName:<TaskName>		... Task.Name of the selected task
		/BitStringCache:<file_name>	... (O) to read bitstrings from the file and not to connect to the analyzed data database at all
		/Survey				... special mode to export survey of tasks
		/Version			... special mode to export system version
		/Template:<template_file>	... path and name to the template file
		/Output:<output_file>		... path and name to the output file
		/Alias:<alias_file>		... (O) aliases for text strings (for PMML mainly)
		/NoAttributeDisctinctValues	... (O) to skip reading distinct values of attributes from metabase (if not needed afterwards for export)
		/DistinctValuesMax:<nnn>	... (O) maximal number of exported distinct values of DB columns (default: 1000)
		/NoConnectDB			... (O) do not try to connect to the analyzed data database (faster, if no connection needed)
		/NoEscapeSeq			... (O) to suppress substitution of XML special characters for escape-sequences (like: &gt, &amp etc.) (default: FALSE)
		/NoEscapeSeqUnicode		... (O) to suppress substitution of national characters for UNICODE escape-sequences (like: &Aacute, &Rcaron etc.) (default: FALSE)
		/Quiet				... (O) for run in the background -- no information dialog boxes shown and no user's interaction is expected (errors reported to the _AppLog.dat only)
		/NoProgress			... (O) for run in the background -- no progress dialog is displayed
		/AppLog:<log_file>		... (O) alternative path and file name for logging
		/TimeLog:<log_file>		... (O) path and file name for time profiling

	Either the TaskID or task name have to be specifed for export the whole task. 
	The TaskID has preference if both are specified.

	Either the MatrixID or matrix name have to be specified for export of the
	DataDictionary. The MatrixID has preference if both are specified.

	Full task export has preference over DataDictionary export if both
	task and matrix are specified.

	A special parameter /Survey could be specified to export just survey of tasks and their states. 
	The DSN parameter must be specified, but no TaskID nor MatrixID needs to be.

	A special parameter /Version could be specified to export just system variables (version, data-time...). 
	The DSN, TaskID and MatrixID parameters need not be specified.

SEWEBAR Importer:
------------------

	Imports PMML file into the metabase (transformation dictionary, tasks) 

	Input parameters:
		/DSN:<data-source-name>		... data source name of metabase (if the data source name contains spaces, the whole /DSN parameter has to be enclosed in quotations mark, e.g. "/DSN:LM Barbora MB")
		/Input:<pmml_file>		... input PMML file with definitions
		/Alias:<alias_file>		... (O) aliases for text strings (the same as for export, reverse mapping)
		/NoCheckPrimaryKeyUnique	... (O) skip test of unique values in the database table primary key
		/Quiet				... (O) for run in the background -- no information dialog boxes shown and no user's interaction is expected (errors reported to the _AppLog.dat only)
		/NoProgress			... (O) for run in the background -- no progress dialog is displayed
		/AppLog:<log_file>		... (O) alternative path and file name for logging
		/TimeLog:<log_file>		... (O) path and file name for time profiling

Empty metabase:
---------------

  LMEmpty.mdb
	Empty metabase used as a template for user-created metabases

  LMEmptyUS.mdb
	Empty metabase used as a template for user-created metabases (for the U.S. regional settings)

Help:
-----

  Help/
	Directory with help files for all modules

/////////////////////////////////////////////////////////////////////////////
Other notes:

(O) means an optional parameter

/////////////////////////////////////////////////////////////////////////////
