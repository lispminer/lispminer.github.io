-- LMGlobal.lua

-- =============================================================================
-- namespace lm;

-- =============================================================================
-- namespace lm.data

	lm.data.IDColumnNameDefault = "ID_LM";			-- default name for ID column created in the importTXT function

-- =============================================================================
-- namespace lm.metabase

-- =============================================================================
-- namespace lm.prepro

	lm.prepro.RootAttributeGroupName = "Root attribute group"	-- name of the top group of attributes

-- =============================================================================
-- namespace lm.tasks

	lm.tasks.TaskGroupNameDefault = "Default Task Group"	-- name of the default group of tasks

	-- ==========================================================================
	-- namespace lm.tasks.settings

		lm.tasks.settings.FTPartialCedentNameDefault = "Default Partial Cedent"	-- name of the default partial cedent
	
	-- ==========================================================================
	-- namespace lm.tasks.interpretation

		lm.tasks.results.HypothesisGroupNameFinal = "Final results"	-- name of the group of hypotheses with final results
	
-- =============================================================================
-- namespace lm.codes

	require( "LMCodesDef");					-- Constants definitions to code-tables

	function lm.codes.getKeyFromValue( t, val)	-- To get text for a lm.code value
	   for k,v in pairs(t) do
	   	if v == val then return k; end;
	   end;
	   return "? - unknown value";
	end

-- =============================================================================
-- Additional codes

-- Log verbosity level
lm.codes.LogVerbosityLevel= {

		Error		    = 0,
		Warning	    = 1,
		Info		    = 2,
		Normal	 	 = 3,
		Fine			 = 4,
		Finer			 = 5,
		Finest		 = 6,
		
		Top			 = 0,
		Default		 = 4,
		All			 = 6,
};

-- TargetPlatform for task.run and metabase.runAll
lm.codes.TargetPlatform= {

		TaskPooler= 2,
		ProcPooler= 3,
		GridPooler= 4,
};

-- Task Generation status
lm.codes.TaskGenerationStatus= {

		None				= 0,			-- Not 
		Request			= 6,			-- LMExec have sent a request to solve this task by xxxxPooler
		Waiting 			= 1,			-- Task is waiting in a queue to be solved
		Running			= 2,			-- Task is beeing solved
		Solved			= 3,			-- Task has been succesfully solved
		Interrupted		= 4,			-- Task solutions has been interrupted (e.g. "too many hypotheses" or deliberately by a user -- see task status message for information)
		Failed 			= 5,			-- Task could not be solved (e.g. due to some semantic error in task description -- see task status message for information)
};

-- Hypothesis to MutualInfluence relationship
lm.codes.HypothesisMutualInfluenceRelationship= {

		Unknown			= 1,
		Unrelated		= 2,
		DerivedFrom		= 3,
		Extending		= 4,
		InConflictWith	= 5,
};

-- =============================================================================
-- Deprecated codes

lm.codes.AFQuantifierType.FoundedImplication= 4;                -- Founded Implication (-)
lm.codes.AFQuantifierType.DoubleFoundedImplication= 9;          -- Double Founded Implication (-)
lm.codes.AFQuantifierType.FoundedEquivalence= 12;               -- Founded Equivalence (-)

lm.codes.DFQuantifierType.FoundedImplication= 4;                -- Founded Implication (a/(a+b) >= p ... at least 100*p [%] of objects satisfying A satisfy also S)
lm.codes.DFQuantifierType.DoubleFoundedImplication= 9;          -- Double Founded Implication (a/(a+b+c) >= p ... at least 100*p [%] of objects satisfying A or S satisfy both A and S)
lm.codes.DFQuantifierType.FoundedEquivalence= 12;               -- Founded Equivalence ((a+d)/n >= p ... at least 100*p [%] objects have the same truth value for A and S)

lm.codes.FTQuantifierType.FoundedImplication= 1;                -- Founded Implication (a/(a+b) >= p ... at least 100*p [%] of objects satisfying A satisfy also S)
lm.codes.FTQuantifierType.DoubleFoundedImplication= 4;          -- Double Founded Implication (a/(a+b+c) >= p ... at least 100*p [%] of objects satisfying A or S satisfy both A and S)
lm.codes.FTQuantifierType.FoundedEquivalence= 7;                -- Founded Equivalence ((a+d)/n >= p ... at least 100*p [%] objects have the same truth value for A and S)

return lm;