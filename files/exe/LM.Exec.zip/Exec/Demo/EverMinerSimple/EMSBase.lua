-- LISp-Miner Control Language script, for details see http://lispminer.vse.cz/lmcl
-- EverMiner Simple Demo

-- EverMinerSimple namespace
ems = {};

return ems;