-- LISp-Miner Control Language demo script
-- EverMiner Simple Demo
--			* imports data from a text file
--			* makes data preprocessing by creating categorized attributes and inserting them into groups
--			* creates analytical tasks based on group of attributes
--			* runs tasks in an automatic iterations till number of found results is acceptable
--			* creates an analytical report
-- Part of the LISp-Miner system, for details see http://lispminer.vse.cz

-- Look-up packages also in the script directory and in the LM/Exec/Lib directory
package.path= package.path..";"..lm.getScriptFolder().."?.lua;"..lm.getLMRootFolder().."/Exec/Lib/?.lua;";;

-- Import predefined constants
local lm= require( "LMGlobal");

-- Import EverMinerSimple packages
require( "EMSBase");
require( "EMSMetabase");
require( "EMSExplore");
require( "EMSPrepro");
require( "EMSTasks");
require( "EMSIterations");
require( "EMSResults");

-- Log start
lm.log( "LMExec EverMiner Simple Demo");

-- =============================================================================
-- Summary of this script input parameters

inputParams= {

	-- path and file name to source text file	
	pathNameDataSrc= lm.getScriptFolder().."../../Data/HotelBooking.txt",			

	-- path and file name of the database to create
	pathNameDataDest= lm.getScriptFolder().."../../Data/EverMinerSimple.DB.mdb",

	-- path and file name of the metabase to create
	pathNameMetabase= lm.getScriptFolder().."../../Data/EverMinerSimple.LM.mdb", 

	-- database table name to be created
	tableName= "Hotel",												

	-- base ODBC DataSourceName for both metabase and data
	dsnBase= "Exec EverMinerSimple",

	domainAttributeGroups= { "Guest", "Visit", "Calendar", "Weather"},	-- domain knowledge in form of groups of attributes

--	domainAttributeGroups2= {										-- domain knowledge in form of groups of attributes
--		Guest = { "Nationality", "Age", "Persons"},
--		Visit = { "VisitFrom", "Nights", "Price", "VisitType" },
--		Weather = { "Weather" }
--	},
		
	domainAttributeToGroup = {										-- attribute -> attributeGroup assignment
		Nationality = "Guest",
		Age = "Guest",
		Persons = "Visit",
		Room = "Visit",
		Price = "Visit",
		VisitType = "Visit",
		VisitFrom = "Calendar",
		Nights = "Calendar",
		Weather = "Weather"
	},

	-- target platform for task processing
--	nTargetPlatform= lm.codes.TargetPlatform.SamePooler,	
	nTargetPlatform= lm.codes.TargetPlatform.ProcPooler,
			
	-- acceptable minimal and maximal number of hypotheses for each tesk
	nHypothesisCountMin= 2,
	nHypothesisCountMax= 5,
	
	-- analytical report to be created
	pathNameReportOutput= lm.getScriptFolder().."../../Export/EverMinerSimple.html"
	
};

-- =============================================================================
-- Debug

lm.setLogVerbosityLevel( lm.codes.LogVerbosityLevel.Fine);
lm.setLogFunctionParameterValuesFlag( true);

---[[
--	ems.explore.initTables( inputParams);

--	ems.prepro.createPreprocessing( inputParams);

--	ems.tasks.createTasks( inputParams);

--	ems.iterations.runAll( inputParams);

--	ems.results.exportReport( inputParams);

--	ems.results.openReport( inputParams);

--]]

-- Close the metabase
-- lm.metabase:close();

-- Log finish
-- lm.logInfo( "LMExec Script End");
