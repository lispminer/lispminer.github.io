-- LISp-Miner Control Language script, for details see http://lispminer.vse.cz/lmcl
-- EverMiner Simple Demo

-- EverMinerSimple Results namespace
ems.results = {};

	-- Local functions
	
	function ems.results.getAttributeGroupStr( inputParams)
	
		str= table.concat( inputParams.domainAttributeGroups, ", ");
		return str;
		
	end;
	
	function ems.results.getAttributeList( attributeGroup)
	
		attributeArray= attributeGroup.prepareAttributeArray({
			pDataTable= dataTable
		});
	
		str= "";
		for i, attribute in ipairs( attributeArray) do

			if ( i > 1) then str= str..", "; end;
			str= str.."<code>";
			str= str..attribute.Name;
			str= str.."</code>";
			
		end;

		return str;		
	end;

	function ems.results.getCategoryList( attribute)
	
		categoryArray= attribute.prepareCategoryArray();
	
		str= "";
		for i, category in ipairs( categoryArray) do

			if ( i > 15) then
			-- Too many categories, report just the first few
				str= str.."...";
				break;
			end;
			
			if ( i > 1) then str= str..", "; end;
			str= str.."<code>";
			str= str..category.NameHTML;
			str= str.."</code>";
			
		end;

		return str;		
	end;
	
function ems.results.exportReport( inputParams)
-- Export an analytical report with results

	bOpened= false;
	if ( not lm.metabase.isOpen()) then
	
		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.iterations.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});
	
		lm.metabase.open({
			dataSourceName= ems.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

	lm.setLogVerbosityLevel( lm.codes.LogVerbosityLevel.Normal);
	lm.setLogFunctionParameterValuesFlag( false);

	lm.log( "Creating analytical report");
	lm.logIndentUp();

	outputFile= io.open( inputParams.pathNameReportOutput, "w");
	
	outputFile:write( "<!DOCTYPE html>\n");
	outputFile:write( "<html lang=\"en\">\n");
	outputFile:write( "<head><link rel=\"stylesheet\" href=\"ems.css\" type=\"text/css\" /></head>\n");

	outputFile:write( "<body>\n");
	
	dataTable= lm.explore.findDataTable({
		name= inputParams.tableName
	});
	assert( dataTable, "Database table not found!");

	outputFile:write( "<center><font size=\"+3\">EverMinerSimple Demo Analytical Report</font></center>\n");
--	outputFile:write( "&nbsp;<p>&nbsp;\n");

-- Input parameters

	outputFile:write( "<h1>Input parameters</h1>\n");

		outputFile:write( "<p>Source data file: <code>"..inputParams.pathNameDataSrc.."</code><br>\n");
		outputFile:write( "<p>Domain knowledge (attribute groups): <code>"..ems.results.getAttributeGroupStr( inputParams).."</code><br>\n");
		outputFile:write( "<p>Target computational platform: <code>"..lm.codes.getKeyFromValue( lm.codes.TargetPlatform, inputParams.nTargetPlatform).."</code><br>\n");
		outputFile:write( "<p>Preferred number of patterns to be found: <code>"..inputParams.nHypothesisCountMin..".."..inputParams.nHypothesisCountMax.."</code><br>\n");
		outputFile:write( "<p>Report file destination: <code>"..inputParams.pathNameReportOutput.."</code><br>\n");

-- Database Tables

	outputFile:write( "<h1>Data Exploration</h1>\n");

	line= string.format( "<h2>%s</h2>\n", 
						dataTable.Name
	); 
	outputFile:write( line);

--	outputFile:write( "<h2>Original columns</h2>\n");
	outputFile:write( "<p>\n");
	outputFile:write( "Original columns:<br><ul>\n");

	dataColumnArray= dataTable.prepareDataColumnArray();

	for i, dataColumn in ipairs( dataColumnArray) do

			if ( (dataColumn.getDataColumnSubTypeCode() == lm.codes.DataColumnSubType.Ordinary) and
				  (not dataColumn.isPrimaryKeyPart())) then
			
				line= string.format( "<li>%s: %s</li>\n", 
									dataColumn.Name,
									dataColumn.getValueSubTypeName()
									
				); 
				outputFile:write( line);
				
			end;
	end;
	
	outputFile:write( "</ul>\n");

--	outputFile:write( "<h2>Original columns</h2>\n");
	outputFile:write( "&nbsp;<br><p>\n");
	outputFile:write( "Derived columns:<br><ul>\n");

	dataColumnArray= dataTable.prepareDataColumnArray();

	for i, dataColumn in ipairs( dataColumnArray) do

			if ( dataColumn.getDataColumnSubTypeCode() ~= lm.codes.DataColumnSubType.Ordinary) then
			
				line= string.format( "<li>%s: %s</li>\n", 
									dataColumn.Name,
									dataColumn.getValueSubTypeName()
									
				); 
				outputFile:write( line);
				
			end;
	end;
	
	outputFile:write( "</ul>\n");

-- Attribute groups

	outputFile:write( "<h1>Data Preprocessing</h1>\n");

	rootAttributeGroup= lm.prepro.getRootAttributeGroup();
	
	attributeGroupArray= rootAttributeGroup.prepareSubAttributeGroupArray();

	for i, attributeGroup in ipairs( attributeGroupArray) do

--			attributeList= ems.results.getAttributeList( attributeGroup);
			
			line= string.format( "<h2>%s</h2>\n", 
								attributeGroup.Name
			); 
			outputFile:write( line);
	
			-- list of attributes
			
			attributeArray= attributeGroup.prepareAttributeArray({
				pDataTable= dataTable
			});
		
			str= "";
			for i, attribute in ipairs( attributeArray) do

				categoryList= ems.results.getCategoryList( attribute);
				
				line= string.format( "<p>%s: %s<br>\n", 
									attribute.Name,
									categoryList
				); 
				outputFile:write( line);
				
			end;
				
	end;
	
-- Tasks
		
	outputFile:write( "<h1>Tasks</h1>\n");
	
	taskArray= lm.tasks.prepareTaskArray({
		pDataTable= dataTable
	});

	outputFile:write( "Total number of tasks created and solved: "..#taskArray.."\n<p>");
	
	for i, task in ipairs( taskArray) do

		finalHypothesisGroup= task.findHypothesisGroup({
			name= lm.tasks.results.HypothesisGroupNameFinal
		});

		if ( finalHypothesisGroup) then
		-- final task
			
			line= string.format( "<h2>%s</h2>\n", 
									task.Name
			); 
			outputFile:write( line);

			nHypoTotalCount= task.getHypothesisCount();
			if ( (nHypoTotalCount >= inputParams.nHypothesisCountMin) and
			 	  (nHypoTotalCount <= inputParams.nHypothesisCountMax)) then

				outputFile:write( "<p>Task has finished succesfully and an acceptable number of patterns has been found<br>\n");

			else

				outputFile:write( "<p>Task finished but an acceptable number of patterns has not been achieved<br>\n");

				if ( task.Note ~= "-") then
					outputFile:write( "<p>"..task.Note.."<br>\n");
				end;
			
			end;
					
			iterationStart, iterationEnd= string.find( task.Name, "%(%d*%)");
			if ( iterationStart) then

				iterationCountStr= string.sub( task.Name, iterationStart+ 1, iterationEnd- 1);
				iterationCount= tonumber( iterationCountStr);

				outputFile:write( "<p>Number of iterations: "..(iterationCount).."<br>\n");
			end;

			nHypoCount= finalHypothesisGroup.getHypothesisCount();					
			if ( nHypoCount > 0) then

	 	  
				line= string.format( "<p>Found patterns: %d<br>\n",
											task.getHypothesisCount()
				);
				outputFile:write( line);
				
				outputFile:write( "<p>\n");
				outputFile:write( "The most interesting ones:<br><ul>\n");

				hypothesisArray= finalHypothesisGroup.prepareHypothesisArray();
			
				for j, hypothesis in ipairs( hypothesisArray) do
	
					-- task with results title
					line= string.format( "<li>%s</li>\n", 
											hypothesis.TextHTML
					); 
					outputFile:write( line);
				
				end;
	
				outputFile:write( "</ul>\n");
				
			else
			
				outputFile:write( "<p>No interesting results found.<br>\n");
				
			end;			
		else

			-- intermediate task setting
			
		end;
		
	end;
	
	if ( bOpened) then
	
		lm.metabase.close();
	
		-- Create a backup copy for debug
--		lm.metabase.backupMDB({
--			pathNameSrc= inputParams.pathNameMetabase,
--			pathNameDest= inputParams.pathNameMetabase.."_bkup.results.mdb"
--		});
	
	end;
	
	outputFile:write( "</body>\n");
	outputFile:write( "</html>\n");
	
	io.close( outputFile);
	
	lm.logIndentDown();

end;

function ems.results.openReport( inputParams)
-- Open an application (browser) associated with .HTML files

	cmd= string.format( "start %s", 
			inputParams.pathNameReportOutput
	); 

--	lm.logInfo( cmd);
	
	os.execute( cmd);

end;

return ems.results;