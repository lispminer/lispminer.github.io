-- LISp-Miner Control Language script, for details see http://lispminer.vse.cz/lmcl
-- EverMiner Simple Demo

-- EverMinerSimple Prepro namespace
ems.prepro = {};

-- Creating groups of attributes
function ems.prepro.createAttributeGroups( inputParams)

	lm.log( "Creating groups of attributes");
	lm.logIndentUp();

	rootAttributeGroup= lm.prepro.getRootAttributeGroup();
	
	-- Iterate through all the groups of attributes
	for i, attributeGroupName in ipairs( inputParams.domainAttributeGroups) do

		attributeGroup= lm.prepro.AttributeGroup({ 
			name= attributeGroupName, 
			pParentGroup= rootAttributeGroup
		});
		
	end;

	lm.logIndentDown();

end;

-- Creating attributes
function ems.prepro.createAttributes( inputParams)

	lm.log( "Creating attributes for data tables");
	lm.logIndentUp();

	rootAttributeGroup= lm.prepro.getRootAttributeGroup();

	-- Prepare database tables array
	local dataTableArray= lm.explore.prepareDataTableArray();

	-- Iterate through all the database tables
	for i, dataTable in ipairs( dataTableArray) do

		if ( dataTable.isInitialized()) then

			lm.log( "Creating attributes for table "..dataTable.Name);
			lm.logIndentUp();
		
			-- Columns
			
			local dataColumnArray= dataTable.prepareDataColumnArray();
			
			-- Iterate through all the columns
			for j, column in ipairs( dataColumnArray) do

				attribute= nil;
			
				if ( (not column.isPrimaryKeyPart()) and
					  (column.getValueSubTypeCode() ~= lm.codes.ValueSubType.DateTime)) then
				-- not processing columns part of the primary key
				-- not processing DateTime columns (will process theirs DateTimePart derived columns instead)
				
					-- Lookup attribute group by the column name
					attributeGroup= lm.prepro.findAttributeGroup({
						name= inputParams.domainAttributeToGroup[ column.Name]
					});
						
					if ( not attributeGroup) then
						
						nPos= string.find( column.Name, ".", 1, true);
						if ( nPos) then
						-- special case of VisitFrom.<DatePart> attributes
							
							baseName= string.sub( column.Name, 1, nPos- 1);
							lm.log( baseName);
							
							attributeGroup= lm.prepro.findAttributeGroup({
								name= inputParams.domainAttributeToGroup[ baseName]
							});
							
						end;
						
						if ( not attributeGroup) then
						-- still not found
						
							lm.log( "Could not find the group for attribute "..column.Name);
							attributeGroup= rootAttributeGroup;
							
						end;
					end;
					
					attribute= lm.prepro.Attribute({
						name= column.Name,
						pAttributeGroup= attributeGroup,
						pDataColumn= column
					});

					-- Creating categories of type based on type of values in underlying column
					
					if ( attribute.getValueSubTypeCode() == lm.codes.ValueSubType.Float) then
					-- Floats => equidistant intervals
					
						attribute.autoCreateIntervalEquidistant({ 
							nCount= 10
						});
						
					elseif ( attribute.getValueSubTypeCode() == lm.codes.ValueSubType.Integer) then
					-- Integers
					
						if ( (column.getDatePartSubTypeCode() == lm.codes.DatePartSubType.NotSet) or
						 	  (column.getDatePartSubTypeCode() == lm.codes.DatePartSubType.Year) or
							  (column.getDatePartSubTypeCode() == lm.codes.DatePartSubType.DayOfRange) or
							  (column.getDatePartSubTypeCode() == lm.codes.DatePartSubType.MonthOfRange)) then
						-- ordinary integer or years
						
							nDistinctValueCount= column.getDistinctValueCount();
							
							if ( nDistinctValueCount < 20) then			
							-- Small number of distinct integers => enumeration
							
								attribute.autoCreateEnumeration({});
								
							else
							-- Large number of distinct integers => equifrequency intervals
							
								attribute.autoCreateIntervalEquifrequency({ 
									nCount= 7
								});
								
							end;
						elseif ((column.getDatePartSubTypeCode() == lm.codes.DatePartSubType.DayOfYear) or
							     (column.getDatePartSubTypeCode() == lm.codes.DatePartSubType.WeekOfYear)) then
						-- DayOfYear, WeekOfYear
						
								attribute.autoCreateIntervalEquifrequency({ 
									nCount= 7
								});
							
						else
						-- DatePart derived column (month, day, DayOfWeek...)
						
							attribute.autoCreateEnumeration({});
						
						end;
					else
					-- String, boolean

						attribute.autoCreateEnumeration({ 
							nCount= 100
						});
					
					end;

					if ( attribute.getCategoryCount() <= 1) then
					-- not valid => remove

						lm.log( "No categories for attribute "..attribute.Name.." - removing");
											
						attribute.onDel();
						attribute= nil;
						
					end;
					
				else
					-- Derived 'DatePart' columns will be created for DateTime
				end;
							
			end;

			lm.logIndentDown();
		
		end;
		
	end;

	lm.logIndentDown();

end;

-- Creating preprocessing
function ems.prepro.createPreprocessing( inputParams)

	lm.log( "Preprocessing of attributes and group of attributes");
	lm.logIndentUp();

	bOpened= false;
	if ( not lm.metabase.isOpen()) then
	
		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.explore.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});
	
		lm.metabase.open({
			dataSourceName= ems.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

	lm.metabase.clearLocalDataCache();			-- to assure a fresh new start

	ems.prepro.createAttributeGroups( inputParams);
	ems.prepro.createAttributes( inputParams);

	if ( bOpened) then
		lm.metabase.close();
	
		-- Create a backup copy for debug
		lm.metabase.backupMDB({
			pathNameSrc= inputParams.pathNameMetabase,
			pathNameDest= inputParams.pathNameMetabase.."_bkup.prepro.mdb"
		});
	end;
		
	lm.logIndentDown();
	
end;

return ems.prepro;