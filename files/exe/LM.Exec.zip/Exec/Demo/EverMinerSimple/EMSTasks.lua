-- LISp-Miner Control Language script, for details see http://lispminer.vse.cz/lmcl
-- EverMiner Simple Demo

-- EverMinerSimple Tasks namespace
ems.tasks = {};

	-- Helper functions
	
	function ems.tasks.createFTPartialCedent( cedentTypeCode, task, dataTable, attributeGroup)
	-- Creates a single FTPartialCedentSetting with all attributes from given group of attributes
	
		ftpartialCedentSetting= lm.tasks.settings.FTPartialCedentSetting({
			pTask= task,
			nCedentTypeCode= cedentTypeCode,
			name= attributeGroup and 
						attributeGroup.Name or 
						lm.tasks.settings.FTPartialCedentNameDefault
		});
		
		if ( attributeGroup) then
		
			attributeArray= attributeGroup.prepareAttributeArray({
				pDataTable= dataTable
			});
				
			for j, attribute in ipairs( attributeArray) do
			-- add literal for each attribute
			
				ftliteralSetting= lm.tasks.settings.FTLiteralSetting({
					pFTPartialCedentSetting= ftpartialCedentSetting,
					pAttribute= attribute
				});
			
			end;
		end;
			
		return ftpartialCedentSetting;
		
	end;

-- Main function

function ems.tasks.createTasks( inputParams)
-- Creating tasks for groups of attributes

	bOpened= false;
	if ( not lm.metabase.isOpen()) then
	
		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.prepro.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});
	
		lm.metabase.open({
			dataSourceName= ems.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

	lm.log( "Creating tasks for all the combinations of groups of attributes");
	lm.logIndentUp();

	dataTable= lm.explore.findDataTable({
		name= inputParams.tableName
	});
	assert( dataTable, "Database table not found!");

	rootAttributeGroup= lm.prepro.getRootAttributeGroup();
	
	attributeGroupArray= rootAttributeGroup.prepareSubAttributeGroupArray();
		
--	taskGroup= lm.tasks.findTaskGroup({
--		name= lm.tasks.DefaultTaskGroupName
--	});
	
	-- Iterate through all the attribute groups to compose succedent
	for i, succedentAttributeGroup in ipairs( attributeGroupArray) do

		lm.log( "Creating task for group of attributes "..succedentAttributeGroup.Name.." in succedent");
		lm.logIndentUp();

		-- create proper task name
		
		autoName= "";

		-- Iterate through all the attribute groups to compose antecedent
		for j, antecedentAttributeGroup in ipairs( attributeGroupArray) do

			if ( antecedentAttributeGroup ~= succedentAttributeGroup) then
			-- Not assocation on the same group 
			
				if ( string.len( autoName) > 0) then autoName= autoName..", "; end;
				autoName= autoName..antecedentAttributeGroup.Name;
				
			end;
		end;

		autoName= autoName.." -> "..succedentAttributeGroup.Name;
		
		-- Create a special group of tasks for each task to contain its clones through the iteration process
		taskGroup= lm.tasks.TaskGroup({
			name= autoName
		});
		
		task= lm.tasks.TaskFT({ 
			name= autoName.." (01)", 
			pTaskGroup= taskGroup,
			pDataTable= dataTable,
		});
		
		-- Succedent: One and only partial cedent

		succedentFTPartialCedentSetting= 
			ems.tasks.createFTPartialCedent( 
				lm.codes.CedentType.Succedent, 
				task, 
				dataTable, 
				succedentAttributeGroup
		);

		-- Succedent: MaxLen
		
		succedentFTWholeCedentSetting= task.findFTWholeCedentSetting({
				nCedentTypeCode= lm.codes.CedentType.Succedent
		});
		succedentFTWholeCedentSetting.MaxLen= 2;
			
		-- Antecedent: partial cedent for each attributeGroup

		-- Iterate through all the attribute groups to compose antecedent
		for j, antecedentAttributeGroup in ipairs( attributeGroupArray) do

			if ( antecedentAttributeGroup ~= succedentAttributeGroup) then
			-- Not assocation on the same group 
			
				-- creating partial cedent for each group of attributes
				antecedentFTPartialCedentSetting= 
					ems.tasks.createFTPartialCedent( 
						lm.codes.CedentType.Antecedent,
						task, 
						dataTable, 
						antecedentAttributeGroup
				);
		
				-- Partial cedent: MaxLen
				
				antecedentFTPartialCedentSetting.MaxLen= 2;
			end;
		
		end;

		-- Antecedent: MaxLen

		antecedentFTWholeCedentSetting= task.findFTWholeCedentSetting({
				nCedentTypeCode= lm.codes.CedentType.Antecedent
		});
		antecedentFTWholeCedentSetting.MaxLen= 3;

		-- Condition: Empty partial cedent

		conditionFTPartialCedentSetting= 
			ems.tasks.createFTPartialCedent( 
				lm.codes.CedentType.Condition, 
				task, 
				dataTable, 
				nil					-- empty AttributeGroup
		);

		-- Quantifiers
		
		baseFTQuantifier= lm.tasks.settings.FTQuantifierSetting({
			pTaskFT= task,
			nFTQuantifierTypeCode= lm.codes.FTQuantifierType.BASE,
			dThresholdValue= 30
		});

		fuiFTQuantifier= lm.tasks.settings.FTQuantifierSetting({
			pTaskFT= task,
			nFTQuantifierTypeCode= lm.codes.FTQuantifierType.PImplication,
			dThresholdValue= 0.9
		});
			
		-- Parameters
		
		task.setExtensionsPrimeCheckAllFlag();
				
		lm.logIndentDown();

	end;
	
	if ( bOpened) then
	
		lm.metabase.close();
	
		-- Create a backup copy for debug
		lm.metabase.backupMDB({
			pathNameSrc= inputParams.pathNameMetabase,
			pathNameDest= inputParams.pathNameMetabase.."_bkup.tasks.mdb"
		});
	
	end;
	
	lm.logIndentDown();

end;

return ems.tasks;