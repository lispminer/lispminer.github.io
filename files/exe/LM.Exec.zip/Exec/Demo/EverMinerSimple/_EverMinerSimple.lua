-- LISp-Miner Control Language demo script
-- EverMiner Simple Demo
--			* imports data from a text file
--			* makes data preprocessing by creating categorized attributes and inserting them into groups
--			* creates analytical tasks based on group of attributes
--			* runs tasks in an automatic iterations till number of found results is acceptable
--			* creates an analytical report
-- Part of the LISp-Miner system, for details see http://lispminer.vse.cz

-- Look-up packages also in the script directory and in the LM/Exec/Lib directory
package.path= package.path..";"..lm.getScriptFolder().."?.lua;"..lm.getLMRootFolder().."/Exec/Lib/?.lua;";;

-- Import predefined constants
local lm= require( "LMGlobal");

-- Import EverMinerSimple packages
require( "EMSBase");
require( "EMSMetabase");
require( "EMSExplore");
require( "EMSPrepro");
require( "EMSTasks");
require( "EMSIterations");
require( "EMSResults");

-- Log start
lm.log( "LMExec EverMiner Simple Demo");

-- =============================================================================
-- Summary of this script input parameters

inputParams= {

	-- path and file name to source text file	
	pathNameDataSrc= lm.getScriptFolder().."../../Data/HotelBooking.txt",			

	-- path and file name of the database to create
	pathNameDataDest= lm.getScriptFolder().."../../Data/EverMinerSimple.DB.mdb",

	-- path and file name of the metabase to create
	pathNameMetabase= lm.getScriptFolder().."../../Data/EverMinerSimple.LM.mdb", 

	-- database table name to be created
	tableName= "Hotel",												

	-- base ODBC DataSourceName for both metabase and data
	dsnBase= "Exec EverMinerSimple",

	domainAttributeGroups= { "Guest", "Visit", "Calendar", "Weather"},	-- domain knowledge in form of groups of attributes

--	domainAttributeGroups2= {										-- domain knowledge in form of groups of attributes
--		Guest = { "Nationality", "Age", "Persons"},
--		Visit = { "VisitFrom", "Nights", "Price", "VisitType" },
--		Weather = { "Weather" }
--	},
		
	domainAttributeToGroup = {										-- attribute -> attributeGroup assignment
		Nationality = "Guest",
		Age = "Guest",
		Persons = "Visit",
		Room = "Visit",
		Price = "Visit",
		VisitType = "Visit",
		VisitFrom = "Calendar",
		Nights = "Calendar",
		Weather = "Weather"
	},

	-- target platform for task processing
--	nTargetPlatform= lm.codes.TargetPlatform.SamePooler,	
	nTargetPlatform= lm.codes.TargetPlatform.ProcPooler,
			
	-- acceptable minimal and maximal number of hypotheses for each tesk
	nHypothesisCountMin= 2,
	nHypothesisCountMax= 5,
	
	-- analytical report to be created
	pathNameReportOutput= lm.getScriptFolder().."../../Export/EverMinerSimple.html"
	
};

-- =============================================================================
-- Data and metabase initialization

	lm.logInfo( "Data and metabase initialization. Press Enter to continue.");
	lm.logIndentUp();
	
	ems.metabase.createDataAndMetabase( inputParams);

	lm.logIndentDown();
-- =============================================================================

-- Open a metabase 
--	lm.metabase.open({
--		dataSourceName= ems.metabase.getMetabaseDSN( inputParams)});

-- =============================================================================
-- Data exploration

	lm.logInfo( "Data exploration. Press Enter to continue.");
	lm.logIndentUp();
	
	ems.explore.initTables( inputParams);

	lm.logIndentDown();
-- =============================================================================

-- =============================================================================
-- Data preprocessing

	lm.logInfo( "Data preprocessing. Press Enter to continue.");
	lm.logIndentUp();

	ems.prepro.createPreprocessing( inputParams);

	lm.logIndentDown();
-- =============================================================================

-- =============================================================================
-- Analytical tasks

	lm.logInfo( "Analytical tasks creation. Press Enter to continue.");
	lm.logIndentUp();

	-- create task for all combinations of groups of attributes
	ems.tasks.createTasks( inputParams);

	lm.logIndentDown();

	lm.logIndentUp();
	lm.logInfo( "Analytical tasks processing. Press Enter to continue.");

	-- run each task in iterations till number of hypotheses is in the given interval
	ems.iterations.runAll( inputParams);
	
	lm.logIndentDown();
-- =============================================================================

-- =============================================================================
-- Analytical report

--	lm.logInfo( "Analytical report. Press Enter to continue.");
	lm.logIndentUp();

	-- create task for all combinations of groups of attributes
	ems.results.exportReport( inputParams);

	ems.results.openReport( inputParams);
		
	lm.logIndentDown();
	
-- =============================================================================

-- Close the metabase
lm.metabase:close();

-- Log finish
lm.logInfo( "LMExec Script End");
