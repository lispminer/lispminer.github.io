-- LISp-Miner Control Language script, for details see http://lispminer.vse.cz/lmcl
-- EverMiner Simple Demo

-- EverMinerSimple Iterations namespace
ems.iterations = {};

-- Local functions

	local taskEnlargeInfo= {};
	local taskReduceInfo= {};
	
	local bDebugNoSearchSpaceChange= false;
	
	function ems.iterations.enlargeSearchSpace( task)
	-- Change the task description so it is able to find more hypotheses

		if ( bDebugNoSearchSpaceChange) then return false; end;
		
		if ( not taskEnlargeInfo[task]) then
			taskEnlargeInfo[task]= 0;
			taskReduceInfo[task]= 0;
		end;

		lm.log( "enlargeSearchSpace: "..task.Name.." enlarge: "..taskEnlargeInfo[task].." reduce: "..taskReduceInfo[task]);

		-- prevent a never-ending cycle
		if ( (taskEnlargeInfo[task] > 1) and (taskReduceInfo[task] > 1)) then
			lm.log( "enlargeSearchSpace -- enlarge/reduce combination error");
			return false;
		end;
		
		if ( taskEnlargeInfo[task] > 5) then
			lm.log( "enlargeSearchSpace -- too much enlarge");
			return false;
		end;

		-- Changing task parameters

		bSomeChange= false;
					
		if ( not bSomeChange) then
		-- Try to lower p

			quantifier= task.findFTQuantifierSetting({
				nFTQuantifierTypeCode= lm.codes.FTQuantifierType.PImplication
			});
			
			if ( quantifier) then
			
				if ( quantifier.ThresholdValue > 0.3) then
				
					quantifier.ThresholdValue= quantifier.ThresholdValue- 0.1;
					bSomeChange= true;
				end;
			end;
		end;
		
		if ( not bSomeChange) then
		-- Try to lower BASE

			quantifier= task.findFTQuantifierSetting({
				nFTQuantifierTypeCode= lm.codes.FTQuantifierType.BASE
			});
			
			if ( quantifier) then
			
				if ( quantifier.ParamBASECEILAbs > 20) then
				
					quantifier.ParamBASECEILAbs= quantifier.ParamBASECEILAbs- 5;

					quantifierFUI= task.findFTQuantifierSetting({
						nFTQuantifierTypeCode= lm.codes.FTQuantifierType.PImplication
					});
					quantifierFUI.ThresholdValue= 0.9;

					taskEnlargeInfo[task]= 0;
					
					bSomeChange= true;
				end;
			end;
		end;

		if ( not bSomeChange) then 
			lm.log( "enlargeSearchSpace -- no change");
			return false; 
		end;
		
		taskEnlargeInfo[task]= taskEnlargeInfo[task]+ 1;
			
		return true;	
	end;

	function ems.iterations.reduceSearchSpace( task)
	-- Change the task description so it founds less hypotheses

		if ( bDebugNoSearchSpaceChange) then return false; end;

		if ( not taskEnlargeInfo[task]) then
			taskEnlargeInfo[task]= 0;
			taskReduceInfo[task]= 0;
		end;

		lm.log( "reduceSearchSpace: "..task.Name.." enlarge: "..taskEnlargeInfo[task].." reduce: "..taskReduceInfo[task]);

		-- prevent a never-ending cycle
		if ( (taskEnlargeInfo[task] > 1) and (taskReduceInfo[task] > 1)) then
			lm.log( "reduceSearchSpace -- enlarge/reduce combination error");
			return false;
		end;
		
		if ( taskReduceInfo[task] > 5) then
			lm.log( "reduceSearchSpace -- too much reduce");
			return false;
		end;

		-- Changing task parameters

		bSomeChange= false;
					
		if ( not bSomeChange) then
		-- Try to elevate p

			quantifier= task.findFTQuantifierSetting({
				nFTQuantifierTypeCode= lm.codes.FTQuantifierType.PImplication
			});
			
			if ( quantifier) then
			
				if ( quantifier.ThresholdValue < 1.0) then
				
					quantifier.ThresholdValue= quantifier.ThresholdValue+ 0.01;
					bSomeChange= true;
				end;
			end;
		end;
		
		if ( not bSomeChange) then 
			lm.log( "reduceSearchSpace -- no change");
			return false;
		end;
		
		taskReduceInfo[task]= taskReduceInfo[task]+ 1;

		return true;
	end;

-- Main functions

function ems.iterations.runAll( inputParams)
-- run each task in iterations till number of hypotheses is in the given interval

	lm.setLogVerbosityLevel( lm.codes.LogVerbosityLevel.Fine);
	lm.setLogFunctionParameterValuesFlag( false);

	lm.log( "Solving all tasks to get an acceptable number of patterns");
	lm.logIndentUp();

	lm.tasks.setPoolerShutdownDelay( 3);	-- 10);
	-- force xxPooler application to stay open for a while even if its queue is empty
	-- because another task will be inserted in a short time
	
	bOpened= false;
	if ( not lm.metabase.isOpen()) then
	
		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.tasks.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});
	
		lm.metabase.open({
			dataSourceName= ems.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

--	lm.logInfo( "Start Pooler. Press Enter to continue.");

	-- get database table
	dataTable= lm.explore.findDataTable({
		name= inputParams.tableName
	});
	assert( dataTable, "Database table not found!");
	
	-- prepare tasks queue
	taskQueueArray= lm.tasks.prepareTaskArray({
		pDataTable= dataTable
	});
	
	-- sort tasks by ID (just for cosmetic reason to process tasks in the order they were created)
	table.sort( taskQueueArray, function ( task1, task2) return task1.ID < task2.ID; end);
		
	nTaskFinishedCount= 0;
	
	while ( #taskQueueArray > 0) do

		-- pop the topmost task from the queue (task is removed from the queue)
		task= table.remove( taskQueueArray, 1);
		assert( task);

--		lm.logInfo( task.Name..": "..task.getTaskGenerationStatusStr());
	
		if (task.isTaskGenerationStatusInProcess()) then
		-- running ( lm.TaskGenerationStatus.Request or lm.TaskGenerationStatus.Waiting or lm.TaskGenerationStatus.Running)
		-- need to query if its state has changed
		
			if ( task.queryTaskGenerationStatus() > 0) then
			-- Task was running and has just finished
		
				lm.metabase.reloadResults();			-- reload newly found results
			end;
		end;
		
--		lm.logInfo( task.Name..": "..task.getTaskGenerationStatusStr());
			
		-- select an appropriate action based on the current TaskGenerationStatus
		if ( task.TaskGenerationStatus == lm.codes.TaskGenerationStatus.None) then
		-- not running yet => need to be launched
			
			-- run asynchronously (stars task in a parallel thread and returns immediatelly)
			task.runAsync({
				nTargetPlatform= inputParams.nTargetPlatform
			});
	
			-- add the task at the end of queue
			table.insert( taskQueueArray, task);
			
		elseif (task.isTaskGenerationStatusInProcess()) then
		-- task still in the process
		-- re-insert the task at the end of queue

			table.insert( taskQueueArray, task);

		elseif ( task.TaskGenerationStatus == lm.codes.TaskGenerationStatus.Solved) then
		-- Successfully solved
		
			bFinalResults= false;
			bFinalResultsAcceptable= false;
			
			-- Check the number of found hypotheses
			nHypoCount= task.getHypothesisCount();
			
			if ( nHypoCount < inputParams.nHypothesisCountMin) then
			-- too few hypotheses
	
				lm.log( "Task '"..task.Name.."' has too few hypotheses found: "..nHypoCount);
				lm.logIndentUp();
	
				-- create clone of the actual task
				taskNew= task.clone();

				taskEnlargeInfo[taskNew]= taskEnlargeInfo[task];
				taskReduceInfo[taskNew]= taskReduceInfo[task];
										
				-- change task parameters to hopefully get more hypotheses
				if ( ems.iterations.enlargeSearchSpace( taskNew)) then
				-- task parameters successfully changed
				
					-- add the new task at the end of queue
					table.insert( taskQueueArray, taskNew);
		
					strMsg= "Search space was enlarged and the new task re-inserted into queue";
					
					task.Note= strMsg;
					lm.log( strMsg);
		
				else
				-- unable to change parameters
	
					strMsg= "Could not enlarge the search space";
					
					task.Note= strMsg;
					lm.log( strMsg);
	
					-- remove the task from metabase
					taskNew.onDel();
					taskNew= nil;

					bFinalResults= true;
					
				end;

				lm.logIndentDown();
						
			elseif ( nHypoCount > inputParams.nHypothesisCountMax) then
			-- too much hypotheses
	
				lm.log( "Task '"..task.Name.."' has too many hypotheses found: "..nHypoCount);
				lm.logIndentUp();
	
				-- create clone of the actual task
				taskNew= task.clone();

				taskEnlargeInfo[taskNew]= taskEnlargeInfo[task];
				taskReduceInfo[taskNew]= taskReduceInfo[task];
	
				-- change task parameters to hopefully get less hypotheses
				if ( ems.iterations.reduceSearchSpace( taskNew)) then
				-- task parameters successfully changed
				
					-- add the new task at the end of queue
					table.insert( taskQueueArray, taskNew);
	
					strMsg= "Search space reduced and the new task re-inserted into queue";
					
					task.Note= strMsg;
					lm.log( strMsg);
		
				else
				-- unable to change parameters
	
					strMsg= "Could not reduce the search space";
					
					task.Note= strMsg;
					lm.log( strMsg);

					-- remove the task from metabase
					taskNew.onDel();
					taskNew= nil;

					bFinalResults= true;
					
				end;

				lm.logIndentDown();

			else

				bFinalResults= true;
				bFinalResultsAcceptable= true;
			
			end;
							  
			if ( bFinalResults) then
			-- acceptable number of hypotheses or could not further change the task settings 
	
				nTaskFinishedCount= nTaskFinishedCount+ 1;
	
				if ( bFinalResultsAcceptable) then
				
					lm.log( "Task '"..task.Name.."' finished successfully with acceptable number of "..nHypoCount.." hypotheses");
					
				else

					lm.log( "Task '"..task.Name.."' finished with "..nHypoCount.." hypotheses");
				
				end;
				
				lm.logIndentUp();

				lm.log( "Looking-up the most interesting results");

				-- 'Final results' group
				hypothesisGroup= lm.tasks.results.HypothesisGroup({
					name= lm.tasks.results.HypothesisGroupNameFinal,
					pTask= task
				});

				if ( nHypoCount > 0) then
								
					hypothesisArray= task.prepareHypothesisArray();
					
					for i, hypothesis in ipairs( hypothesisArray) do
					
						if ( i > inputParams.nHypothesisCountMin) then break; end;
						
						hypothesis= hypothesisArray[i];	-- should choose the best hypothesis!
					
						hypothesisGroup.insertHypothesis({
							pHypothesis= hypothesis
						});
				
					end;
					
				end;

				-- export task results
--				task.ExportPMML( 
--					task.getPMMLTemplate() "Sewebar/Template/LMSurvey.Task.Template.txt", 		-- Template for export
--					"Exec/Export/LMExec.Demo.Task."..task.ID..".txt"			-- Destination file
	
				-- we have finished with the task so no need to re-insert it to queue

				lm.logIndentDown();
			end;

		else 
		-- finished, but in this case it means "not successfully" (lm.TaskGenerationStatus.Failed or lm.TaskGenerationStatus.Interrupted)
		-- because a "succesfully solved" was already handled above

--			lm.logInfo( task.getTaskGenerationStatusStr());
			
			assert( task.isTaskGenerationStatusFinished(), "Task '"..task.Name.."' is in an unknown state");
	
			lm.log( "Task '"..task.Name.."' not finished successfully and therefore removed from processing");

			task.Note= "Not finished successfully and therefore removed from processing";
			
			-- we have finished with the task so no need to re-insert it to queue

		end;
		
		-- leave processor cores alone for a while
		lm.sleep( 250);

	end;	-- while
			
	-- Force the still running Pooler to shutdown (it shouldn't have anything to process already)
	lm.tasks.shutdownPoolerOnIdle();
	lm.sleep( 1000);	-- give some (short) time to shutdown
	
--	lm.sleep( 1000*( lm.tasks.getPoolerShutdownDelay()+ 2));
		-- or alternative way: to wait till the xxPooler application delayed close occurs and
		-- the metabase would be unlocked
			
	if ( bOpened) then

		lm.metabase.close();
	
		-- Create a backup copy for debug
		lm.metabase.backupMDB({
			pathNameSrc= inputParams.pathNameMetabase,
			pathNameDest= inputParams.pathNameMetabase.."_bkup.iterations.mdb"
		});
	
	end;
		
	lm.logIndentDown();
		
	return nTaskFinishedCount;
	
end;	

return ems.iterations;