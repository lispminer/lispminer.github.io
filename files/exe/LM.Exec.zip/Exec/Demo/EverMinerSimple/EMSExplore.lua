-- LISp-Miner Control Language script, for details see http://lispminer.vse.cz/lmcl
-- EverMiner Simple Demo

-- EverMinerSimple Explore namespace
ems.explore = {};

-- Initialization of tables function
function ems.explore.initTables( inputParams)

	bOpened= false;
	if ( not lm.metabase.isOpen()) then

		lm.metabase.restoreMDB({
			pathNameSrc= inputParams.pathNameMetabase.."_bkup.create.mdb",
			pathNameDest= inputParams.pathNameMetabase
		});

		lm.metabase.open({
			dataSourceName= ems.metabase.getMetabaseDSN( inputParams)});
		bOpened= true;
	end;

	lm.log( "Initializing data tables");
	lm.logIndentUp();

	-- Prepare dataTableArray
	local dataTableArray= lm.explore.prepareDataTableArray();

	-- Iterate through all the dataTables
	for i, dataTable in ipairs( dataTableArray) do

		lm.log( "Initializing data table ".. dataTable.Name);
		lm.logIndentUp();

		dataTable.init();
		
		if ( not dataTable.isPrimaryKeyDefined()) then
		-- Primary key not set yet
		
			-- Use the default ID column created during the text data import
			dataTable.markPrimaryKey({ 
				columnName= lm.data.IDColumnNameDefault		
					-- name of column to become the primary key
			});			
		
		end;
		
		-- Check the primary key being set properly and stop if not
		assert( dataTable.checkPrimaryKey(), 
				  "Error checking the primary key for table "..dataTable.Name);

		-- Enable data caching to speed-up analytical task processing
		dataTable.LocalDataCacheFlag= true;
		
		lm.logIndentDown();
	
	end;
	
	if ( bOpened) then
		lm.metabase.close();
	
		-- Create a backup copy for debug
		lm.metabase.backupMDB({
			pathNameSrc= inputParams.pathNameMetabase,
			pathNameDest= inputParams.pathNameMetabase.."_bkup.explore.mdb"
		});
	
	end;
		
	lm.logIndentDown();
	
end;

return ems.explore;