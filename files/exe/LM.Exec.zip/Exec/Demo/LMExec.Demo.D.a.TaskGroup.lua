-- LMExec.Demo.Task.lua
-- Simple example of taskGroup manipulation
--			* ???
-- Part of the LISp-Miner system, for details see http://lispminer.vse.cz

-- Look-up packages also in the script directory and in the LM/Exec/Lib directory
package.path= package.path..";"..lm.getScriptFolder().."?.lua;"..lm.getLMRootFolder().."/Exec/Lib/?.lua;";;

-- Import predefined constants
local lm= require( "LMGlobal");

-- Log start
lm.log( "LMExec Script Demo TaskGroup manipulation");

-- Open a metabase 
lm.metabase:open({
	dataSourceName= "LM Exec Demo HotelBooking MB"});		-- ODBC DataSourceName

local taskGroup= lm.tasks.TaskGroup( {
			name= "Newly created task group"
});

-- Prepare taskGroups
local taskGroupArray= lm.tasks:prepareTaskGroupArray();

-- Write title line
lm.log( "\tNr.\tTaskGroupID\tTaskGroupName\t#Tasks");

-- Iterate through all the taskGroups
for i, taskGroup in ipairs( taskGroupArray) do

	local taskArray= taskGroup:prepareTaskArray();
	
	-- Compose information about a single task
	local s= string.format( "\t%d\t%d\t%s\t%d", 
							i,	taskGroup:getID(), taskGroup:getName(), 
							#taskArray);
	lm.log( s);

end;

lm.log( "\tTotal number of taskGroups: "..#taskGroupArray);

-- Close the metabase
lm.metabase:close();

-- Log finish
lm.logInfo( "LMExec Script End");
