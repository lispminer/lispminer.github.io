-- LMExec.Demo.Z.b.ScriptParam.lua
-- Passing command line parameters to LMExec
-- LMExec.exe /Input:LMExec.Demo.Z.b.ScriptParam.lua /ScriptParam:FirstParam=Alfa /ScriptParam:SecondParam=2
-- Part of the LISp-Miner system, for details see http://lispminer.vse.cz

-- Look-up packages also in the script directory and in the LM/Exec/Lib directory
package.path= package.path..";"..lm.getScriptFolder().."?.lua;"..lm.getLMRootFolder().."/Exec/Lib/?.lua;";;

-- Import predefined constants
local lm= require( "LMGlobal");

-- Log start
lm.log( "LMExec Script Demo Script Parameters");

lm.logInfo( "The first parameter value is "..lm.ScriptParam.FirstParam);	
lm.logInfo( "The second parameter value is "..lm.ScriptParam.SecondParam);

-- Log finish
lm.log( "LMExec Script End");
