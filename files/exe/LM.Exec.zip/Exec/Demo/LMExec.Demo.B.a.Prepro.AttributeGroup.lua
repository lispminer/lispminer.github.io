-- LISp-Miner Control Language demo script
-- Simple example of group of attributes manipulation
--			* creates a new group of attributes
-- Part of the LISp-Miner system, for details see http://lispminer.vse.cz

-- Look-up packages also in the script directory and in the LM/Exec/Lib directory
package.path= package.path..";"..lm.getScriptFolder().."?.lua;"..lm.getLMRootFolder().."/Exec/Lib/?.lua;";;

-- Import predefined constants
local lm= require( "LMGlobal");

-- Log start
lm.log( "LMExec Script Demo AttributeGroup manipulation");

-- Open a metabase 
lm.metabase:open({ 
	dataSourceName= "LM Exec Demo HotelBooking MB"});		-- ODBC DataSourceName

-- Get Root attributeGroup
local rootAttributeGroup= lm.prepro:getRootAttributeGroup();
assert( rootAttributeGroup);

newName= "Newly created attribute group";

attributeGroup= lm.prepro.findAttributeGroup({ name= newName});

if ( attributeGroup) then
-- does exists

	lm.log( "Group of attributes "..newName.." already exists. Try other name or do accept an automatic change -- see later");

end;

attributeGroup= lm.prepro.AttributeGroup( {
			name= newName,
			pParentGroup= rootAttributeGroup
});

local subAttributeGroupArray= rootAttributeGroup:prepareSubAttributeGroupArray();
lm.log( "Total number of attributeGroups: "..#subAttributeGroupArray);

-- Close the metabase
	lm.metabase.markChanged();			-- inform LM Workspace that the script have made some changes to metabase
	lm.metabase:close();

-- Log finish
lm.logInfo( "LMExec Script End");
