-- LISp-Miner Control Language demo script
-- Simple example of manipulation with categories
-- Part of the LISp-Miner system, for details see http://lispminer.vse.cz

-- Look-up packages also in the script directory and in the LM/Exec/Lib directory
package.path= package.path..";"..lm.getScriptFolder().."?.lua;"..lm.getLMRootFolder().."/Exec/Lib/?.lua;";;

-- Import predefined constants
local lm= require( "LMGlobal");

-- Log start
lm.log( "LMExec Script Demo Category manipulation");

-- Open a metabase 

	lm.metabase:open({ 
		dataSourceName= "LM Exec Demo HotelBooking MB"});		-- ODBC DataSourceName

-- Initialisation

	dataTableName= "Hotel";
	columnName= "Nationality";
	attributeName= "Nationality_prepro";

	-- Get Root attributeGroup
	local rootAttributeGroup= lm.prepro:getRootAttributeGroup();
	assert( rootAttributeGroup);

-- Deleting old

	attribute= lm.prepro.findAttribute({ name= attributeName});

	if ( attribute ~= nil) then
	-- already exist
	
		lm.log( "Deleting old attribute "..attributeName);
	
		attribute.onDel();
		
	end;

--	New attribute

	lm.log( "Creating new attribute "..attributeName);
	
	dataTable= lm.explore.findDataTable({ name= dataTableName});
	dataColumn= dataTable.findDataColumn({ name= columnName});
	
	attribute= lm.prepro.Attribute({ 
		name= attributeName, 
		pAttributeGroup= rootAttributeGroup,
		pDataColumn= dataColumn
	});

-- Query array of distinct values in this column and theirs frequencies

	distinctValueArray, frequenciesArray= dataColumn.prepareDistinctValueArray({});

-- List of values

	lm.log( "List of values in column: "..dataColumn.Name);

	-- Write title line
	lm.log( "\t\tNr.\tID\tValue\tFrequency");

	-- Iterate through all the categories
	for i= 1, #distinctValueArray do
	
		local s= string.format( "\t\t%d\t%s\t%d", 
								i,	
								distinctValueArray[i],
								frequenciesArray[i]
		); 
		lm.log( s);

	end;
	
	lm.log( "\t\tNumber of distinct values: "..#distinctValueArray);

	lm.logEmptyLine();
	
-- Categories manually

	lm.log( "Creating categories for "..attribute.Name);

	-- Iterate through all the categories
	for i= 1, #distinctValueArray do

		if ( distinctValueArray[i] ~= nil) then
		
			categoryName= string.format( "%s", distinctValueArray[i]);
			
			local category= lm.prepro.CategoryEnumeration({
				name= categoryName,
				pAttribute= attribute
			});
				
			category.includeValue({ value= distinctValueArray[i]});
	
			category.Name= category.getNameDefault();
				-- not necessary since is the same for the single inserted value as categoryName
				-- but could be convenient for more values or intervals
		else
		
			-- to create X-Category

			categoryName= "X-category";
			
			local category= lm.prepro.CategoryEnumeration({
				name= categoryName,
				pAttribute= attribute
			});
				
			category.IncludeNULLFlag= true;
			
		end;			
	end;
	
	-- 'Others' category

	local category= lm.prepro.CategoryEnumeration({
				name= "Others",
				pAttribute= attribute
	});
				
	category.includeValue({ value= "US"});
	category.includeValue({ value= "CA"});
	
	category.Name= category.getNameDefault();
	lm.log( "Category name: "..category.Name);
	
	-- Change
	
	category.excludeValue({ value= "CA"});

	category.Name= category.getNameDefault();
	lm.log( "Category name: "..category.Name);
				
-- Pre-calculating frequencies of categories
-- This is not necessary but could be a good practise to pre-calculate frequencies 
-- at once for all atributes before some further calculations based on them
-- and to check if successfully done

	local bOk= attribute.calcCategoryFrequencies();
	if ( not bOk) then
	
		lm.logError( "Error calculating frequencies of categories");
		
	end;
	
-- List of categories

	lm.log( "List of categories of: "..attribute.Name);

	local categoryArray= attribute.prepareCategoryArray();

	-- Write title line
	lm.log( "\t\tNr.\tID\tCategoryName\tCategorySubType\tFrequency");

	-- Iterate through all the categories
	for i, category in ipairs( categoryArray) do
	
		-- column title
		local s= string.format( "\t\t%d\t%d\t%s\t%s\t%d", 
								i,	
								category.ID,
								category.Name,
								category.getCategorySubTypeName(),
								category.Frequency
		); 
		lm.log( s);

	end;
	
	lm.log( "\t\tNumber of categories: "..#categoryArray);
	lm.log( "\t\tHas X-category: "..(attribute.hasXCategory() and "yes" or "no"));
 
-- Close the metabase
	lm.metabase.markChanged();			-- inform LM Workspace that the script have made some changes to metabase
	lm.metabase:close();

-- Log finish
lm.logInfo( "LMExec Script End");
