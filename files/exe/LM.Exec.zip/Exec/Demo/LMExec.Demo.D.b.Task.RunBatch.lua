-- LMExec.Demo.MB.lua
-- Simple example of metabase manipulation, PMML import/export and running tasks
-- Part of the LISp-Miner system, for details see http://lispminer.vse.cz

-- Look-up packages also in the script directory and in the LM/Exec/Lib directory
package.path= package.path..";"..lm.getScriptFolder().."?.lua;"..lm.getLMRootFolder().."/Exec/Lib/?.lua;";;

-- Import predefined constants
local lm= require( "LMGlobal");

-- Log start (opens a dialog window and writes a line to the AppLog file)
lm.logInfo( "LMExec Script Demo LM.Metabase manipulation");

-- Open a metabase 
lm.metabase:open({ 
	dataSourceName= "LM SwbImport MB"}						-- ODBC DataSourceName
);

-- Log success (only writes to the AppLog file)
lm:log( "Metabase " .. lm.metabase:getDSN() .. " succesfully opened");

-- Import a precessing and task description in PMML
lm.metabase:importPMML({
	pathNameSrc= "Sewebar/Export/4ftMiner.Task61.131109.pmml"		-- source file
});

-- Run all imported tasks and wait till finished
lm.tasks:runAll( 
	lm.codes.TargetPlatform.TaskPooler, -- see LMCodesDef.lua for other possible target platforms
	true											-- bNotFinishedTasksOnly (do not re-run task already solved)
);

-- Reload the whole metabase
lm.metabase:reload();
-- Beware! Since now all the LM data objects are no longer valid in the Lua script!

-- Export a survey of tasks, their states and number of found hypotheses
lm.metabase:exportPMML({
	pathNameTemplate= "Sewebar/Template/LMSurvey.Task.Template.txt", 		-- Template for export
	pathNameDest= "Exec/Export/LMExec.Demo.MB.TaskSurvey.txt"			-- Destination file
});

-- Close the metabase
lm.metabase:close();

-- Log finish
lm.logInfo( "LMExec Script End");
