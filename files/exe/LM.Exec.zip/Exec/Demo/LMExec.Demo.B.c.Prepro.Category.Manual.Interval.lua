-- LISp-Miner Control Language demo script
-- Simple example of manipulation with categories
-- Part of the LISp-Miner system, for details see http://lispminer.vse.cz

-- Look-up packages also in the script directory and in the LM/Exec/Lib directory
package.path= package.path..";"..lm.getScriptFolder().."?.lua;"..lm.getLMRootFolder().."/Exec/Lib/?.lua;";;

-- Import predefined constants
local lm= require( "LMGlobal");

-- Log start
lm.log( "LMExec Script Demo Category manipulation");

-- Open a metabase 

	lm.metabase:open({ 
		dataSourceName= "LM Exec Demo HotelBooking MB"});		-- ODBC DataSourceName

-- Initialisation

	dataTableName= "Hotel";
	columnName= "Nights";
	attributeName= "Nights_prepro";

	-- Get Root attributeGroup
	local rootAttributeGroup= lm.prepro:getRootAttributeGroup();
	assert( rootAttributeGroup);

-- Deleting old

	attribute= lm.prepro.findAttribute({ name= attributeName});

	if ( attribute ~= nil) then
	-- already exist
	
		lm.log( "Deleting old attribute "..attributeName);
	
		attribute.onDel();
		
	end;

--	New attribute

	lm.log( "Creating new attribute "..attributeName);
	
	dataTable= lm.explore.findDataTable({ name= dataTableName});
	dataColumn= dataTable.findDataColumn({ name= columnName});
	
	attribute= lm.prepro.Attribute({ 
		name= attributeName, 
		pAttributeGroup= rootAttributeGroup,
		pDataColumn= dataColumn
	});

-- Categories manually

	lm.log( "Creating categories for "..attribute.Name);

	do
	-- Low values

			categoryName= "Low";	-- just a temporary name
			
			category= lm.prepro.CategoryInterval({
				name= categoryName,
				pAttribute= attribute
			});
				
			interval= lm.prepro.Interval({
				pCategoryInterval= category,
				valueFrom= (dataColumn.getMin() > 0) and 0 or dataColumn.getMin(),
				valueTo= 7
			});

			interval.setRightBracketTypeCode( lm.codes.BracketType.Sharp);
			
			category.Name= category.getNameDefault();
	end;

	do
	-- High values

			categoryName= "High";	-- just a temporary name
			
			category= lm.prepro.CategoryInterval({
				name= categoryName,
				pAttribute= attribute
			});
				
			interval= lm.prepro.Interval({
				pCategoryInterval= category,
				valueFrom= 8,
				valueTo= dataColumn.getMax()
			});
			
			category.Name= category.getNameDefault();
			lm.log( "Category name: "..category.Name);
			
			-- if we have changed our mind
			interval.setValueTo({ bInfinity= true});

			category.Name= category.getNameDefault();
			lm.log( "Category name: "..category.Name);

	end;
	
-- Pre-calculating frequencies of categories
-- This is not necessary but could be a good practise to pre-calculate frequencies 
-- at once for all atributes before some further calculations based on them
-- and to check if successfully done

	local bOk= attribute.calcCategoryFrequencies();
	if ( not bOk) then
	
		lm.logError( "Error calculating frequencies of categories");
		
	end;
	
-- List of categories

	lm.log( "List of categories of: "..attribute.Name);

	local categoryArray= attribute.prepareCategoryArray();

	-- Write title line
	lm.log( "\t\tNr.\tID\tCategoryName\tCategorySubType\tFrequency");

	-- Iterate through all the categories
	for i, category in ipairs( categoryArray) do
	
		-- column title
		local s= string.format( "\t\t%d\t%d\t%s\t%s\t%d", 
								i,	
								category.ID,
								category.Name,
								category.getCategorySubTypeName(),
								category.Frequency
		); 
		lm.log( s);

	end;
	
	lm.log( "\t\tNumber of categories: "..#categoryArray);
	lm.log( "\t\tHas X-category: "..(attribute.hasXCategory() and "yes" or "no"));

-- Close the metabase
	lm.metabase.markChanged();			-- inform LM Workspace that the script have made some changes to metabase
	lm.metabase:close();

-- Log finish
lm.logInfo( "LMExec Script End");
