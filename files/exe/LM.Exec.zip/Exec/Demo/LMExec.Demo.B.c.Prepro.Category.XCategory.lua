-- LISp-Miner Control Language demo script
-- Simple example of manipulation with categories
-- Part of the LISp-Miner system, for details see http://lispminer.vse.cz

-- Look-up packages also in the script directory and in the LM/Exec/Lib directory
package.path= package.path..";"..lm.getScriptFolder().."?.lua;"..lm.getLMRootFolder().."/Exec/Lib/?.lua;";;

-- Import predefined constants
local lm= require( "LMGlobal");

-- Log start
lm.log( "LMExec Script Demo X-Category manipulation");

-- Open a metabase 

	lm.metabase:open({ 
		dataSourceName= "LM Exec Demo HotelBooking MB"});		-- ODBC DataSourceName

-- Initialisation

	dataTableName= "Hotel";
	columnName= "Nationality";
	attributeName= "Nationality_prepro_x";

	-- Get Root attributeGroup
	local rootAttributeGroup= lm.prepro:getRootAttributeGroup();
	assert( rootAttributeGroup);

-- Deleting old

	attribute= lm.prepro.findAttribute({ name= attributeName});

	if ( attribute ~= nil) then
	-- already exist
	
		lm.log( "Deleting old attribute "..attributeName);
	
		attribute.onDel();
		
	end;

--	New attribute

	lm.log( "Creating new attribute "..attributeName);
	
	dataTable= lm.explore.findDataTable({ name= dataTableName});
	dataColumn= dataTable.findDataColumn({ name= columnName});
	
	attribute= lm.prepro.Attribute({ 
		name= attributeName, 
		pAttributeGroup= rootAttributeGroup,
		pDataColumn= dataColumn
	});

-- Categories 

	lm.log( "Creating categories for "..attribute.Name);

	do
	-- X-Category

			categoryName= "X-Category";	-- not necessary to set

			local category= lm.prepro.CategoryEnumeration({
				name= categoryName,
				pAttribute= attribute
			});
			category.XCategoryFlag= true;

			-- including NULL values
			category.IncludeNullFlag= true;

			-- including all the ordinary values deemed as "unknown"			
			category.includeValue({ value= "?"});
			category.includeValue({ value= "-"});
			category.includeValue({ value= "N/A"});
			category.includeValue({ value= "not set"});

	end;

	attribute.autoCreateEnumeration({});
		-- if called >AFTER< a X-category was created, ignores all the values already put into X-category
		
-- Pre-calculating frequencies of categories
-- This is not necessary but could be a good practise to pre-calculate frequencies 
-- at once for all atributes before some further calculations based on them
-- and to check if successfully done

	local bOk= attribute.calcCategoryFrequencies();
	if ( not bOk) then
	
		lm.logError( "Error calculating frequencies of categories");
		
	end;
	
-- List of categories

	lm.log( "List of categories of: "..attribute.Name);

	local categoryArray= attribute.prepareCategoryArray();

	-- Write title line
	lm.log( "\t\tNr.\tID\tCategoryName\tCategorySubType\tFrequency");

	-- Iterate through all the categories
	for i, category in ipairs( categoryArray) do
	
		-- column title
		local s= string.format( "\t\t%d\t%d\t%s\t%s\t%d", 
								i,	
								category.ID,
								category.Name,
								category.getCategorySubTypeName(),
								category.Frequency
		); 
		lm.log( s);

	end;
	
	lm.log( "\t\tNumber of categories: "..#categoryArray);

	lm.log( "\t\tHas X-category: "..(attribute.hasXCategory() and "yes" or "no"));

	-- to make an ordinary category from the X-category

	xcategory= attribute.getXCategory();
	
	xcategory.XCategoryFlag= false;

	lm.log( "Number of categories: "..attribute.getCategoryCount());
	lm.log( "Has X-category: "..(attribute.hasXCategory() and "yes" or "no"));

	-- to change an ordinary category into X-category (two possible ways)
	
--	attribute.setXCategory( xcategory);
	xcategory.XCategoryFlag= true;		-- an alternative way

	lm.log( "Number of categories: "..attribute.getCategoryCount());
	lm.log( "Has X-category: "..(attribute.hasXCategory() and "yes" or "no"));

	-- to reset the X-category

	attribute.setXCategory( nil);
	
	lm.log( "Number of categories: "..attribute.getCategoryCount());
	lm.log( "Has X-category: "..(attribute.hasXCategory() and "yes" or "no"));

	-- to change an ordinary category into X-category

	category= attribute.findCategory({ name= "GE"});
	attribute.setXCategory( category);

	lm.log( "Number of categories: "..attribute.getCategoryCount());
	lm.log( "Has X-category: "..(attribute.hasXCategory() and "yes" or "no"));
	
-- Close the metabase
	lm.metabase.markChanged();			-- inform LM Workspace that the script have made some changes to metabase
	lm.metabase:close();

-- Log finish
lm.logInfo( "LMExec Script End");
