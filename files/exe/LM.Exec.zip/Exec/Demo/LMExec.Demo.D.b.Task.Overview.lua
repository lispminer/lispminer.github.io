-- LMExec.Demo.Task.lua
-- Simple example of task manipulation
--			* writes basic information about each task to log
-- Part of the LISp-Miner system, for details see http://lispminer.vse.cz

-- Look-up packages also in the script directory and in the LM/Exec/Lib directory
package.path= package.path..";"..lm.getScriptFolder().."?.lua;"..lm.getLMRootFolder().."/Exec/Lib/?.lua;";;

-- Import predefined constants
local lm= require( "LMGlobal");

-- Log start
lm.log( "LMExec Script Demo Task manipulation");

-- Open a metabase 
lm.metabase:open({
	dataSourceName= "LM Exec Demo HotelBooking MB"});		-- ODBC DataSourceName

-- Get tasks
local taskArray= lm.tasks:prepareTaskArray();

-- Write title line
lm.log( "\tNr.\tTaskID\tTaskName\tGenerationStatus\tDescription\tHypotheses");

-- Iterate through all the tasks
for i, task in ipairs( taskArray) do

	-- Compose information about a single task
	local s= string.format( "\t%d\t%d\t%s\t%d\t%s\t%d", 
							i,	task:getID(), task:getName(), 
							task:getTaskGenerationStatus(), 
							task:getTaskGenerationStatusStr(), 
							task:isTaskGenerationStatusFinished() and 
								task:getHypothesssCount() or
								"0"
									-- Lua way of 'A ? B : C' operator (if A is true then B else C)
	);
	lm.log( s);

end;

lm.log( "\tTotal number of tasks: "..#taskArray);

-- Close the metabase
lm.metabase:close();

-- Log finish
lm.logInfo( "LMExec Script End");
