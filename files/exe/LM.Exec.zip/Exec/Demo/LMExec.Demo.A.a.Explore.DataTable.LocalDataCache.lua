-- LISp-Miner Control Language demo script
-- Simple example of dataTable property manipulation
--			* tries to find a database table with ID= 1 
--			* if such table exists, the LocalDataCache is enabled for it
-- Part of the LISp-Miner system, for details see http://lispminer.vse.cz

-- Look-up packages also in the script directory and in the LM/Exec/Lib directory
package.path= package.path..";"..lm.getScriptFolder().."?.lua;"..lm.getLMRootFolder().."/Exec/Lib/?.lua;";;

-- Import predefined constants
local lm= require( "LMGlobal");

-- Log start
lm.log( "LMExec Script Demo Matrix manipulation");

-- Open a metabase 
lm.metabase:open({
		dataSourceName= "LM Exec Demo HotelBooking MB"});		-- ODBC DataSourceName

-- Try to find the first table
dataTable= lm.explore.findDataTable({ nID= 1});

if ( dataTable) then
-- dataTable has been found

	if ( not dataTable.isLocalDataCacheFlag()) then
	-- not set yet
	
		lm.log( "Enabling data caching for table "..dataTable.Name);
		
		dataTable.setLocalDataCacheFlag( true);
		
		-- Store changes into metabase
		dataTable.onUpdate();

	else
	
		lm.log( "Caching already enabled for table "..dataTable.Name);
		
	end;
		
	-- dataTable title
	local s= string.format( "\tTable: %s, LocalDataCacheFlag: %s", 
							dataTable.Name,
							dataTable.isLocalDataCacheFlag()
	); 
	lm.log( s);

else

	lm.log( "No database table found!");
	
end;

-- Close the metabase
lm.metabase:close();

-- Log finish
lm.logInfo( "LMExec Script End");
