-- LMExec.Demo.Task.lua
-- Simple example of MutualInfluence manipulation
-- Part of the LISp-Miner system, for details see http://lispminer.vse.cz

-- Look-up packages also in the script directory and in the LM/Exec/Lib directory
package.path= package.path..";"..lm.getScriptFolder().."?.lua;"..lm.getLMRootFolder().."/Exec/Lib/?.lua;";;

-- Import predefined constants
local lm= require( "LMGlobal");

	-- Helper function for creating a attribute if already not exists
	function checkAttribute( attributeName, attributeGroup, dataTableName, columnName)
	
--		lm.log( "Checking attribute");
		lm.logIndentUp();

		attribute= lm.prepro.findAttribute({ name= attributeName});
		if ( attribute == nil) then
		-- create attribute
		
			lm.log( "Creating row attribute "..attributeName);
	
			dataTable= lm.explore.findDataTable({ name= dataTableName});
			dataColumn= dataTable.findDataColumn({ name= columnName});
			
			attribute= lm.prepro.Attribute({ 
				name= attributeName, 
				pAttributeGroup= attributeGroup,
				pDataColumn= dataColumn
			});

		-- Categories as equifrequency interval

			attribute.autoCreateIntervalEquifrequency({
				nCount= 7,
				bMnemonicNames= true,
			});
			
		end;
	
			
		lm.logIndentDown();
		
		return attribute;
		
	end;

-- Log start
lm.log( "LMExec Script Demo TaskGroup manipulation");

-- Open a metabase 
lm.metabase:open({
	dataSourceName= "LM Exec Demo HotelBooking MB"});		-- ODBC DataSourceName

-- Initialisation

	dataTableName= "Hotel";
	columnRowName= "Nights";
	attributeRowName= "Nights_mi";
	columnColName= "Price";
	attributeColName= "Price_mi";

	-- Get Root attributeGroup
	local rootAttributeGroup= lm.prepro.getRootAttributeGroup();
	assert( rootAttributeGroup);

-- Preparing attributes

	attributeRow= checkAttribute( attributeRowName, rootAttributeGroup, dataTableName, columnRowName);
	attributeCol= checkAttribute( attributeColName, rootAttributeGroup, dataTableName, columnColName);
	
-- Deleting old mutual influence

	dataTable= lm.explore.findDataTable({ name= dataTableName});
	
	mutualInfluenceArray= lm.domain.prepareMutualInfluenceArray({ 
		pDataTable= dataTable,
		pAttributeRow= attributeRow,
		pAttributeCol= attributeCol
	});

	for i, mutualInfluence in ipairs( mutualInfluenceArray) do
	
		lm.log( "Deleting old mutual influence "..mutualInfluence.ID);
	
		mutualInfluence.onDel();
			
	end;

--	New mutual influence

	mutualInfluence= lm.domain.MutualInfluence( {
			pAttributeRow= attributeRow,
			pAttributeCol= attributeCol
	});

	-- Set mutual influence type
	mutualInfluence.setMutualInfluenceTypeCode( 
		lm.codes.MutualInfluenceType.PositiveInfluence);
		
	-- Creating atomic rules
	mutualInfluence.autoCreateDiagonalePositive();

-- Close the metabase
	lm.metabase.markChanged();			-- inform LM Workspace that the script have made some changes to metabase
	lm.metabase:close();

-- Log finish
	lm.logInfo( "LMExec Script End");
