-- LISp-Miner Control Language demo script
-- Obligatory "Hello, world!" example
-- Part of the LISp-Miner system, for details see http://lispminer.vse.cz

-- Look-up packages also in the script directory and in the LM/Exec/Lib directory
package.path= package.path..";"..lm.getScriptFolder().."?.lua;"..lm.getLMRootFolder().."/Exec/Lib/?.lua;";;

-- Import predefined constants
local lm= require( "LMGlobal");

-- Log start
lm.log( "LMExec Script Demo Hello, world! script");

-- Open a dialog box
lm.logInfo( "Hello, world!");

-- Log finish
lm.logInfo( "LMExec Script End");
